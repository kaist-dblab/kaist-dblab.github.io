/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/* 
 *  Description : 
 *      Allocate a new buffer page.
 *      This routine uses the second chance buffer replacement algorithm
 *      to select a victim.  That is, if the reference bit of current 
 *      checking entry (indicated by BfM_NextVictim) is set, then simply clear
 *      the bit for the second chance and proceed the next entry, otherwise
 *      the current page indicated by BfM_NextVictim is selected to be returned.
 *      Before return the buffer, if the dirty bit of the victim is set, it 
 *      must be force out to the disk.
 *
 *  Return Values : 
 *      An index of a new buffer page from the buffer pool
 *
 *  Errors : 
 *      some errors : caused by BfM_FlushPage(), BfM_FreePage(), 
 *                    and BfM_Insert()
 */

#include <BfM.h>

VictimCallBackType victimCallBack;

int BfM_AllocPage(void)
{
	int		i, e;
	int		victim;		/* return value */

	/* starting from the NextVictim, find the victim  */
	/* If there is a unfixed buffer, we can find it at most 2 loops */
	victim = BfM_NextVictim;
	for(i=0; i<2*BfM_MaxBufs; i++, victim = (victim+1)%BfM_MaxBufs) {
		if(BfM_BufferTable[victim].fixed <= 0) {
			/* if the reference bit is set, simply clear it for the second chance */
			if(BfM_BufferTable[victim].bits & REFER)
				BfM_BufferTable[victim].bits ^= REFER;	/* clear the bit */

			else {	/* The bit is 0 */
				/* if the dirty bit is set, force out to the disk */
				if(BfM_BufferTable[victim].bits & DIRTY)  {
					e = BfM_FlushPage(BfM_BufferTable[victim].Key.SegID, &(BfM_BufferTable[victim].Key.pageid));
					if(e < 0) return e;
				}

				/* Delete the victim from the hash table */
				if(BfM_BufferTable[victim].Key.SegID != NIL) {
					e = BfM_Delete(&(BfM_BufferTable[victim].Key));
					if(e < 0) return e;
				}

				BfM_BufferTable[victim].bits = ALL_0;

				/* The next buffer is the next victim. */
				BfM_NextVictim = (victim + 1) % BfM_MaxBufs; 

				break;  /* escape from the loop */
		    }
		}
	}

	if(i == 2*BfM_MaxBufs) {
		puts("fatal no more unfixed buffers");
		return(eNOBUFFER);
	}

	return(victim);
}  /* BfM_AllocPage */
