/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/* 
 *  Description : 
 *      Initialize the buffer table which is resposible for the buffer pool.
 *      All bits (dirty, valid and reference bit) of each table entry in the 
 *      buffer table are set to 0.
 *
 *  Return Values : None
 *
 *  Errors : None
*/


#include <malloc.h>
#include <BfM.h>

/* Global variables which are used through buffer manager */

BufferTable* BfM_BufferTable = NULL;	/* one-to-one correpond to bufferpool */
char* BfM_BufferPool	     = NULL;    /* set of pages */
int BfM_NextVictim			 = 0;		/* next victim used by replacement algorithm */
int BfM_MaxBufs				 = 0;		/* max buffer size */
int BfM_HashTableSize		 = 0;
int BfM_PAGESIZE			 = 0;

/*
 * The size of the hash table is four times of the size of the buffer pool
 * in order to minimize the rate of collisions.
 * Each entry of the hash table corresponds to an index of the buffer pool 
 * as well as the buffer table.
 */
int* BfM_HashTable = NULL;

int BfM_Init(int maxbuffers, int pagesize)
{
    int i;   /* index */

	BfM_MaxBufs			= maxbuffers;
	BfM_HashTableSize	= BfM_MaxBufs * 3 - 1;
	BfM_PAGESIZE        = pagesize;

	if(BfM_BufferTable)
		free(BfM_BufferTable);
	BfM_BufferTable = NULL;
	if(BfM_BufferPool)
		free(BfM_BufferPool);
	BfM_BufferPool = NULL;
	if(BfM_HashTable)
		free(BfM_HashTable);
	BfM_HashTable = NULL;
	BfM_BufferTable = (BufferTable*)malloc(sizeof(BufferTable) * BfM_MaxBufs);
	BfM_BufferPool	= (char*)malloc(BfM_PAGESIZE * BfM_MaxBufs);
	BfM_HashTable   = (int*)malloc(sizeof(int) * BfM_HashTableSize);

    /* The first selected buffer is the first entry of the buffer pool */
    BfM_NextVictim = 0;

    /* clear all bits for initialization */
	for(i = 0; i < BfM_MaxBufs; i++)  { 
        BfM_BufferTable[i].bits  = ALL_0;
		BfM_BufferTable[i].fixed = 0;
        BfM_BufferTable[i].Key.SegID  = NIL;
        BfM_BufferTable[i].Key.pageid.pageNo = (PageNo)NIL;
    }

    BfM_InitHashTable();

	return eNOERROR;
}  /* BfM_Init */

