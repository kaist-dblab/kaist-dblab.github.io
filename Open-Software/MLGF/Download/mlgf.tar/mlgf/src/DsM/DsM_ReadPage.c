/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 *  Description : Read a page from the disk and load it into apage.
 *
 *  Return Values : a page read from the disk using given pageid
 *
 *  Errors :
 *      eNOERROR : No error
 *      eBADPAGEIDDSM   : Invalid page identifier
 *      eBADBUFFERDSM   : Invalid pointer to buffer
 *      eSYSTEMERRORDSM : Error occurs when UNIX system call is called
 */

#include <DsM.h>

int DsM_ReadPage(int SegID, PageID* pageid, void* apage)
{
    int  e;   /* for error */
    int  f_desc;
    long byte_offset;

    if((pageid==NULL) || (pageid->pageNo<0))  /* Invalid page identifier */
        return(eBADPAGEIDDSM);

    if(apage == NULL)   /* Invalid pointer to buffer */
        return(eBADBUFFERDSM);
    
    e = dsm_segid_getdesc(SegID, &f_desc);
    if(e < 0)  return e;

    /* seek the correct position which coressponds to pageid */
    byte_offset = (long) (pageid->pageNo) * DsM_PAGESIZE;   /* calculate the byte offset */

    e = sys_lseek(f_desc, byte_offset, FROM_SET);  

    if(e < 0)    /* system call error */
        return(eSYSTEMERRORDSM);


    /* read the page from the disk to the given buffer */
    e = sys_read(f_desc, (char *)apage, DsM_PAGESIZE);

    DsM_read_count++;   /* for real disk access count: jwsong  */

    if(e < 0)   /* system call error */
        return(eSYSTEMERRORDSM);

    return(eNOERROR);

}  /* DsM_ReadPage */
