/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#include <malloc.h>
#include <DsM.h>


/* 
 *  Our `kaoss' uses the UNIX file system instead of directly using raw disk.
 *  By this  reason,  the unique segment identifier of a file (segment) must
 *  be  maintained.   This file has  some routines for supporting a file has
 *  an unique segment identifier. This also contains a routine which returns
 *  a file name (a string) corresponding to a given segment identifier.
 */
    

int dsm_size;   /* the size of the table */

int dsm_free;   /* the first index of the free list */


/*
 *  Data Structures of the `SegmentID - file name' table.
 *
 *  The index of this table indicates a unique segment identifier.
 *  The `used' field indicates whether the entry is used.   If the
 *  entry is being used,  the `fname' field  has the corresponding
 *  file name, otherwise the entry belongs to the free list by the
 *  `l' field (p : previous, n : next link).
 * 
 */
typedef struct {
    char used;    /* whether it is used or not */

    union {
        struct {
            char fname[MAXFILENAME];   /* file name */
            int count;                 /* # of scans */
            int fd;                    /* a unix file descriptor */
        } f;

        struct {     /* for supporting linked list (free list) */
            int p;   /* previous */
            int n;   /* next */
        } l;
    } entry;

} SegEntry;


SegEntry *dTable;  /* the table */


#define USED(i)   ((dTable[(i)].used == TRUE) ? "true" : "false")
#define FNAME(i)  ((dTable[(i)].used == TRUE) ? (dTable[(i)].entry.f.fname) : "Null")
#define FDESC(i)  ((dTable[(i)].used == TRUE) ? (dTable[(i)].entry.f.fd) : -1)
#define COUNT(i)  ((dTable[(i)].used == TRUE) ? (dTable[(i)].entry.f.count) : -1)

int dsm_segid_get(int segid)
{
    return FDESC(segid);
}

/*
 *  Initialize the table.  The size of the table is given as `size' parameters,
 *  but  the true size of the table is bigger than  the given `size' since the
 *  table may  grow.   Initailly,  the table has no used entry and all entries
 *  belong to the free list.
 */
int dsm_segid_init(int size)
{
    int i;  /* for index */

    if(size < 0)
        return(eBADSIZEdsm);

    dsm_size = size * 2;   /* calculate the size of the table */

    /* allocate memory for the table */
    dTable = (SegEntry *)malloc(sizeof(SegEntry) * dsm_size);

    if(dTable == NULL)
        return(eALLOCERRORdsm);


    /* Initailly, all entries belong to the free list, do it */

    dTable[0].entry.l.p = NIL;
    dTable[0].entry.l.n = 1;
    dTable[0].used = FALSE;

    for(i = 1; i < (dsm_size - 1); i++) {
        dTable[i].entry.l.p = i - 1;
        dTable[i].entry.l.n = i + 1;
        dTable[i].used = FALSE;
    }

    dTable[i].entry.l.p = i - 1;
    dTable[i].entry.l.n = NIL;
    dTable[i].used = FALSE;


    dsm_free = 0;   /* the first entry of the free list */

    return(eNOERROR);

}  /* dsm_segid_init */



int dsm_segid_final(void)
{

    free(dTable);

    return(eNOERROR);

} /* dsm_segid_final */



int dsm_segid_open(int segid, int mode)
{

    if(dTable[segid].used == FALSE) return(eBADSEGIDdsm);

    if(dTable[segid].entry.f.fd != NIL) 
        (dTable[segid].entry.f.count)++;
    else {
        dTable[segid].entry.f.fd = sys_open(FNAME(segid), mode);
        if(dTable[segid].entry.f.fd < 0) return(eBADSEGIDdsm);
        dTable[segid].entry.f.count = 1;
    }

    return(eNOERROR);
}


int dsm_segid_close(int segid)
{

    if(dTable[segid].used == FALSE) return(eBADSEGIDdsm);

    if(dTable[segid].entry.f.fd == NIL) return(eNOTOPENdsm);
    else {
        (dTable[segid].entry.f.count)--;
        if(dTable[segid].entry.f.count <= 0) {
            sys_close(dTable[segid].entry.f.fd);
            dTable[segid].entry.f.fd = NIL;
        }
    }
	return eNOERROR;
}


int dsm_segid_getdesc(int segid, int* desc)
{

    if(dTable[segid].used == FALSE) return(eBADSEGIDdsm);

    if(dTable[segid].entry.f.fd == NIL) return(eNOTOPENdsm);

    *desc = dTable[segid].entry.f.fd;

    return(eNOERROR);
}


/*
 *  Insert an entry into the table.   The index of the table is `segid' and
 *  the corresponding file name is `name'.  The entry filled with the given
 *  parameters does not belong to the free list any more.
 */
int dsm_segid_insert(int segid, char* name)
{
    int e;
    int next, prev;

    if(segid < 0) return(eBADSEGIDdsm);

    if(segid >= dsm_size) {
        e = dsm_segid_double();
        if(e < 0)  return e;
    }

    if(dTable[segid].used == TRUE)
        return(eDUPLICATESEGIDdsm);

    if(name == NULL)
        return(eBADFILENAMEdsm);

    prev = dTable[segid].entry.l.p;
    next = dTable[segid].entry.l.n;


    /* Reorganize links */

    if(dsm_free == segid)  /* that is, prev == NIL */
        dsm_free = next;
    else 
        dTable[prev].entry.l.n = next;

    if(next != NIL)
        dTable[next].entry.l.p = prev;

    /* fill the entry with the given file name */
    strcpy(dTable[segid].entry.f.fname, name);
    dTable[segid].entry.f.fd = NIL;

    dTable[segid].used = TRUE;  /* mark it use */

    return(eNOERROR);

}  /* dsm_segid_insert */


/*
 *  Delete an entry from the table.  The entry which will be deleted is 
 *  indicated by `segid'.   After this function is executed,  the entry
 *  belong to the free list.
 */
int dsm_segid_delete(int segid)
{

    if((segid < 0) || (segid >= dsm_size))
        return(eBADSEGIDdsm);


    /* reorganize links */

    if(dsm_free != NIL)  
        dTable[dsm_free].entry.l.p = segid;

    dTable[segid].entry.l.n = dsm_free;
    dTable[segid].entry.l.p = NIL;

    dsm_free = segid;

    dTable[dsm_free].used = FALSE;   /* free it */

    return(eNOERROR);

}  /* dsm_segid_delete */


/*
 *  Get a new segment identifier from the free list.  If the free list is
 *  NULL, double the size of the table and make the free list.
 */
int dsm_segid_new(void)
{
    int e;
    int newid;

    if(dsm_free == NIL)  {    /* double the size and allocate the free list */
        e = dsm_segid_double();
        if(e < 0)
            return e;
    }

    newid = dsm_free;  /* new id is the first entry of the free list */

    return(newid);

}  /* dsm_segid_new */


/*
 *  Double the table size. First, it reallocates the table of which size is
 *  the double of the original table.  Second, put the new entries into the
 *  the free list.  Finally, double `dsm_size' which is the size of the table.
 */
int dsm_segid_double(void)
{
    int i;
    int new_size;
    SegEntry *temp;

    new_size = dsm_size * 2;  /* the new size is the double of the old one */

    temp = (SegEntry *)realloc((SegEntry *)dTable, sizeof(SegEntry) * new_size);

    if(temp == NULL)
        return(eALLOCERRORdsm);

    dTable = temp;

    /* Put the rest of the new table into the free list */

    dTable[dsm_size].entry.l.p = NIL;
    dTable[dsm_size].entry.l.n = dsm_size + 1;
    dTable[dsm_size].used = FALSE;

    for(i = dsm_size + 1; i < (new_size - 1); i++) {
        dTable[i].entry.l.p = i - 1;
        dTable[i].entry.l.n = i + 1;
        dTable[i].used = FALSE;
    }

    dTable[i].entry.l.p = i - 1;
    dTable[i].entry.l.n = NIL;
    dTable[i].used = FALSE;


    dsm_free = dsm_size;

    dsm_size = new_size;


    return(eNOERROR);

}  /* dsm_segid_double */


/*
 *  Get the file name which is corresponding to a given segment identifier.
 */
int dsm_segid_namefromid(int segid, char* name)
{

    if((segid < 0) || (segid >= dsm_size))
        return(eBADSEGIDdsm);

    if(dTable[segid].used == FALSE)
        return(eBADSEGIDdsm);

    strcpy(name, dTable[segid].entry.f.fname);   /* return a file name */

    return(eNOERROR);

}  /* dsm_segid_namefromid */



/*
 *  Get the segment identifier corresponding to the given file name.
 */
int dsm_segid_idfromname(char* name, int* segid)
{
    int i;

    if(name == (char *)NULL) return(eBADFILENAMEdsm);

    /* find out the name from the table */
    for(i = 0;i < dsm_size;i++)
        if((dTable[i].used == TRUE) && !strcmp(name,dTable[i].entry.f.fname)) break;

    if(i == dsm_size) return(eBADFILENAMEdsm);

    *segid = i;     /* Segment Identifier */

    return(eNOERROR);

}   /* dsm_segid_idfromname */



int dsm_segid_dump(char* para)
{
    int i;

    printf("\n\t|=======================================================|\n"); 
    printf("\t|         %32s              |\n", para);
    printf("\t|%8s--|%20s------|%5s---|%5s---|\n", "--------","--------------------","-----","-----");
    printf("\t|%8s  |%20s      |%5s   |%5s   |\n", "Used", "File Name", "FD", "CNT");
    printf("\t|%8s--|%20s------|%5s---|%5s---|\n", "--------","--------------------","-----","-----");

    for(i = 0; i < dsm_size; i++) 
        printf("\t|%8s  |%20s      |%5d   |%5d   |\n", USED(i), FNAME(i), FDESC(i), COUNT(i));
    printf("\t|==========|==========================|========|========|\n"); 

	return eNOERROR;
}
