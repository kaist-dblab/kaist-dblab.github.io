/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: MLGF_CreateIndex.c
 *
 * Description:
 *  Create an MLGF index.
 *
 * Exports:
 *  Four MLGF_CreateIndex(One*, One, One, AttributeType[], MLGF_HashValue)
 *
 * Returns:
 *  Error code
 *    eBADPARAMETER
 *    some errors caused by function calls
 */


#include "common.h"
#include "DsM.h"


Four MLGF_CreateIndex(
	One				*path,				/* IN full name of the file */
	One				numOfKeys,			/* IN the number of keys (organizing attributes) */
	One				numOfAttrs,			/* IN the number of attributes of the object */
										/* 	  (including the number of organizing attributes) */
	AttributeType	*attrType,			/* IN type of each attribute */
	MLGF_HashValue	minMaxTypeVector,	/* IN bit vector of flags indicating MIN/MAX of MBR for each attribute */
	One			    useAdditionalFunc) /* IN flag of additional function use */
{
	int		os_fd;			/* OS level file descriptor */
	struct stat	statBuf;
	Two		mlgfd;			/* MLGF file descriptor */
	Two		i;				/* index */
    Four	e;				/* error code */
	PageID	rootPid;		/* root page of the newly created MLGF */
    mlgf_DirectoryPage	*apage;		/* root page of the created index */
#ifndef MBR_MLGF_BUFFER
    mlgf_DirectoryPage	apageBuf;	/* buffer for root page */

	apage = &apageBuf;
#endif  /* MBR_MLGF_BUFFER */


    /* check parameters */
	if (path == NULL || numOfKeys > numOfAttrs || numOfAttrs > MLGF_MAXNUM_ATTRIBUTES || attrType == NULL)
    	ERR(eBADPARAMETER);

	/* Find an empty slot in the open file table */
	mlgfd = mlgf_GetOpenFileTableEntry();
	if (mlgfd < 0) ERR(mlgfd);

	/* open new file */
	if((os_fd = open(path, O_RDWR|O_CREAT|O_TRUNC, 0600)) < 0) {
		perror(" creat a new MLGF file");
		ERR(eSYSERR);
	}
	if(stat(path, &statBuf) < 0) ERR(eSYSERR);
	OPENFILE_INO(mlgfd) = statBuf.st_ino;
	OPENFILE_COUNT(mlgfd) = 1;
	OPENFILE_OS_FD(mlgfd) = os_fd;

	/* initialize control information */
	OPENFILE_CONTROL(mlgfd).numOfKeys = numOfKeys; 
	OPENFILE_CONTROL(mlgfd).numOfAttrs = numOfAttrs;
	OPENFILE_CONTROL(mlgfd).rootPage.pageNo = NIL_PAGEID;
	OPENFILE_CONTROL(mlgfd).minMaxTypeVector = minMaxTypeVector;

	/* initialize attribute type */
	OPENFILE_CONTROL(mlgfd).objMaxLen = 0;
	if ( useAdditionalFunc )
		OPENFILE_CONTROL(mlgfd).useAdditionalFunc = TRUE;
	else
		OPENFILE_CONTROL(mlgfd).useAdditionalFunc = FALSE;

	if ( useAdditionalFunc <0 || useAdditionalFunc > 1)
		return ( eBADPARAMETER );

	for(i = 0; i < numOfAttrs; i++) {
		OPENFILE_CONTROL(mlgfd).attrType[i].dataType = attrType[i].dataType;
		OPENFILE_CONTROL(mlgfd).attrType[i].length = attrType[i].length;

		OPENFILE_CONTROL(mlgfd).objMaxLen += attrType[i].length;
		if(attrType[i].dataType == VARSTRING)
		{
			OPENFILE_CONTROL(mlgfd).objMaxLen += sizeof(Two);
		}
		if(attrType[i].length <= 0 || OPENFILE_CONTROL(mlgfd).objMaxLen > OBJ_MAX_LEN)
			ERR(eBADPARAMETER);
	}

	/* initialize free page list */
	OPENFILE_FREEPAGELIST(mlgfd).next = NULL;
	OPENFILE_PAGECOUNT(mlgfd).pageNo = 0;
	OPENFILE_PAGECOUNT(mlgfd).volNo = 0;

#ifdef MBR_MLGF_BUFFER
	close(OPENFILE_OS_FD(mlgfd));
	OPENFILE_DSMSEGID(mlgfd) = dsm_segid_new();
	if(!(dsm_segid_insert(OPENFILE_DSMSEGID(mlgfd), path) == eNOERROR &&
         DsM_OpenSegment(OPENFILE_DSMSEGID(mlgfd), INOUT) == eNOERROR))
	{
		return(eSYSERR);
	}
    OPENFILE_OS_FD(mlgfd) = dsm_segid_get(OPENFILE_DSMSEGID(mlgfd));
#endif  /* MBR_MLGF_BUFFER */

    /* Allocate a new btree page for the root of a btree. */
    e = mlgf_AllocPage(mlgfd, &rootPid);
    if (e < 0)  ERR(e);

    /*
    ** Construct a root page.
    */
    /* Read the root page into the buffer. */
#ifdef MBR_MLGF_BUFFER
    e = BfM_GetNewPage(OPENFILE_DSMSEGID(mlgfd), &rootPid, (char**)&apage); 
    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    MLGF_INIT_DIRECTORY_PAGE(apage, FALSE, rootPid, 1, TRUE); 
    
#ifdef MBR_MLGF_BUFFER
    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &rootPid);
    if (e < 0) ERR(e);

    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &rootPid);
    if (e < 0) ERR(e);
#else
	e = mlgf_WritePage(mlgfd, rootPid, (char*)apage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	OPENFILE_CONTROL(mlgfd).rootPage.pageNo = rootPid.pageNo;

	/* Write the control information to the created file and close it. */
	e = MLGF_CloseIndex(mlgfd);
	if (e < 0) ERR(e);

	return(eNOERROR);
} /* MLGF_CreateIndex() */
