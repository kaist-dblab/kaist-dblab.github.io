/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: MLGF_DeleteObject.c
 *
 * Description:
 *  Delete an object from the given MLGF index.
 *
 * Exports:
 *  Four MLGF_DeleteObject(Two, AttributeHeader[])
 */


#include <assert.h>
#include "common.h"


/* Internal Function Prototypes */
Four mlgf_DeleteRecursive(Two, PageID*, MLGF_KeyDesc*, MLGF_HashValue*,
                          Object*, mlgf_DirectoryEntry*, mlgf_DeleteStatus_T*);


/*
 * Function: Four MLGF_DeleteObject(Two, AttributeHeader[])
 *
 * Description:
 *  Delete an object from the given MLGF index.
 *
 * Returns:
 *  Error code
 *	 eNOTFOUND
 *   eBADPARAMETER
 *   some errors caused by function calls
 */
Four MLGF_DeleteObject(
	Two							mlgfd,					/* IN MLGF file descriptor */
	AttributeHeader				*attrValues)			/* IN array of attribute values (object) to	delete */
{
    Four                        e;                      /* error code */
    One                         i;                      /* index variable */
    mlgf_DirectoryEntry         rootEntry;              /* directory entry for old root page */
    char                        extraData[PAGESIZE];    /* extra data of the deleted object */
    PageID                      tmpPid;
    mlgf_DeleteStatus_T         status;
	PageID						rootPid;				/* root page of MLGF */
	MLGF_KeyDesc				kdesc;					/* key descriptor of MLGF */
	MLGF_HashValue				keys[MLGF_MAXNUM_KEYS];	/* hash values of keys */
	Object						obj;					/* object to delete */
	char						*dataPtr;				/* pointer to data of object */
	Two							len;

	if (!IS_VALID_MLGFD(mlgfd) || attrValues == NULL)
		ERR(eBADPARAMETER);

	 if ( OPENFILE_CONTROL(mlgfd).useAdditionalFunc == FALSE)
	 {
		 for(i=0; i<OPENFILE_CONTROL(mlgfd).numOfAttrs; i++)
	     {
	    	 if (OPENFILE_CONTROL(mlgfd).attrType[i].dataType == VARSTRING)
	         {
			     ERR(eVARIABLELENGTHRECORD);
		     }
	 	 }
	 }

	if ( OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
		len = sizeof(Two);
	else
		len = 0;

	dataPtr = &obj.data[0];
	for(i=0; i<OPENFILE_CONTROL(mlgfd).numOfAttrs; i++)
	{
		if (OPENFILE_CONTROL(mlgfd).attrType[i].dataType == VARSTRING)
		{
			if (ATTRIBUTE_LENGTH(&(attrValues[i])) > OPENFILE_CONTROL(mlgfd).attrType[i].length ||
					ATTRIBUTE_LENGTH(&(attrValues[i])) <= 0)
				ERR(eBADPARAMETER);
		}
		else
		{
			if (ATTRIBUTE_LENGTH(&(attrValues[i])) != OPENFILE_CONTROL(mlgfd).attrType[i].length)
				ERR(eBADPARAMETER);
		}
		
		switch(OPENFILE_CONTROL(mlgfd).attrType[i].dataType)
		{
			case INT:
				memcpy((char*)&dataPtr[len],
						(char*)INT_ATTRIBUTE(&(attrValues[i])),
						ATTRIBUTE_LENGTH(&(attrValues[i])));
				e = mlgf_GetHashValue(OPENFILE_CONTROL(mlgfd).attrType[i].dataType,
											&attrValues[i], &keys[i]);
				if(e<0) ERR(e);
				break;
			case FLOAT:
				memcpy((char*)&dataPtr[len],
						(char*)FLOAT_ATTRIBUTE(&(attrValues[i])),
						ATTRIBUTE_LENGTH(&(attrValues[i])));
				e = mlgf_GetHashValue(OPENFILE_CONTROL(mlgfd).attrType[i].dataType,
											&attrValues[i], &keys[i]);
				if(e<0) ERR(e);
				break;
			case STRING:
				memcpy((char*)&dataPtr[len],
						(char*)STRING_ATTRIBUTE(&(attrValues[i])),
						ATTRIBUTE_LENGTH(&(attrValues[i])));
				e = mlgf_GetHashValue(OPENFILE_CONTROL(mlgfd).attrType[i].dataType,
											&attrValues[i], &keys[i]);
				if(e<0) ERR(e);
				break;
			case VARSTRING:
				memcpy((char*)&dataPtr[len], (char*)&(ATTRIBUTE_LENGTH(&(attrValues[i]))), sizeof(Two));
				len += sizeof(Two);
				memcpy((char*)&dataPtr[len],
						(char*)STRING_ATTRIBUTE(&(attrValues[i])),
						ATTRIBUTE_LENGTH(&(attrValues[i])));
				e = mlgf_GetHashValue(OPENFILE_CONTROL(mlgfd).attrType[i].dataType,
											&attrValues[i], &keys[i]);
				if(e<0) ERR(e);
				break;
		}
		len += ATTRIBUTE_LENGTH(&(attrValues[i]));
	}

	if ( OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
	{
		len -= sizeof(Two);
		memcpy((char*)&dataPtr[0],&len,sizeof(Two));
	}

	rootPid = OPENFILE_CONTROL(mlgfd).rootPage;
	kdesc.flag = OPENFILE_CONTROL(mlgfd).flag;
	kdesc.nKeys = OPENFILE_CONTROL(mlgfd).numOfKeys;
	kdesc.objMaxLen = OPENFILE_CONTROL(mlgfd).objMaxLen;
	kdesc.minMaxTypeVector = OPENFILE_CONTROL(mlgfd).minMaxTypeVector;

    /* `rootEntry' is the entry for root page. */
    rootEntry.spid = rootPid.pageNo; 
    rootEntry.theta = 0;	/* ignore this field for root page */
    for (i = 0; i < kdesc.nKeys; i++) rootEntry.nValidBits[i] = 0;

    /* call recursion */
    status.allFlags = 0;
	e = mlgf_DeleteRecursive(mlgfd, &rootPid, &kdesc, keys, &obj, &rootEntry, &status);
    if (e < 0) ERR(e);

    if (status.flags.notFound) return(eNOTFOUND);

    return(eNOERROR);

} /* MLGF_DeleteObject() */



/*
 * Function: Four mlgf_DeleteRecursive(Two, PageID*, MLGF_KeyDesc*, MLGF_HashValue*,
 *             Object*, mlgf_DirectoryEntry*, mlgf_DeleteStatus_T*)
 *
 * Description:
 *  This function is an auxiliary function of MLGF_DeleteObject().
 *
 * Returns:
 *  Error code
 *    some errors caused by function calls
 */
Four mlgf_DeleteRecursive(
	Two					mlgfd,					/* IN MLGF file descriptor */
    PageID              *root,                  /* IN root of subtree */
    MLGF_KeyDesc        *kdesc,                 /* IN key descriptor for MLGF */
    MLGF_HashValue      *keys,                  /* IN hash values of the deleted object */
	Object				*obj,					/* IN object to delete */
    mlgf_DirectoryEntry *entryToRoot,           /* IN entry for the current node in parent node */
    mlgf_DeleteStatus_T *status)                /* INOUT delete status */

{
    Four                e;                      /* error code */
    Two                 entryLen;               /* length of a directory entry */
    Two                 entryNo;                /* index to directory entry */
    PageID              child;                  /* PageID of the child page */
	PageID				emptyPage;				/* PageID of empty page */
    Boolean             found;                  /* TRUE when we find something to search */
    Boolean             mbrChangeFlag;          /* TRUE if the extreme hash values are updated */
    mlgf_Page           *apage;                 /* an MLGF page */
    mlgf_DirectoryPage  *childPage;             /* a child page */
    mlgf_DirectoryEntry *entryToChild;          /* entry pointing to the child */
    mlgf_DirectoryEntry entryToChild_tmp;       /* temporary copy for new update */
    MLGF_HashValue      *extremeHashValues;     /* points to array of extreme hash values in the given root node */
    MLGF_HashValue      *childHashValues;       /* points to array of extreme hash values in the child node */
    MLGF_HashValue      *hx, *hy;               /* points to arrary of hash values in an entry */
    MLGF_HashValue      *entryHashValues;       /* points to arrary of hash values in an entry */
    One                 k;
    Two                 i;
    PageID              tmpPid;
#ifndef MBR_MLGF_BUFFER
    mlgf_Page           apageBuf;				/* buffer for an MLGF page */
    mlgf_DirectoryPage  childPageBuf;			/* buffer for a child page */

	apage = &apageBuf;
	childPage = &childPageBuf;
#endif  /* MBR_MLGF_BUFFER */


#ifdef MBR_MLGF_BUFFER
    /* Read the current node into a buffer. */
    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), root, (char**)&apage);
    if (e < 0) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, *root, (char*)apage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    if (apage->any.hdr.type & MLGF_LEAFPAGE) { /* leaf page */

	/* delete the given object from the leaf page. */
	e = mlgf_DeleteObjectFromLeaf(mlgfd, root, &apage->leaf, kdesc, keys, obj, entryToRoot, status);
#ifdef MBR_MLGF_BUFFER
	if (e < 0) ERRB1(e, mlgfd, root);
#else
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

#ifdef MBR_MLGF_BUFFER
	e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), root);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	return(eNOERROR);
    }

    /* From this point the node is the directory node. */

    /* Calculate the length of a directory entry. */
    entryLen = MLGF_DIRENTRY_LENGTH(kdesc->nKeys);

    /* find region to go */
    found = mlgf_FindEntry(&apage->directory, kdesc->nKeys, keys, &entryNo);

    if (!found) {
        status->flags.notFound = 1;

#ifdef MBR_MLGF_BUFFER
	e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), root);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	return(eNOERROR);
    }

    entryToChild = MLGF_ITH_DIRENTRY(&apage->directory, entryNo, entryLen);
    MAKE_PAGEID(child, root->volNo, entryToChild->spid);


    /* call recursion */
    memcpy(&entryToChild_tmp, entryToChild, entryLen);
    e = mlgf_DeleteRecursive(mlgfd, &child, kdesc, keys, obj, &entryToChild_tmp, status);
#ifdef MBR_MLGF_BUFFER
    if (e < 0) ERRB1(e, mlgfd, root);
#else
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    if (status->flags.thetaUpdated) {

        entryToChild->theta = entryToChild_tmp.theta;
#ifdef MBR_MLGF_BUFFER
        e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), root);
        if (e < 0) ERRB1(e, mlgfd, root);
#else   
		e = mlgf_WritePage(mlgfd, *root, (char*)apage);
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

        status->flags.thetaUpdated = 0;
    }

    if (status->flags.mbrUpdated) {
	
        hx = MLGF_DIRENTRY_HASHVALUEPTR(entryToChild, kdesc->nKeys);
        hy = MLGF_DIRENTRY_HASHVALUEPTR(&entryToChild_tmp, kdesc->nKeys);
        
        for (k = 0; k < kdesc->nKeys; k++) hx[k] = hy[k];
#ifdef MBR_MLGF_BUFFER
        e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), root);
        if (e < 0) ERRB1(e, mlgfd, root);
#else
		e = mlgf_WritePage(mlgfd, *root, (char*)apage);
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

        status->flags.mbrUpdated = 0;

        /*
        ** Update the MBR of the entry 'entryToRoot'
        */
	hx = MLGF_DIRENTRY_HASHVALUEPTR(entryToRoot, kdesc->nKeys);
	for (k = 0; k < kdesc->nKeys; k++) {

	    if ((MLGF_KEYDESC_IS_MINTYPE(*kdesc, k) && (hx[k] < keys[k])) ||
		(MLGF_KEYDESC_IS_MAXTYPE(*kdesc, k) && (hx[k] > keys[k])))
		continue;

            if (MLGF_KEYDESC_IS_MINTYPE(*kdesc, k))
                hx[k] |= MLGF_HASHVALUE_SET_EXCEPT_UPPER_N_BITS(entryToRoot->nValidBits[k]);
            else
                hx[k] = MLGF_HASHVALUE_MASK_UPPER_N_BITS(hx[k], entryToRoot->nValidBits[k]);

            status->flags.mbrUpdated = 1;

	    hy = MLGF_DIRENTRY_HASHVALUEPTR(
		MLGF_ITH_DIRENTRY(&(apage->directory), 0, entryLen), kdesc->nKeys);
	    for (i = 0; i < apage->directory.hdr.nEntries; i++) {
		if ((MLGF_KEYDESC_IS_MINTYPE(*kdesc, k) && (hx[k] > hy[k])) ||
		    (MLGF_KEYDESC_IS_MAXTYPE(*kdesc, k) && (hx[k] < hy[k]))) {

		    hx[k] = hy[k];
		}

		hy = (MLGF_HashValue*)((char*)hy + entryLen);
	    }
        }
    }

    if (status->flags.underflow) {

		if (apage->directory.hdr.height == 1) /* merge leaf page */
		{
		    e = mlgf_MergeLeafPage(mlgfd, &apage->directory, kdesc, &entryNo, entryToRoot);
		}
		else 	/* merge directory page */
		{
		    e = mlgf_MergeDirectoryPage(mlgfd, &apage->directory, kdesc, &entryNo, entryToRoot);
		}
#ifdef MBR_MLGF_BUFFER
		if (e < 0) ERRB1(e, mlgfd, root);
#else
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

        status->flags.underflow = 0;

    } else if (status->flags.emptyPage) {
		/* try to merge the entry with buddy entry with non-empty region */
		if (apage->directory.hdr.height == 1) /* merge leaf page */
		{
			e = mlgf_MergeLeafPage(mlgfd, &apage->directory, kdesc, &entryNo, entryToRoot);
		}
		else 
		{
			/* merge directory page */
			e = mlgf_MergeDirectoryPage(mlgfd, &apage->directory, kdesc, &entryNo, entryToRoot);
		}
#ifdef MBR_MLGF_BUFFER
		if (e < 0) ERRB1(e, mlgfd, root);
#else
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

		if (MLGF_ITH_DIRENTRY(&apage->directory, entryNo, entryLen)->theta == 0) {	/* if failed to merge */
			/* free the empty page */
	    	MAKE_PAGEID(emptyPage, root->volNo, MLGF_ITH_DIRENTRY(&apage->directory, entryNo, entryLen)->spid);
			e = mlgf_FreePage(mlgfd, emptyPage);
#ifdef MBR_MLGF_BUFFER
			if (e < 0) ERRB1(e, mlgfd, root);
#else
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

			/* delete entry */
	        e = mlgf_DeleteFromDirectory(&apage->directory, kdesc, entryNo);
#ifdef MBR_MLGF_BUFFER
	        if (e < 0) ERRB1(e, mlgfd, root);
#else
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

#ifdef MBR_MLGF_BUFFER
	        e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), root);
	        if (e < 0) ERRB1(e, mlgfd, root);
#else
			e = mlgf_WritePage(mlgfd, *root, (char*)apage);
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
		}

        status->flags.emptyPage = 0;
    }

    if (MLGF_DP_THETA(&apage->directory, entryLen) != entryToRoot->theta) {
        /* update the theta value */
	entryToRoot->theta = MLGF_DP_THETA(&apage->directory, entryLen);
        status->flags.thetaUpdated = 1;
    }

    if (apage->directory.hdr.nEntries == 0)
        status->flags.emptyPage = 1;
    else if (entryToRoot->theta < MLGF_DP_THRESHOLD)
	{
        status->flags.underflow = 1;
	}

    if (apage->any.hdr.type & MLGF_ROOTPAGE) {	/* level down */

	/* if the root page has only one entry, let level down */
	while (apage->directory.hdr.nEntries == 1 && apage->directory.hdr.height > 1) {

	    /* Copy the only one child into the root. */
	    entryToChild = MLGF_ITH_DIRENTRY(&apage->directory, 0, entryLen);
	    MAKE_PAGEID(child, root->volNo, entryToChild->spid);

	    /* Read the child into the buffer. */
#ifdef MBR_MLGF_BUFFER
	    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &child, (char**)&childPage);
	    if (e < 0) ERRB1(e, mlgfd, root);
#else
		e = mlgf_ReadPage(mlgfd, child, (char*)childPage);
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
            
            memcpy(&apage->directory.data[0], &childPage->data[0], entryLen*childPage->hdr.nEntries);
            apage->directory.hdr.nEntries = childPage->hdr.nEntries;
            apage->directory.hdr.height --;
	    /* MLGF_COPY_DIRECTORY_PAGE(&apage->directory, *root, childPage, TRUE); */
#ifdef MBR_MLGF_BUFFER
	    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), root);
            if (e < 0) ERRB2(e, mlgfd, &child, root);
#else
			e = mlgf_WritePage(mlgfd, *root, (char*)apage);
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

            
#ifdef MBR_MLGF_BUFFER
	    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &child);
	    if (e < 0) ERRB1(e, mlgfd, root);
#endif  /* MBR_MLGF_BUFFER */

			e = mlgf_FreePage(mlgfd, child);
#ifdef MBR_MLGF_BUFFER
			if (e < 0) ERRB1(e, mlgfd, root);
#else
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
	}
    }

#ifdef MBR_MLGF_BUFFER
    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), root);
    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */


    return(eNOERROR);

} /* mlgf_DeleteRecursive() */

