/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#include "common.h"
#include <string.h>

void mcopy(void* src, void* dest, int length)
{
	memcpy(dest,src,length);
}

Two loadTwo(void* ptr)
{
	Two t;
	mcopy(ptr, &t, sizeof(Two));
	
	return t;
}

void setTwo(Two val, void* ptr)
{
	mcopy(&val, ptr, sizeof(Two));
}

Four loadFour(void* ptr)
{
	Four f;
	mcopy(ptr, &f, sizeof(Four));
	return f;
}
void setFour(Four val, void* ptr)
{
	mcopy(&val, ptr, sizeof(Four));
}

/*
 * Function : mlgf_leafGetTotalObjLen(Two, mlgf_LeafEntry*)
 *
 * Description :
 * 	Return total of data record length in leaf entry
 *
 * 	Return :
 * 	 1) length of data record in leaf entry 
 * 	 2) Error code
 * 	   eBADPARAMETER
 *
 */
Two mlgf_leafGetTotalObjLen(
		Two mlgfd,					 /* IN MLGF file descriptor */
		mlgf_LeafEntry* leafEntry)	 /* IN a leaf entry */
{
	Two nRecords;
	switch(OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
	{
		case FALSE:
			return (OPENFILE_CONTROL(mlgfd).objMaxLen);
		case TRUE:
			
			return loadTwo((char*)(leafEntry->keys + OPENFILE_CONTROL(mlgfd).numOfKeys));
		default :
			ERR(eBADPARAMETER);
			break;
	
	}
}

/*
 * Function : mlgf_leafSetTotalObjLen(Two, mlgf_LeafEntry*, Two)
 *
 * Description :
 * 	Set total of object length in leaf entry
 *
 */
void mlgf_leafSetTotalObjLen(
		Two mlgfd,					 /* IN MLGF file descriptor */
		mlgf_LeafEntry* leafEntry,	 /* IN a leaf entry */
		Two totalObjLen)			 /* IN length of data record */
{

	switch(OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
	{
		case FALSE :
			break;
		case TRUE :
			setTwo(totalObjLen, (char*)( leafEntry->keys + OPENFILE_CONTROL(mlgfd).numOfKeys));
			break;
		default :
			break;
	}
}



/*
 * Function : mlgf_leafGetNObjects(Two, mlgf_LeafEntry*)
 *
 * Description :
 * 	Return number of object in leaf entry
 *
 * Return :
 *  1) number of data record
 *  2) Error code
 *    eBADPARAMETER
 */
Two mlgf_leafGetNObjects(
		Two mlgfd,					 /* IN MLGF file descriptor */
		mlgf_LeafEntry* leafEntry) 	 /* IN a leaf entry */
{
	switch(OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
	{
		case FALSE :
			return 1;
		case TRUE :
			return loadTwo((char*) (leafEntry->keys + OPENFILE_CONTROL(mlgfd).numOfKeys) +  sizeof(Two));
		default :
			ERR(eBADPARAMETER);
			break;
	}
}

/*
 * Function : mlgf_leafSetNObjects(Two, mlgf_LeafEntry*, Two)
 *
 * Description :
 * 	Set number of objects in leaf entry
 *
 */
void mlgf_leafSetNObjects(
		Two mlgfd,					/* IN MLGF file descriptor */
		mlgf_LeafEntry* leafEntry,	/* IN a leaf entry */
		Two nRecords)				/* IN number of data record */
{
	switch(OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
	{
		case FALSE :
			break;
		case TRUE :
			setTwo(nRecords, (char*) (leafEntry->keys + OPENFILE_CONTROL(mlgfd).numOfKeys) +  sizeof(Two));
			break;
		default :
			break;
	}
}



/*
 * Function : mlgf_leafEntryLength(Two, One, Two, Two)
 *
 * Description :
 * 	Return length of leaf entry
 *
 * Return :
 * 	1) length of leaf entry
 * 	2) Error code
 * 		eBADPARAMETER
 *
 */
Two mlgf_leafEntryLength(
		Two mlgfd,			/* IN MLGF file descriptor */
		One nKeys,			/* IN number of organizing attribute */
		Two totalObjLen,	/* IN total length of object */
		Two nObjects)		/* IN number of object */
{
	switch(OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
	{
		case FALSE:
			return (sizeof(MLGF_HashValue)*nKeys + ((nObjects <0) ? sizeof(ShortPageID) : totalObjLen)); 
		case TRUE:
			return (sizeof(Two) + sizeof(Two) + sizeof(MLGF_HashValue)*nKeys + ((nObjects <0) ? sizeof(ShortPageID) : totalObjLen)); 
		default :
			ERR(eBADPARAMETER);
			break;
	}
}

/*
 * Function : mlgf_newLeafEntryLength(Two, One, Two)
 *
 * Description :
 * 	Return length of new leaf entry
 *
 * Return :
 * 	1) length of leaf entry
 * 	2) Error code
 * 		eBADPARAMETER
 *
 */
Two mlgf_newLeafEntryLength(
		Two mlgfd, 			/* IN MLGF file descriptor */
		One nKeys,		    /* IN number of organizing attribute */
		Two totalObjLen)	/* IN total length of object */
{
	switch(OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
	{
		case FALSE:
			return (sizeof(MLGF_HashValue)*nKeys + totalObjLen);
		case TRUE:
			return (sizeof(Two) + sizeof(Two) + sizeof(MLGF_HashValue)*nKeys + totalObjLen);
		default :
			ERR(eBADPARAMETER);
			break;
	}
}

/*
 * Function : mlgf_leafEntryObjectItemLen(Two, Object*)
 *
 * Description :
 * 	Return length of object 
 *
 * Return :
 * 	1) length of leaf entry
 * 	2) Error code
 * 		eBADPARAMETER
 *
 */
Two mlgf_leafEntryObjectItemLen(
		Two mlgfd,		/* IN MLGF file descriptor */
		Object*  obj)	/* IN object */
{
	switch(OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
	{
		case FALSE:
			return ALIGNED_LENGTH(OPENFILE_CONTROL(mlgfd).objMaxLen);
		case TRUE:
			return ALIGNED_LENGTH(loadTwo((char*)(obj->data))+sizeof(Two));
		default :
			ERR(eBADPARAMETER);
			break;
	}
}

/*
 * Function : mlgf_isSameObject(Two, Object*, Object*)
 *
 * Description :
 *	Check equality of two objects
 *
 * Return :
 * 	1) Same or Not
 *
 */
One mlgf_isSameObject(
		Two mlgfd,		/* IN MLGF file descriptor */
		Object* objX,	/* IN object */
		Object* objY)	/* IN object */
{
	switch(OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
	{
		case FALSE :
			if ( memcmp(objX->data, objY->data,mlgf_leafEntryObjectItemLen(mlgfd,objX))==0)
				return WHOLE_SAME;
			if (memcmp(objX->data, objY->data,OPENFILE_CONTROL(mlgfd).numOfKeys * sizeof(MLGF_HashValue)) == 0)
				return KEY_SAME;
			else
				return FALSE;
		case TRUE :
			if ((loadTwo((char*)(objX->data))==(loadTwo((char*)(objY->data)))) && (memcmp((char*)(objX->data+sizeof(Two)),(char*)(objY->data+sizeof(Two)),loadTwo((char*)(objX->data))) == 0))
				return TRUE;
			else
				return FALSE;
	}
}

