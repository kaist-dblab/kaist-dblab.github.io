/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_Dump.c
 *
 * Description:
 *  Includes routines dump the data structures used in the MLGF index.
 *
 * Exports:
 */


#include <ctype.h>
#include "common.h"


/* Internal Function Prototypes */
void mlgf_DumpDirectoryEntry(mlgf_DirectoryEntry*, One, FILE*);
void mlgf_DumpLeafEntry(Two, mlgf_LeafEntry*, MLGF_KeyDesc*, Boolean, FILE*);
void mlgf_DumpObjectItem(Two, char*, Boolean, FILE*);


/*
 * Function: Four mlgf_DumpDirectoryPage(Two, PageID*, File*)
 *
 * Description:
 *  Dump the directory page.
 *
 * Returns:
 *  Error code
 *    some errors caused by function calls
 */
Four mlgf_DumpDirectoryPage(
	Two					mlgfd,					/* IN MLGF file descriptor */
    PageID              *pid,                   /* IN PageID of a directory page */
	FILE				*fd)					/* OUT output file descriptor */
{
    Four                e;                      /* error code */
    Two                 i;                      /* index variable */
    Two                 entryLen;               /* the length of a directory entry */
    mlgf_DirectoryEntry *entry;                 /* a directory entry */

    mlgf_DirectoryPage	*apage;		/* pointer to buffer for the directory page */
#ifndef MBR_MLGF_BUFFER
    mlgf_DirectoryPage	apageBuf;	/* buffer for the directory page */

	apage = &apageBuf;
#endif  /* MBR_MLGF_BUFFER */


#ifdef MBR_MLGF_BUFFER
    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), pid, (char**)&apage);
    if (e < 0) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, *pid, (char*)apage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    if (!(apage->hdr.type & MLGF_DIRECTORYPAGE)) {

	fprintf(fd, "Directory Page Expected!!!\n");

#ifdef MBR_MLGF_BUFFER
	e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), pid);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	return(eNOERROR);
    }

	fprintf(fd, "\n------------------------------------------------------");
	fprintf(fd, "\n|  directory page dump ");
	fprintf(fd, "\n------------------------------------------------------");
	fprintf(fd, "\n|  # of entries      : %d\n", apage->hdr.nEntries);

    /* Get the length of a directory entry. */
    entryLen = MLGF_DIRENTRY_LENGTH(OPENFILE_CONTROL(mlgfd).numOfKeys);

	nDirPages++;
	dirPageOccupancyRatio += (float)MLGF_DP_THETA(apage, entryLen)/(float)(PAGESIZE - MLGF_DP_FIXED);

	/* print all the entries */
    for (i = 0; i < apage->hdr.nEntries; i++) {
		entry = MLGF_ITH_DIRENTRY(apage, i, entryLen);
		fprintf(fd, "| Entry %3d ", i);
		fprintf(fd, "|       Page Ptr %d |\n", entry->spid);


		mlgf_DumpDirectoryEntry(entry,OPENFILE_CONTROL(mlgfd).numOfKeys , fd);
    }


#ifdef MBR_MLGF_BUFFER
    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), pid);
    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

   return(eNOERROR);

} /* mlgf_DumpDirectoryPage() */


/*
 * Function: Four mlgf_DumpLeafPage(Two, PageID*, Boolean, FILE*)
 *
 * Description:
 *  Dump the leaf page.
 *
 * Returns:
 *  Error code
 *    some errors caused by function calls
 */
Four mlgf_DumpLeafPage(
	Two					mlgfd,				/* IN MLGF file descriptor */
    PageID              *pid,				/* IN PageID of a leaf page */
	Boolean				recordOnly,			/* IN whether to dump records only in the bulk export format */
	FILE				*fd)				/* OUT output file descriptor */
{
    Four                e;              /* error code */
    Two                 i, k;			/* index variable */
    Two                 entryLen;       /* the length of a leaf entry */
	MLGF_KeyDesc		kdesc;			/* key descriptor of MLGF */
	PageID				curPid;			/* current overflow page ID */
	PageID				nextPid;		/* next overflow page ID */
    mlgf_LeafEntry      *entry;         /* a leaf entry */
    mlgf_LeafPage       *apage;         /* pointer to buffer for the leaf page */
	mlgf_OverflowPage	*opage;			/* pointer to buffer for the overflow page */
#ifndef MBR_MLGF_BUFFER
    mlgf_LeafPage       apageBuf;		/* buffer for the leaf page */
	mlgf_OverflowPage	opageBuf;		/* buffer for the overflow page */

	apage = &apageBuf;
	opage = &opageBuf;
#endif  /* MBR_MLGF_BUFFER */

	kdesc.flag = OPENFILE_CONTROL(mlgfd).flag;
	kdesc.nKeys = OPENFILE_CONTROL(mlgfd).numOfKeys;
	kdesc.objMaxLen = OPENFILE_CONTROL(mlgfd).objMaxLen;
	kdesc.minMaxTypeVector = OPENFILE_CONTROL(mlgfd).minMaxTypeVector;

#ifdef MBR_MLGF_BUFFER
    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), pid, (char**)&apage);
    if (e < 0) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, *pid, (char*)apage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    if (!(apage->hdr.type & MLGF_LEAFPAGE)) {

	fprintf(fd, "Leaf Page Expected!!!\n");

#ifdef MBR_MLGF_BUFFER
	e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), pid);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	return(eNOERROR);
    }

	if(!recordOnly)
	{
		fprintf(fd, "\n Dump leaf page : total %d entries\n", apage->hdr.nEntries);
	}

	if (!recordOnly) {
		nLeafPages++;
		leafPageOccupancyRatio += (float)MLGF_LP_THETA(apage)/(float)(PAGESIZE - sizeof(mlgf_LeafPageHdr_T));
	}

	/* print all the records */
    for (i = 0; i < apage->hdr.nEntries; i++) {
		entry = MLGF_ITH_LEAFENTRY(apage, i);

		if(!recordOnly) {
        	fprintf(fd, "Entry %d : ", i);
			fprintf(fd, "region vector = <");
			for(k=0; k<OPENFILE_CONTROL(mlgfd).numOfKeys; k++) {
				if(k != 0) fprintf(fd, ",");
				fprintf(fd, "0x%0x", entry->keys[k]);
			}
			fprintf(fd, ">, ");
		}

    	if (mlgf_leafGetNObjects(mlgfd,entry) > 0) { /* normal entry */
			mlgf_DumpLeafEntry(mlgfd, entry, &kdesc, recordOnly, fd);
		}
		else	/* entry that has overflow pages */
		{
			if(!recordOnly)
				fprintf(fd, "Overflow Page Ptr %d\n", MLGF_LEAFENTRY_FIRST_OVERFLOW(kdesc.nKeys, entry));

			MAKE_PAGEID(nextPid, pid->volNo, MLGF_LEAFENTRY_FIRST_OVERFLOW(kdesc.nKeys, entry));
			do {
				curPid = nextPid;
#ifdef MBR_MLGF_BUFFER
				e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &curPid, (char**)&opage);
				if (e < 0) ERRB1(e, mlgfd, pid);
#else
				e = mlgf_ReadPage(mlgfd, curPid, (char*)opage);
				if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

				if(!recordOnly)
					fprintf(fd, " <Overflow Page> Overflow Page : %d\n", curPid.pageNo);

				e = mlgf_DumpOverflowPage(mlgfd, &curPid, recordOnly, fd);
#ifdef MBR_MLGF_BUFFER
				if (e < 0) ERRB2(e, mlgfd, pid, &curPid);
#else
				if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

				/* go to the next page */
				nextPid.pageNo = opage->hdr.nextPage;

#ifdef MBR_MLGF_BUFFER
				e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &curPid);
				if (e < 0) ERRB1(e, mlgfd, pid);
#endif  /* MBR_MLGF_BUFFER */

			} while(!IS_NILPAGEID(nextPid));
		}
    }

#ifdef MBR_MLGF_BUFFER
    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), pid);
    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    return(eNOERROR);

} /* mlgf_DumpLeafPage() */



/*
 * Function: Four mlgf_DumpOverflowPage(Two, PageID*, Boolean, FILE*)
 *
 * Description:
 *  Dump the overflow page.
 *
 * Returns:
 *  Error code
 *    some errors caused by function calls
 */
Four mlgf_DumpOverflowPage(
	Two					mlgfd,			/* IN MLGF file descriptor */
    PageID              *pid,           /* IN PageID of a overflow page */
	Boolean				recordOnly,			/* IN whether to dump records only in the bulk export format */
	FILE				*fd)			/* OUT output file descriptor */
{
    Four                e;              /* error code */
    Four                i;              /* index variable */
	Four				currentOffset;	/* offset of current object */
    Two                 objectItemLen;  /* the length of an object item in object array */
    char                *objectItemPtr; /* pointer to an object item in object array */
	MLGF_KeyDesc		kdesc;			/* key descriptor of MLGF */
    mlgf_OverflowPage   *apage;         /* pointer to buffer for the overflow page */
#ifndef MBR_MLGF_BUFFER
    mlgf_OverflowPage   apageBuf;		/* buffer for the overflow page */

	apage = &apageBuf;
#endif  /* MBR_MLGF_BUFFER */

	kdesc.flag = OPENFILE_CONTROL(mlgfd).flag;
	kdesc.nKeys = OPENFILE_CONTROL(mlgfd).numOfKeys;
	kdesc.objMaxLen = OPENFILE_CONTROL(mlgfd).objMaxLen;
	kdesc.minMaxTypeVector = OPENFILE_CONTROL(mlgfd).minMaxTypeVector;

#ifdef MBR_MLGF_BUFFER
    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), pid, (char**)&apage);
    if (e < 0) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, *pid, (char*)apage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    if (!(apage->hdr.type & MLGF_OVERFLOWPAGE)) {

	fprintf(fd, "Overflow Page Expected!!!\n");

#ifdef MBR_MLGF_BUFFER
	e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), pid);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	return(eNOERROR);
    }

	if(!recordOnly)
	{
		fprintf(fd, " Dump overflow page : total records %d\n", apage->hdr.nObjects);
	}

	/* print all the records */
	currentOffset = 0;
    for (i = 0; i < apage->hdr.nObjects; i++) {
		objectItemPtr = &apage->data[currentOffset];;
		 objectItemLen = mlgf_leafEntryObjectItemLen(mlgfd,((Object*)objectItemPtr));

		if(!recordOnly)
        	fprintf(fd, "   Record %d : ", i);

		/* print data */
		mlgf_DumpObjectItem(mlgfd, objectItemPtr, recordOnly, fd);

		/* Points to the next object */
		currentOffset += objectItemLen;
    }


#ifdef MBR_MLGF_BUFFER
    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), pid);
    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    return(eNOERROR);

} /* mlgf_DumpOverflowPage() */



/*
 * Function: void mlgf_DumpDirectoryEntry(mlgf_DirectoryEntry*, One, FILE*)
 *
 * Description:
 *  Dump the given directory entry.
 *
 * Returns:
 *  None
 */
void mlgf_DumpDirectoryEntry(
    mlgf_DirectoryEntry *entry,         /* IN entry to dump */
    One                 nKeys,          /* IN # of keys of this index */
	FILE				*fd)			/* OUT output file descriptor */
{
    One                 k;              /* index variable */
    MLGF_HashValue      *hashValuePtr;  /* starting offset of array of hash values */

    hashValuePtr = MLGF_DIRENTRY_HASHVALUEPTR(entry, nKeys);

    for (k = 0; k < nKeys; k++) {
		fprintf(fd, "|\t%d-th Hash Value", k);
		fprintf(fd, "|    valid bit %2d", entry->nValidBits[k]);
		fprintf(fd, "|    hash value %.8X", hashValuePtr[k]);
		fprintf(fd, "\n");
    }

} /* mlgf_DumpDirectoryEntry() */



/*
 * Function: void mlgf_DumpLeafEntry(mlgf_LeafEntry*, MLGF_KeyDesc*, Boolean, FILE*)
 *
 * Description:
 *  Dump the given leaf entry.
 *
 * Returns:
 *  None
 */
void mlgf_DumpLeafEntry(
	Two					mlgfd,			/* IN MLGF file descriptor */
    mlgf_LeafEntry      *entry,         /* IN entry to dump */
    MLGF_KeyDesc        *kdesc,         /* IN key descriptor of used index */
	Boolean				recordOnly,		/* IN whether to dump records only in the bulk export format */
	FILE				*fd)			/* OUT output file descriptor */
{
    Two                 i, k, j;		/* index variable */
    char                *objectItemPtr; /* points to an object item in object array */
    char                *data;          /* points to the data of object */


	if(!recordOnly)
	{
		fprintf(fd, "nRecords %d\n", mlgf_leafGetNObjects(mlgfd,entry));
	}

	/* Points to the first record of the current entry. */
	objectItemPtr = MLGF_LEAFENTRY_FIRST_OBJECT(OPENFILE_CONTROL(mlgfd).useAdditionalFunc,kdesc->nKeys, entry);

	for(i=0; i<mlgf_leafGetNObjects(mlgfd,entry); i++) {
		if(!recordOnly)
			fprintf(fd, "   Record %d : ", i);

		/* print the record */
		(void) mlgf_DumpObjectItem(mlgfd, objectItemPtr, recordOnly, fd);

		/* Points to the next record. */
		objectItemPtr += mlgf_leafEntryObjectItemLen(mlgfd,((Object*)objectItemPtr));
	}
} /* mlgf_DumpLeafEntry() */



/*
 * Function: void mlgf_DumpObjectItem(Two, char*, Boolean, FILE*)
 *
 * Description:
 *  Dump the given object item.
 *
 * Returns:
 *  None
 */
void mlgf_DumpObjectItem(
	Two					mlgfd,				/* IN MLGF file descriptor */
    char                *objectItemPtr,		/* IN pointer to an object item */
	Boolean				recordOnly,			/* IN whether to dump records only in the bulk export format */
	FILE				*fd)				/* OUT output file descriptor */
{
    Two                 i, j;				/* index variable */
	Two					attributeLength;	/* length of attribute */
    char                *data;          	/* points to the data of object */
	int					intVal;				/* integer value */
	float				floatVal;			/* floating-point value */
	Two					loc;

	/* dump the content of record */
	if(!recordOnly)
		fprintf(fd, "( ");

	if ( OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
		loc = sizeof(Two);
	else
		loc = 0;

	data = &((Object*)objectItemPtr)->data[loc];
	
	for(i=0; i<OPENFILE_CONTROL(mlgfd).numOfAttrs; i++) {
		if(i != 0) {
			if(!recordOnly)
				fprintf(fd, ",");
			else
				fprintf(fd, "\n");
		}

		/* dump the content of each attribute */
		switch(OPENFILE_CONTROL(mlgfd).attrType[i].dataType)
		{
			case INT:
				attributeLength = OPENFILE_CONTROL(mlgfd).attrType[i].length;
				memcpy((char*)&intVal, (char*)data, attributeLength);
				fprintf(fd, "%d", intVal);
				break;
			case FLOAT:
				attributeLength = OPENFILE_CONTROL(mlgfd).attrType[i].length;
				memcpy((char*)&floatVal, (char*)data, attributeLength);
				fprintf(fd, "%f", floatVal);
				break;
			case STRING:
				attributeLength = OPENFILE_CONTROL(mlgfd).attrType[i].length;
				fprintf(fd, "\"");
				for(j=0; j<attributeLength; j++)
				{
					if (isprint(data[j]))
						fprintf(fd, "%c", data[j]);
					else
						fprintf(fd, "~");
				}
				fprintf(fd, "\"");
				break;
			case VARSTRING:
				memcpy((char*)&attributeLength, (char*)data, sizeof(Two));
				data += sizeof(Two);
				fprintf(fd, "\"");
				for(j=0; j<attributeLength; j++)
				{
					if (isprint(data[j]))
						fprintf(fd, "%c", data[j]);
					else
						fprintf(fd, "~");
				}
				fprintf(fd, "\"");
				break;
		}
		data += attributeLength;
	}
	if(!recordOnly)
		fprintf(fd, " )\n");
	else
		fprintf(fd, "\n\n");

} /* mlgf_DumpLeafEntry() */
