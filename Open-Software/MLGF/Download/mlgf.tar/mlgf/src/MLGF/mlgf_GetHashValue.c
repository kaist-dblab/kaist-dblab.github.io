/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_GetHashValue.c
 *
 * Description:
 *  Get hash value.
 *
 * Exports:
 *  Four mlgf_GetHashValue(Two, AttributeHeader[], MLGF_HashValue[])
 *  void mlgf_GetHashValueForRangeQuery(Two, QueryRegion[], MLGF_HashValue[], MLGF_HashValue[])
 *
 * Returns:
 *  Error code
 *	  eBADPARAMETER
 */


#include	"common.h"


/* Internal Function Prototype */
MLGF_HashValue mlgf_HashFloatNumber(float*);


/*
 * Function: Four mlgf_GetHashValue(Two, AttributeHeader[], MLGF_HashValue[])
 *
 * Description:
 *  Get hash value.
 *
 * Returns:
 *  Error code
 *	  eBADPARAMETER
 */
Four mlgf_GetHashValue(
	Two		attributeType,		/* IN attribute type */
	AttributeHeader	*attrValue,	/* IN value of the attribute */
	MLGF_HashValue	*hashValue)	/* OUT hash value of the attribute */
{
	switch(attributeType) {
	    case INT :
			/* 
			 * hash value is unsigned long type,
			 * so we make attribute be unsigned long type.
			 */
			*hashValue = (MLGF_HashValue)(*attrValue->field.intPtr) + BIAS;
			break;
	    case FLOAT :
			*hashValue = mlgf_HashFloatNumber(attrValue->field.floatPtr);
			break;
	    case STRING :
	    case VARSTRING:
			*hashValue = 0;
			memcpy((char*)hashValue, (char*)attrValue->field.charPtr, MIN(sizeof(MLGF_HashValue), attrValue->length));
			break;
		default :
			ERR(eBADPARAMETER);
			break;
	}
		
	return(eNOERROR);
}


/*
 * Function: void mlgf_GetHashValueForRangeQuery(Two, QueryRegion[], MLGF_HashValue[], MLGF_HashValue[])
 *
 * Description:
 *  Get hash value for the range query.
 */
void mlgf_GetHashValueForRangeQuery(
	Two				mlgfd,			/* IN MLGF file descriptor */
	QueryRegion		*region,		/* IN query region */
	MLGF_HashValue	*minHashValues,	/* OUT lower boundary of region */
	MLGF_HashValue	*maxHashValues)	/* OUT upper boundary of region */
{
	Two		i;		/* index */

	/* assign hash values */
	for( i=0; i< NUM_OF_KEYS(mlgfd); i++) {
	    
		if (region[i].fullDomainFlag) {
		        minHashValues[i] = MLGF_HASHVALUE_MIN;
		        maxHashValues[i] = MLGF_HASHVALUE_MAX;
			continue;
		}
		
		switch( OPENFILE_CONTROL(mlgfd).attrType[i].dataType) {
		    case INT :
			/* hash value is unsigned long type,
			 * so we make attribute be unsigned long type.
			 */
			minHashValues[i] = (MLGF_HashValue)(*INT_ATTRIBUTE(&region[i].minKey)) + BIAS;
			maxHashValues[i] = (MLGF_HashValue)(*INT_ATTRIBUTE(&region[i].maxKey)) + BIAS;
			break;
		    case FLOAT :
			minHashValues[i] = mlgf_HashFloatNumber(FLOAT_ATTRIBUTE(&region[i].minKey));
			maxHashValues[i] = mlgf_HashFloatNumber(FLOAT_ATTRIBUTE(&region[i].maxKey));
			break;
		    case STRING :
		    case VARSTRING:
			minHashValues[i] = 0;
			memcpy( &minHashValues[i],
				region[i].minKey.field.charPtr,
				MIN(sizeof(MLGF_HashValue), region[i].minKey.length));
			
			maxHashValues[i] = 0;
			memcpy( &maxHashValues[i],
				region[i].maxKey.field.charPtr,
				MIN(sizeof(MLGF_HashValue), region[i].maxKey.length));
			break;
		}
	}
}


/*
 * Function: MLGF_HashValue mlgf_HashFloatNumber(float*)
 *
 * Description:
 *  Hash the given floating-point number into the integer number.
 *  This assumes that the floating-point number is of IEEE-705 format.
 *
 * Returns:
 *  Hash value of float number 
 */
MLGF_HashValue mlgf_HashFloatNumber(
	float	*floatNumber)	/* IN float number */
{    
	union {
	    float f;
	    struct {
		unsigned sign     : 1;
		unsigned exponent : 8;
		unsigned mantissa :23;
	    } encoding;
	    MLGF_HashValue h;
	} hash;

	hash.f = *floatNumber;

	if (hash.f >= 0) {
		hash.encoding.sign = 1;
	} else {
		hash.encoding.sign = 0;
		hash.encoding.exponent = 255 - hash.encoding.exponent;
		hash.encoding.mantissa = 0x007FFFFF - hash.encoding.mantissa;	    
	}

	return hash.h;
}
