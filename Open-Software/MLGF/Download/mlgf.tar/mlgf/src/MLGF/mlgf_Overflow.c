/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_Overflow.c
 *
 * Description :
 *  This file has five functions which are concerned with maintaining overflow
 *  pages. A new overflow page is created when the size of a leaf entry becomes
 *  greater than a third of a page size.  If the member of objects having the
 *  same key value grows more than one page limit, the page should be splitted
 *  by two pages and they are connected by doubly linked list. The deletion
 *  of an object may cause an underflow of an overflow page. If it occurs,
 *  overflow pages may be merged or redistributed.
 */


#include "common.h"


/* Internal Function Prototypes */
Four mlgf_SplitOverflow(Two, PageID*, mlgf_OverflowPage*, MLGF_KeyDesc*);
Four mlgf_OverflowMerge(Two, mlgf_OverflowPage*, mlgf_OverflowPage*);
Four mlgf_OverflowDistribute(mlgf_OverflowPage*, mlgf_OverflowPage*,Two);


/*
 * Function: Four mlgf_CreateOverflow(Two, PageID*, mlgf_LeafPage*, MLGF_KeyDesc*, Two)
 *
 * Description:
 *  This function creates an overflow chain from the given leaf entry.
 *  At first, it allocates a new page and intializes it as an overflow page.
 *  And then, it moves the objects from the leaf entry into the newlly created
 *  overflow page. At the same time, it inserts the given new object into
 *  the overflow page.
 *
 * Returns:
 *  Error code
 *    some errors caused by function calls
 */
Four mlgf_CreateOverflow(
	Two					mlgfd,					/* IN MLGF file descriptor */
    PageID              *root,                  /* IN root page ID */ 
    mlgf_LeafPage       *apage,                 /* INOUT leaf page including the leaf entry */
    MLGF_KeyDesc        *kdesc,                 /* IN key descriptor of MLGF index */
    Two                 entryNo)                /* IN entry to be converted into overflow page */
{
    Four                e;                      /* error number */
    Two                 objectItemLen;          /* length of an object item of object array*/
    char                *firstObjectItem;       /* points to the first object item in object array */
    PageID              newPid;                 /* PageID of the newlly created overflow page */
    mlgf_LeafEntry      *entry;                 /* pointer to the entryNo-th leaf entry */
    mlgf_OverflowPage   *opage;                 /* pointer to the buffer for the overflow page */
#ifndef MBR_MLGF_BUFFER
    mlgf_OverflowPage   opageBuf;				/* buffer for the overflow page */

	opage = &opageBuf;
#endif  /* MBR_MLGF_BUFFER */


    /* Allocat a new page and initialize it as an overflow page. */
	e = mlgf_AllocPage(mlgfd, &newPid);
    if (e < eNOERROR) ERR(e);
    
    /* check this MLGF is temporary */

    /* Read the page into the buffer. */
#ifdef MBR_MLGF_BUFFER
    e = BfM_GetNewPage(OPENFILE_DSMSEGID(mlgfd), &newPid, (char**)&opage);
    if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    /* Initialize the new page as an overflow page. */
    MLGF_INIT_OVERFLOW_PAGE(opage, FALSE, newPid, NIL, NIL, 0);

    /* entry points to the leaf entry which will be converted to the overflow chain. */
    entry = MLGF_ITH_LEAFENTRY(apage, entryNo);

    /* firstObjectItem points to the first object item in the leaf entry. */
    firstObjectItem = MLGF_LEAFENTRY_FIRST_OBJECT(OPENFILE_CONTROL(mlgfd).useAdditionalFunc,kdesc->nKeys, entry);

    /* Move the objects from the leaf entry to the overflow page. */
    memcpy((char*)&opage->data[0], firstObjectItem,mlgf_leafGetTotalObjLen(mlgfd,entry));

	opage->hdr.totalObjLen = mlgf_leafGetTotalObjLen(mlgfd,entry);
    opage->hdr.nObjects =mlgf_leafGetNObjects(mlgfd,entry); 

#ifdef MBR_MLGF_BUFFER
    /* Set dirtyFlag to 1 in order to mark that the overflow page was updated. */
    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &newPid);
    if (e < eNOERROR) ERRB1(e, mlgfd, &newPid);

    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &newPid);
    if (e < eNOERROR) ERR(e);
#else
	e = mlgf_WritePage(mlgfd, newPid, (char*)opage);
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    /* Release space used for the objects. */
    apage->hdr.unused += mlgf_leafGetTotalObjLen(mlgfd,entry) - sizeof(ShortPageID);

    /* The leaf entry has an overflow PageID instead of Object list */
	mlgf_leafSetTotalObjLen(mlgfd,entry,0);
	mlgf_leafSetNObjects(mlgfd,entry,NIL);

    *((ShortPageID*)firstObjectItem) = newPid.pageNo;

    return(eNOERROR);

} /* mlgf_CreateOverflow() */



/*
 * Function: Four mlgf_InsertOverflow(Two, PageID*, PageID*, MLGF_KeyDesc*, MLGF_HashValue*, Object*)
 *
 * Description:
 *  If the ObjectID is greater than the last ObjectID in the given page, get
 *  the nextPage and recursively call itself using the nextPage as long as the
 *  nextPage is not NIL.
 *  If the next page is NIL, append it to the end of the given page.
 *  If the ObjectID is less than the last ObjectID, the object should be
 *  inserted into this page. At first, it find out the correct position to be
 *  inserted using the binary search routine, and then insert it if there is
 *  enough space. If there is not enough space in the given page, split it and
 *  then recursively call itself.
 *
 * Returns:
 *  Error code
 *    eDUPLICATEDRECORD
 *    some errors caused by function calls
 */
Four mlgf_InsertOverflow(
	Two							mlgfd,					/* IN MLGF file descriptor */
    PageID                      *root,                  /* IN root page ID */
    PageID                      *overPid,               /* IN where the object to be inserted */
    MLGF_KeyDesc                *kdesc,                 /* IN key descriptor of this index */
    MLGF_HashValue              keys[],                 /* IN hash values of key values */
	Object						*obj)					/* IN object to insert */
{
    Four                        e;                      /* error number */
	Four						i;						/* idx */
	Two							currentOffset;			/* offset of current object */
	Two							curObjLen;				/* length of the current object */
    Two                         objectItemLen;          /* length of an object item in object array */
	Two							dupType;				/* type of duplication */
	PageID						curPage;				/* the current overflow page */
    PageID                      nextPage;               /* the Next Overflow Page */
	PageID						lastPid;				/* PageID of the last overflow page */
	PageID						insertPid;				/* PageID of page on which to insert the new object */
    mlgf_OverflowPage           *opage;                 /* Page Pointer to the overflow page */
	Object						*objPtr;				/* pointer to an object */
#ifndef MBR_MLGF_BUFFER
    mlgf_OverflowPage   		opageBuf;				/* buffer for the overflow page */

	opage = &opageBuf;
#endif  /* MBR_MLGF_BUFFER */


    /* Get the length of an object item. */
    //objectItemLen = MLGF_LEAFENTRY_OBJECTITEM_LEN(kdesc->extraDataLen);
    objectItemLen = mlgf_leafEntryObjectItemLen(mlgfd,obj);
	/*
	 * Check if the same record already exist.
	 * And also find the page with the enough free space.
	 */
	SET_NILPAGEID(insertPid);
	nextPage = *overPid;
	do {
		curPage = nextPage;
		/* read overflow page */
#ifdef MBR_MLGF_BUFFER
	    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &curPage, (char**)&opage);
	    if (e < eNOERROR) ERR(e);
#else
		e = mlgf_ReadPage(mlgfd, curPage, (char*)opage);
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

		/* Check if the same object already exist. */
		currentOffset = 0;
		for (i = 0; i < opage->hdr.nObjects; i++) {
			objPtr = (Object*)&opage->data[currentOffset];

			curObjLen = mlgf_leafEntryObjectItemLen(mlgfd,objPtr);

			dupType = mlgf_isSameObject(mlgfd,obj,objPtr);
			if(dupType != FALSE) {
#ifdef MBR_MLGF_BUFFER
				e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &curPage);
				if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

				return(dupType);
			}

			/* Points to the next record */
			currentOffset += curObjLen;
		}

		/* The current overflow page has enough space? */
		if(IS_NILPAGEID(insertPid) && MLGF_OP_FREE(opage) >= objectItemLen)
			insertPid = curPage;

		if(IS_NILPAGEID(insertPid) && opage->hdr.nextPage == NIL)
			lastPid = curPage;

		/* Get the PageID of the next overflow page. */
		nextPage.pageNo = opage->hdr.nextPage;
#ifdef MBR_MLGF_BUFFER
		e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &curPage);
		if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
	} while(!IS_NILPAGEID(nextPage));

	if (IS_NILPAGEID(insertPid))
	{
		insertPid = lastPid;

#ifdef MBR_MLGF_BUFFER
		e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &insertPid, (char**)&opage);
		if (e < eNOERROR) ERR(e);
#else
		e = mlgf_ReadPage(mlgfd, insertPid, (char*)opage);
		if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

		for ( ; ; )
		{
			/* Split the overflow page */
        	e = mlgf_SplitOverflow(mlgfd, &insertPid, opage, kdesc);
#ifdef MBR_MLGF_BUFFER
			if (e < eNOERROR) ERRB1(e, mlgfd, insertPid);
#else
			if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

			if (MLGF_OP_FREE(opage) >= objectItemLen) break;

#ifdef MBR_MLGF_BUFFER
			e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &insertPid);
			if (e < eNOERROR) ERR(e);

			insertPid.pageNo = opage->hdr.nextPage;

			e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &insertPid, (char**)&opage);
			if (e < eNOERROR) ERR(e);
#else
			insertPid.pageNo = opage->hdr.nextPage;

			e = mlgf_ReadPage(mlgfd, insertPid, (char*)opage);
			if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
		}
	}
	else
	{
#ifdef MBR_MLGF_BUFFER
		e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &insertPid, (char**)&opage);
		if (e < eNOERROR) ERR(e);
#else
		e = mlgf_ReadPage(mlgfd, insertPid, (char*)opage);
		if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
	}

	/*
	 * store the object into the current overflow page
	 */
	/* Copy the new object */
	memcpy((char*)&opage->data[opage->hdr.totalObjLen], (char*)obj, objectItemLen);

	/* Update the control variables of the overflow page. */
	opage->hdr.totalObjLen += objectItemLen;
	opage->hdr.nObjects++;

#ifdef MBR_MLGF_BUFFER
	e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &insertPid);
	if (e < eNOERROR) ERR(e);

	e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &insertPid);
	if (e < eNOERROR) ERR(e);
#else
	/* write the overflow page into the disk. */
	e = mlgf_WritePage(mlgfd, insertPid, (char*)opage);
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    return(eNOERROR);

} /* mlgf_InsertOverflow() */



/*
 * Function: Four mlgf_DeleteOverflow(Two, PageID*, PageID*, MLGF_KeyDesc*, MLGF_HashValue[], Object*, Four*)
 *
 * Description:
 *  This function deletes the given ObjectID from the overflow pages. If the
 *  ObjectID is in the given overflow page, simply delete it. If not, get the
 *  next page and recursively call itself using the next page. If the page after
 *  deleting is not half full, the page and the neighboring page are merged or
 *  redistributed. After deleting, if there is only one overflow page and its
 *  size is less than a fourth of a page, then 'f' is assigned to the # of
 *  ObjectIDs, otherwise it becomes FALSE.
 *
 * Returns:
 *  Error code
 *    eNOTFOUND_BTM
 *    some errors caused by function calls
 */
Four mlgf_DeleteOverflow(
	Two							mlgfd,					/* IN mlgf file descriptor */
    PageID                      *root,                  /* IN root page ID */
    PageID                      *overPid,               /* IN where the given object will be deleted? */
    MLGF_KeyDesc                *kdesc,                 /* IN key descriptor of used index */
    MLGF_HashValue              keys[],                 /* IN hash values of key values */
	Object						*obj,					/* IN object to delete */
    Four                        *f)                     /* OUT amount of used space if underflow occur otherwise, amount of whole space */
{
    Four                        e;                      /* error number */
    Two                         idx;                    /* nth ObjectID in the overflow page */
    PageID                      prevPid;                /* The previous Page of the Overflow Page */
    PageID                      nextPid;                /* The nextPage of the given overflow page */
    mlgf_OverflowPage           *mpage;                 /* Page Pointer to the neighbor page */
    PageID                      *mpid;                  /* page id of the neighbor page */
    mlgf_OverflowPage           *opage;                 /* Page Pointer to the given overflow page */
    Boolean                     found;                  /* search result */
    mlgf_OverflowPage           *leftPage;              /* left page of between two overflow pages */
    mlgf_OverflowPage           *rightPage;             /* right page of between two overflow pages */
    PageID                      *rightPid;              /* page id of the right page */
    Two                         objectItemLen;          /* length of an object item in object array */
    char                        *objectItemPtr;         /* points to an object item in overflow page */
	Four						objArrayElemOffset;		/* offset on object array */
	Two							objArrayElemNo;			/* index on object array */
#ifndef MBR_MLGF_BUFFER
    mlgf_OverflowPage           mpageBuf;				/* buffer for the neighbor page */
    mlgf_OverflowPage           opageBuf;				/* buffer for the given overflow page */

	mpage = &mpageBuf;
	opage = &opageBuf;
#endif  /* MBR_MLGF_BUFFER */


#ifdef MBR_MLGF_BUFFER
    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), overPid, (char**)&opage);
    if (e < eNOERROR) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, *overPid, (char*)opage);
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    /* Get the length of an object item. */
   objectItemLen = mlgf_leafEntryObjectItemLen(mlgfd,obj);

	found = mlgf_SearchObjectArray(opage->data, obj, opage->hdr.nObjects, &objArrayElemNo, &objArrayElemOffset,mlgfd);

    /* Get the last object in the given overflow page. */

    MAKE_PAGEID(nextPid, overPid->volNo, opage->hdr.nextPage);

    /* Not exist in this page */
	if (!found)	/* Not exist in this page */
	{
#ifdef MBR_MLGF_BUFFER
        e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), overPid);
        if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

        if (IS_NILPAGEID(nextPid)) return(eNOTFOUND);

        /* Recursively delete the object using the next page */
		e = mlgf_DeleteOverflow(mlgfd, root, &nextPid, kdesc, keys, obj, f);
		if (e == eNOTFOUND) return(eNOTFOUND);
		else if( e < eNOERROR ) ERR(e);

        return(eNOERROR);
    }

    /* The deleted object is in this page, if exist. */

    /*@ Search the ObjectID */



	objectItemPtr = (char*)(opage->data + objArrayElemOffset);

    /* Get the previous page id */
    MAKE_PAGEID(prevPid, overPid->volNo, opage->hdr.prevPage);

    /* Delete the ObjectID */

	/* Delete the Object */
	memmove((char*)objectItemPtr, (char*)&objectItemPtr[objectItemLen],
			opage->hdr.totalObjLen - (objArrayElemOffset + objectItemLen));

    /*@ update the variables of the page */
	opage->hdr.totalObjLen -= objectItemLen;
    (opage->hdr.nObjects)--;

    /* Initialize 'f' to the max # of objects in the overflow page. */
    /* Initialize 'f' to the amount of whole space (exept the header) in the overflow page. */
    *f = PAGESIZE-MLGF_OP_FIXED;

    /* Underflow */
    if (opage->hdr.totalObjLen < MLGF_OP_HALF_THRESHOLD)
	{	/* Underflow */

        /*
         * Get the neighbor(= mpid) to merge or redistribute.
         */
        if (nextPid.pageNo == NIL) {
            if (prevPid.pageNo == NIL) /* There is no neighbor. */
                mpid = (PageID*)NULL;
            else /* The previous page is used as the neighbor */
                mpid = &prevPid;
        } else {
            /* The next page is used as the neighbor. */
            mpid = &nextPid;
        }

        /*
         * Merge/Redistriubte the underflowed page with the neighbor.
         */
        if (mpid == NULL) {
            /*
             * If the overflow page is underflow (and there is no
             * neighbor), set 'f' to the amount of used space of objects in 'opage'.
             */
            *f = opage->hdr.totalObjLen;
        } else {

            /* The previous page is used by the neighboring page */
#ifdef MBR_MLGF_BUFFER
            e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), mpid, (char**)&mpage);
            if (e < eNOERROR) ERRB1(e, mlgfd,overPid);
#else
			e = mlgf_ReadPage(mlgfd, *mpid, (char*)mpage);
			if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

            if (mpid->pageNo == prevPid.pageNo) {
                leftPage = mpage;
                rightPage = opage;
                rightPid = overPid;
            } else {
                leftPage = opage;
                rightPage = mpage;
                rightPid = &nextPid;
            }

            if((leftPage->hdr.totalObjLen + rightPage->hdr.totalObjLen) <= PAGESIZE-MLGF_OP_FIXED) {
                /* The sum of the two pages is less than a page size */
                e = mlgf_OverflowMerge(mlgfd, leftPage, rightPage);
#ifdef MBR_MLGF_BUFFER
                if (e < eNOERROR) ERRB2(e, mlgfd, overPid, mpid);
#else
				if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
            } else { /* more than one page size */
#ifdef MBR_MLGF_BUFFER
                if (e < eNOERROR) ERRB2(e, mlgfd, overPid, mpid);
#else
				if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
            }

#ifdef MBR_MLGF_BUFFER
            e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), mpid);
            if (e < eNOERROR) ERRB1(e, mlgfd,overPid);

            e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), mpid);
            if (e < eNOERROR) ERRB1(e, mlgfd, overPid);
#else
			e = mlgf_WritePage(mlgfd, *mpid, (char*)mpage);
			if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */ 
        }
    }

#ifdef MBR_MLGF_BUFFER
    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), overPid);
    if (e < eNOERROR) ERRB1(e, mlgfd, overPid);

    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), overPid);
    if (e < eNOERROR) ERR(e);
#else           
	e = mlgf_WritePage(mlgfd, *overPid, (char*)opage);
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */ 

    return(eNOERROR);

} /* mlgf_DeleteOverflow() */



/*
 * Function: Four mlgf_SplitOverflow(Two, PageID*, mlgf_OverflowPage*, MLGF_KeyDesc*)
 *
 * Description:
 *  This function splits the given overflow page and inserts the given object
 *  into the appropriate overflow page.
 *
 * Returns:
 *  Error code
 *    some errors caused by function calls
 *
 * Note:
 *  The caller should call BfM_SetDirty() for 'fpage'.
 */
Four mlgf_SplitOverflow(
	Two					mlgfd,					/* IN MLGF file descriptor */
    PageID              *root,                  /* IN root page ID */
    mlgf_OverflowPage   *fpage,                 /* INOUT the page which will be splitted */
    MLGF_KeyDesc        *kdesc)                 /* IN key descriptor of used index */
{
    Four                e;                      /* error number */
	Four				i;						/* idx */
	Two					nObjects;				/* number of records in the page */
	Two					currentOffset;			/* starting offset of current object */
	Two					curObjLen;				/* length of the current object */
	Two					newOffset;				/* offset in the new page */
    PageID              newPid;                 /* a new allocated page */
    mlgf_OverflowPage   *npage;                 /* a page pointer to the new/next page */
	Object				*objPtr;				/* pointer to an object */
#ifndef MBR_MLGF_BUFFER
    mlgf_OverflowPage   npageBuf;				/* buffer for the new/next page */

	npage = &npageBuf;
#endif  /* MBR_MLGF_BUFFER */


	/*@ Allocate a new page and initialize it as an overflow page. */
    e = mlgf_AllocPage(mlgfd, &newPid);
    if (e < eNOERROR)  ERR(e);

#ifdef MBR_MLGF_BUFFER
	e = BfM_GetNewPage(OPENFILE_DSMSEGID(mlgfd), &newPid, (char**)&npage);
	if (e < eNOERROR)  ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	/* Initialize the new page to the overflow page. */
    MLGF_INIT_OVERFLOW_PAGE(npage, FALSE, newPid, fpage->hdr.pid.pageNo, fpage->hdr.nextPage, 0);

	/* Find the split boundary. */
	nObjects = fpage->hdr.nObjects;
	currentOffset = 0;
	for (i = 0; i < nObjects && currentOffset < MLGF_OP_HALF_THRESHOLD; i++)
	{
		objPtr = (Object*)&fpage->data[currentOffset];

		curObjLen = mlgf_leafEntryObjectItemLen(mlgfd,objPtr);

		/* points to the next record */
		currentOffset += curObjLen;
	}

	/* Update the old page */
	fpage->hdr.totalObjLen = currentOffset;
	fpage->hdr.nObjects = i;

	/* Copy the other objects of old page into the new page */
	for (newOffset = 0; i < nObjects; i++)
	{
		objPtr = (Object*)&fpage->data[currentOffset];

		curObjLen = mlgf_leafEntryObjectItemLen(mlgfd,objPtr);

		/* Copy the current object into the new page. */
		memcpy((char*)&npage->data[newOffset], (char*)objPtr, curObjLen);

		/* points to the next record */
		currentOffset += curObjLen;
		newOffset += curObjLen;
	}

	/* Update the new page */
	npage->hdr.totalObjLen = newOffset;
	npage->hdr.nObjects = nObjects - fpage->hdr.nObjects;

    /* Update links to maintain doubly linked list */
    fpage->hdr.nextPage = newPid.pageNo;

	/* write the overflow page into the disk. */
#ifdef MBR_MLGF_BUFFER
    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &newPid);
    if (e < eNOERROR) ERRB1(e, mlgfd, &newPid);

    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &newPid);
    if (e < eNOERROR) ERR(e);
#else
	e = mlgf_WritePage(mlgfd, newPid, (char*)npage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    return(eNOERROR);

} /* mlgf_SplitOverflow() */



/*
 * Function: Four mlgf_OverflowMerge(Two, mlgf_OverflowPage*, mlgf_OverflowPage*)
 *
 * Description:
 *  All objects in the right page are copied to the right page.
 *  After the copy is completed, 'nextPage' and 'prevPage' are updated to
 *  maintain doubly linked list. Finally, deallocate the the right page.
 */
Four mlgf_OverflowMerge(
	Two					mlgfd,			/* IN mlgf file descriptor */
    mlgf_OverflowPage   *page1,         /* INOUT page to be copied to */
    mlgf_OverflowPage   *page2)         /* INOUT page to be copied from */
{
    Four                e;              /* error number */
    PageID              nextPid;        /* The next page of page2 */
    mlgf_OverflowPage   *npage;         /* Page Pointer to the overflow page */
#ifndef MBR_MLGF_BUFFER
    mlgf_OverflowPage   npageBuf;		/* buffer for the overflow page */

	npage = &npageBuf;
#endif  /* MBR_MLGF_BUFFER */


    /* Copy the contents of the page2 to the page1 */
	memcpy((char*)&page1->data[page1->hdr.totalObjLen], (char*)page2->data, page2->hdr.totalObjLen);

	page1->hdr.totalObjLen += page2->hdr.totalObjLen;
    page1->hdr.nObjects += page2->hdr.nObjects;

    /* Update links */
    MAKE_PAGEID(nextPid, page2->hdr.pid.volNo, page2->hdr.nextPage);
    page1->hdr.nextPage = nextPid.pageNo;
    if (nextPid.pageNo != NIL) {
#ifdef MBR_MLGF_BUFFER
	e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &nextPid, (char**)&npage);
	if (e < eNOERROR) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, nextPid, (char*)npage);
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	npage->hdr.prevPage = page2->hdr.prevPage;

#ifdef MBR_MLGF_BUFFER
	e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &nextPid);
	if (e < eNOERROR) ERRB1(e, mlgfd, &nextPid);

	e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &nextPid);
	if (e < eNOERROR) ERR(e);
#else
	e = mlgf_WritePage(mlgfd, nextPid, (char*)npage);
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
    }


	e = mlgf_FreePage(mlgfd, page2->hdr.pid);
	if (e < eNOERROR) ERR(e);

    return(eNOERROR);

} /* mlgf_OverflowMerge() */



/*
 * Function: void mlgf_OverflowDistribute(mlgf_OverflowPage*, mlgf_OverflowPage*)
 *
 * Description:
 *  If the size of the left page is larger than the right page, ObjectIDs are
 *  moved from the left page to the right page, otherwise from the right
 *  page to the left page.
 *
 * Returns:
 *  None
 */
Four mlgf_OverflowDistribute(
    mlgf_OverflowPage           *page1,         /* INOUT The left page to be redistributed */
    mlgf_OverflowPage           *page2,         /* INOUT The right page to be redistributed */
    Two				mlgfd)
{
	Two							i;				/* idx */
    Four                        e;              /* error code */
	Four						estMovedBytes;	/* # of estimated moved bytes */
	Four						realMovedBytes;	/* # of real1y moved bytes */
    Four                        nMovedObjects;  /* # of objects to move */
	Four						currentOffset;	/* offset of current object */
	Two							curObjLen;		/* length of the current object */
	Object						*objPtr;		/* pointer to an object */


    if( page1->hdr.totalObjLen > page2->hdr.totalObjLen) {	/* page1 -> page2 */
		/* estimate # of bytes to move */
		estMovedBytes = (page1->hdr.totalObjLen - page2->hdr.totalObjLen)/2;

		/* calc. real # of bytes to move */
		realMovedBytes = page1->hdr.totalObjLen;
		nMovedObjects = page1->hdr.nObjects;
		currentOffset = 0;
		while(1)
		{
			objPtr = (Object*)&page1->data[currentOffset];

			curObjLen = mlgf_leafEntryObjectItemLen(mlgfd,objPtr);

			realMovedBytes -= curObjLen;
			nMovedObjects--;

			/* Points to the next object */
			currentOffset += curObjLen;

			if(nMovedObjects == 0)
			{
				return(eNOERROR);
			}
			else if(realMovedBytes<=estMovedBytes 
					&& realMovedBytes<=MLGF_OP_FREE(page2))
			{
				break;
			}
		}

		/* reserve space in page2 */
		memmove((char*)&page2->data[realMovedBytes], (char*)page2->data, page2->hdr.totalObjLen);

		/* move the objects from page1 to page2 */
		memcpy((char*)page2->data, (char*)&page1->data[currentOffset], realMovedBytes);

		/* update the number of objects in each page */
		page1->hdr.totalObjLen -= realMovedBytes;
		page1->hdr.nObjects -= nMovedObjects;
		page2->hdr.totalObjLen += realMovedBytes;
		page2->hdr.nObjects += nMovedObjects;

    } else {	/* page2 => page1 */
	/*@ number of objects to move */
		/*@ estimate # of bytes to move */
		estMovedBytes = (page2->hdr.totalObjLen - page1->hdr.totalObjLen)/2;

		/* calc. real # of bytes to move */
		realMovedBytes = 0;
		nMovedObjects = 0;
		currentOffset = 0;
		while(1)
		{
			objPtr = (Object*)&page2->data[currentOffset];

			curObjLen = mlgf_leafEntryObjectItemLen(mlgfd,objPtr);

			realMovedBytes += curObjLen;
			nMovedObjects++;

			if(realMovedBytes>estMovedBytes
					|| realMovedBytes>MLGF_OP_FREE(page1))
			{
				realMovedBytes -= curObjLen;
				nMovedObjects--;
				break;
			}

			/* Points to the next object */
			currentOffset += curObjLen;
		}
		if(nMovedObjects == 0)
		{
			return(eNOERROR);
		}

		/* move the objects from page2 to page1 */
		memcpy((char*)&page1->data[page1->hdr.totalObjLen], (char*)page2->data, realMovedBytes);

		/* fill the moved space in page1 */
		memmove((char*)page2->data, (char*)&page2->data[currentOffset], page2->hdr.totalObjLen-realMovedBytes);

		/* update the number of objects in each page */
		page1->hdr.totalObjLen += realMovedBytes;
		page1->hdr.nObjects += nMovedObjects;
		page2->hdr.totalObjLen -= realMovedBytes;
		page2->hdr.nObjects -= nMovedObjects;
    }

    return(eNOERROR);

} /* mlgf_OverflowDistribute() */
