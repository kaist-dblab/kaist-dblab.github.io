/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_SplitDirectoryPage.c
 *
 * Description:
 *  Split a given directory page.
 *
 * Exports:
 *  Four mlgf_SplitDirectoryPage(Two, PageID*, MLGF_KeyDesc*, mlgf_DirectoryEntry*,
 *                               mlgf_DirectoryEntry*, mlgf_DirectoryEntry*)
 *
 * Returns:
 *  Error code
 *    some errors caused by function calls
 */


#include "common.h"


Four mlgf_SplitDirectoryPage(
	Two					mlgfd,					/* MLGF file descriptor */
    PageID              *dirPid,                /* IN page to split */
    MLGF_KeyDesc        *kdesc,                 /* IN key descriptor of used index */
    mlgf_DirectoryEntry *insertedEntry,         /* IN entry to insert */
    mlgf_DirectoryEntry *srcEntry,              /* INOUT entry for original directory page */
    mlgf_DirectoryEntry *dstEntry)              /* OUT entry for new directory page */
{
    Four                e;                      /* error code */
    Boolean             isTmp;
    Two                 i;
    One                 k;                      /* index variable */
    One                 domain;                 /* domain used for split */
    Two                 entryLen;               /* length of a directory entry */
    PageID              newPid;                 /* PageID of the newly allocated page */
    MLGF_HashValue      bitmask;                /* bitmask for region test */
    MLGF_HashValue      *hashValue;             /* domain-th hash value of current entry */
    MLGF_HashValue      insertedHashValue;      /* domain-th hash value of insetedEntry */
    mlgf_DirectoryPage  *dirPage;               /* a original directory page */
    mlgf_DirectoryPage  *newPage;               /* a newly allocated directory page */
    MLGF_HashValue      *extremeHashValues;     /* points to array of extreme(= min or max) hash values within the leaf page */
    MLGF_HashValue      *dirEntryHashValues;    /* points to array of hash values of a directory entry */

#ifndef MBR_MLGF_BUFFER
    mlgf_DirectoryPage  dirPageBuf;				/* buffer for a original directory page */
    mlgf_DirectoryPage  newPageBuf;				/* buffer for a newly allocated directory page */

	dirPage = &dirPageBuf;
	newPage = &newPageBuf;
#endif  /* MBR_MLGF_BUFFER */


#ifdef MBR_MLGF_BUFFER
    /* read directory page from disk */
    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), dirPid, (char**)&dirPage);
    if (e < eNOERROR) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, *dirPid, (char*)dirPage);
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    /* select domain to split */
    mlgf_SplitDirectoryRegion(dirPage, kdesc->nKeys, insertedEntry, srcEntry, dstEntry, &domain);


    /* Allocate a new directory page. */
    e = mlgf_AllocPage(mlgfd, &newPid);
#ifdef MBR_MLGF_BUFFER
    if (e < eNOERROR) ERRB1(e, mlgfd, dirPid);
#else
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
    
    /* check this MLGF is temporary */

#ifdef MBR_MLGF_BUFFER
    /* Read the new page into the buffer. */
    e = BfM_GetNewPage(OPENFILE_DSMSEGID(mlgfd), &newPid, (char**)&newPage);
    if (e < eNOERROR) ERRB1(e, mlgfd, dirPid);
#endif  /* MBR_MLGF_BUFFER */

    /* Initialize the new directory page. */
     MLGF_INIT_DIRECTORY_PAGE(newPage, FALSE, newPid, dirPage->hdr.height, FALSE);


    /* Calculate the length of a directory entry. */
    entryLen = MLGF_DIRENTRY_LENGTH(kdesc->nKeys);

    /* Get bit mask used for dividing the entries into two groups. */
    bitmask = MLGF_HASHVALUE_ITH_BIT_SET(srcEntry->nValidBits[domain]);

    /*
     * Divide the directory page into two direcory page.
     */

    /* hashValue points to the domain-th hash value. */
    hashValue =	MLGF_DIRENTRY_HASHVALUEPTR(MLGF_ITH_DIRENTRY(dirPage, 0, entryLen), kdesc->nKeys) + domain;

    /* Search the split boundary. */
    for (i = 0; i < dirPage->hdr.nEntries; i++) {
	if (*hashValue & bitmask) break;

	hashValue = (MLGF_HashValue*)((char*)hashValue + entryLen);
    }

    /* Move the entries to the new page. */
    memcpy((char*)MLGF_ITH_DIRENTRY(newPage, 0, entryLen),
	   (char*)MLGF_ITH_DIRENTRY(dirPage, i, entryLen),
	   (dirPage->hdr.nEntries-i)*entryLen);
    newPage->hdr.nEntries = dirPage->hdr.nEntries-i;

    dirPage->hdr.nEntries -= newPage->hdr.nEntries;

    /* Insert the new entry, 'insertedEntry'. */

    /* insertedHashValue is the domain-th hash value of the insetedEntry. */
    insertedHashValue = MLGF_DIRENTRY_HASHVALUEPTR(insertedEntry, kdesc->nKeys)[domain];

    if (insertedHashValue & bitmask) /* insert into the new page */
	e = mlgf_InsertIntoDirectory(newPage, kdesc, insertedEntry);
    else			/* insert into the original page */
	e = mlgf_InsertIntoDirectory(dirPage, kdesc, insertedEntry);
#ifdef MBR_MLGF_BUFFER
    if (e < eNOERROR) ERRB2(e, mlgfd, &newPid, dirPid);
#else
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    /* Update the `srcEntry' and `dstEntry'. */
    srcEntry->theta = MLGF_DP_THETA(dirPage, entryLen);
    dstEntry->theta = MLGF_DP_THETA(newPage, entryLen);
    dstEntry->spid = newPid.pageNo;

    /*
    ** Set the MBR of the newPage.
    */
    extremeHashValues = MLGF_DIRENTRY_HASHVALUEPTR(dstEntry, kdesc->nKeys);
    for (k = 0; k < kdesc->nKeys; k++) {
        if (MLGF_KEYDESC_IS_MINTYPE(*kdesc, k))
            extremeHashValues[k] |= MLGF_HASHVALUE_SET_EXCEPT_UPPER_N_BITS(dstEntry->nValidBits[k]);
        else
            extremeHashValues[k] = MLGF_HASHVALUE_MASK_UPPER_N_BITS(extremeHashValues[k], dstEntry->nValidBits[k]);
    }

    dirEntryHashValues = MLGF_DIRENTRY_HASHVALUEPTR(MLGF_ITH_DIRENTRY(newPage, 0, entryLen), kdesc->nKeys);
    for (i = 0; i < newPage->hdr.nEntries; i++) {

	for (k = 0; k < kdesc->nKeys; k++) {

	    if ((MLGF_KEYDESC_IS_MINTYPE(*kdesc, k) && (extremeHashValues[k] > dirEntryHashValues[k])) ||
		(MLGF_KEYDESC_IS_MAXTYPE(*kdesc, k) && (extremeHashValues[k] < dirEntryHashValues[k]))) {
		extremeHashValues[k] = dirEntryHashValues[k];
	    }
	}

	dirEntryHashValues = (MLGF_HashValue*)((char*)dirEntryHashValues + entryLen);
    }

#ifdef MBR_MLGF_BUFFER
    /* Set the dirty flag of the buffer for new page. */
    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &newPid);
    if (e < eNOERROR) ERRB2(e, mlgfd, &newPid, dirPid);
    
    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &newPid);
    if (e < eNOERROR) ERRB1(e, mlgfd, dirPid);
#else
	e = mlgf_WritePage(mlgfd, newPid, (char*)newPage);
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */


    /*
    ** Set the MBR of the dirPage.
    */
    extremeHashValues = MLGF_DIRENTRY_HASHVALUEPTR(srcEntry, kdesc->nKeys);
    for (k = 0; k < kdesc->nKeys; k++) {
	if (MLGF_KEYDESC_IS_MINTYPE(*kdesc, k))
            extremeHashValues[k] |= MLGF_HASHVALUE_SET_EXCEPT_UPPER_N_BITS(srcEntry->nValidBits[k]);
        else
            extremeHashValues[k] = MLGF_HASHVALUE_MASK_UPPER_N_BITS(extremeHashValues[k], srcEntry->nValidBits[k]);
    }


    dirEntryHashValues = MLGF_DIRENTRY_HASHVALUEPTR(MLGF_ITH_DIRENTRY(dirPage, 0, entryLen), kdesc->nKeys);
    for (i = 0; i < dirPage->hdr.nEntries; i++) {

	for (k = 0; k < kdesc->nKeys; k++) {

	    if ((MLGF_KEYDESC_IS_MINTYPE(*kdesc, k) && (extremeHashValues[k] > dirEntryHashValues[k])) ||
		(MLGF_KEYDESC_IS_MAXTYPE(*kdesc, k) && (extremeHashValues[k] < dirEntryHashValues[k]))) {
		extremeHashValues[k] = dirEntryHashValues[k];
	    }
	}

	dirEntryHashValues = (MLGF_HashValue*)((char*)dirEntryHashValues + entryLen);
    }

#ifdef MBR_MLGF_BUFFER
    /* Set the dirty flag of the buffer for original page. */
    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), dirPid);
    if (e < eNOERROR) ERRB1(e, mlgfd, dirPid);

    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), dirPid);
    if (e < eNOERROR) ERR(e);
#else
	e = mlgf_WritePage(mlgfd, *dirPid, (char*)dirPage);
	if (e < eNOERROR) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    return(eNOERROR);

} /* mlgf_SplitDirectoryPage() */
