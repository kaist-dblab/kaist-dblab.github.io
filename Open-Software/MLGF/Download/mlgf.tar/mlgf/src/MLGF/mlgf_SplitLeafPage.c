/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_SplitLeafPage.c
 *
 * Description:
 *  Split a given leaf page.
 *
 * Exports:
 *  Four mlgf_SplitLeafPage(Two, PageID*, MLGF_KeyDesc*, MLGF_HashValue*, Object*, 
 *							mlgf_DirectoryEntry*, mlgf_DirectoryEntry*);
 *
 * Returns:
 *  Error code
 *    some errors caused by function calls
 */


#include "common.h"


Four mlgf_SplitLeafPage(
	Two					mlgfd,					/* MLGF file descriptor */
    PageID              *leafPid,               /* IN page to split */
    MLGF_KeyDesc        *kdesc,                 /* IN key descriptor of used index */
    MLGF_HashValue      keys[],                 /* IN key values of the inserted object */
	Object				*obj,					/* IN object to insert */
    mlgf_DirectoryEntry *srcEntry,              /* INOUT entry for original directory page */
    mlgf_DirectoryEntry *dstEntry)              /* OUT entry for new directory page */
{
    Four                e;                      /* error code */
    Boolean             isTmp;
    Two                 i;
    Two                 j;
    One                 k;                      /* index variable */
    One                 domain;                 /* domain used for split */
    Two                 offset;                 /* points to a position in data area */
    Two                 entryLen;               /* length of a leaf entry */
    PageID              newPid;                 /* PageID of the newly allocated page */
    MLGF_HashValue      bitmask;                /* bitmask for region test */
    mlgf_LeafEntry      *entry;                 /* a leaf entry */
    mlgf_LeafPage       *leafPage;              /* a original leaf page */
    mlgf_LeafPage       *newPage;               /* a newly allocated leaf page */
    MLGF_HashValue      *extremeHashValues;     /* points to array of extreme(= min or max) hash values within the leaf page */
#ifndef MBR_MLGF_BUFFER
    mlgf_LeafPage       leafPageBuf;			/* buffer for a original leaf page */
    mlgf_LeafPage       newPageBuf;				/* buffer for a newly allocated leaf page */

	leafPage = &leafPageBuf;
	newPage = &newPageBuf;
#endif  /* MBR_MLGF_BUFFER */


    /* read leaf page from disk */
#ifdef MBR_MLGF_BUFFER
    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), leafPid, (char**)&leafPage);
    if (e < 0) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, *leafPid, (char*)leafPage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    /* select domain to split */
    mlgf_SplitLeafRegion(leafPage, kdesc, keys, srcEntry, dstEntry, &domain);


    /* Allocate a new leaf page. */
	e = mlgf_AllocPage(mlgfd, &newPid);
#ifdef MBR_MLGF_BUFFER
    if (e < 0) ERRB1(e, mlgfd, leafPid);
#else
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    /* check this MLGF is temporary */

    /* Read the new page into the buffer. */
#ifdef MBR_MLGF_BUFFER
    e = BfM_GetNewPage(OPENFILE_DSMSEGID(mlgfd), &newPid, (char**)&newPage);
    if (e < 0) ERRB1(e, mlgfd, leafPid);
#endif  /* MBR_MLGF_BUFFER */

    /* Initialize the new leaf page. */
    MLGF_INIT_LEAF_PAGE(newPage, FALSE, newPid);


    /* Get bit mask used for dividing the entries into two groups. */
    bitmask =  MLGF_HASHVALUE_ITH_BIT_SET(srcEntry->nValidBits[domain]);

    /*
     * Divide the leaf page into two direcory page.
     */
    /* Search the split boundary. */
    for (i = 0; i < leafPage->hdr.nEntries; i++) {
	entry = MLGF_ITH_LEAFENTRY(leafPage, i);

	if (entry->keys[domain] & bitmask) break;
    }

    newPage->hdr.nEntries = leafPage->hdr.nEntries-i;

    /* Move the entries to the new page. */
    for (offset = 0, j = 0; i < leafPage->hdr.nEntries; i++, j++) {

	entry = MLGF_ITH_LEAFENTRY(leafPage, i);
	 entryLen = MLGF_LEAFENTRY_LENGTH(OPENFILE_CONTROL(mlgfd).useAdditionalFunc,kdesc->nKeys, mlgf_leafGetTotalObjLen(mlgfd,entry),mlgf_leafGetNObjects(mlgfd,entry));
	memcpy(&newPage->data[offset], (char*)entry, entryLen);

	newPage->slot[-j] = offset;
	offset += entryLen;
    }

    newPage->hdr.free = offset;

    leafPage->hdr.unused += offset;
    leafPage->hdr.nEntries -= newPage->hdr.nEntries;

    /* Update the `srcEntry' and `dstEntry'. */
    srcEntry->theta = MLGF_LP_THETA(leafPage);
    dstEntry->theta = MLGF_LP_THETA(newPage);
    dstEntry->spid = newPid.pageNo;


    /*
    ** Set the MBR of the newPage.
    */
    extremeHashValues = MLGF_DIRENTRY_HASHVALUEPTR(dstEntry, kdesc->nKeys);
    for (k = 0; k < kdesc->nKeys; k++) {
	if (MLGF_KEYDESC_IS_MINTYPE(*kdesc, k))
            extremeHashValues[k] |= MLGF_HASHVALUE_SET_EXCEPT_UPPER_N_BITS(dstEntry->nValidBits[k]);
        else
            extremeHashValues[k] = MLGF_HASHVALUE_MASK_UPPER_N_BITS(extremeHashValues[k], dstEntry->nValidBits[k]);
    }

    for (i = 0; i < newPage->hdr.nEntries; i++) {
	entry = MLGF_ITH_LEAFENTRY(newPage, i);

	for (k = 0; k < kdesc->nKeys; k++) {

	    if ((MLGF_KEYDESC_IS_MINTYPE(*kdesc, k) && (extremeHashValues[k] > entry->keys[k])) ||
		(MLGF_KEYDESC_IS_MAXTYPE(*kdesc, k) && (extremeHashValues[k] < entry->keys[k]))) {
		extremeHashValues[k] = entry->keys[k];
	    }
	}
    }


#ifdef MBR_MLGF_BUFFER
    /* Set the dirty flag of the buffer for new page. */
    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &newPid);
    if (e < 0) ERRB2(e, mlgfd, &newPid, leafPid);
    
    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &newPid);
    if (e < 0) ERRB1(e, mlgfd, leafPid);
#else       
	e = mlgf_WritePage(mlgfd, newPid, (char*)newPage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */


    /*
    ** Set the MBR of the leafPage.
    */
    extremeHashValues = MLGF_DIRENTRY_HASHVALUEPTR(srcEntry, kdesc->nKeys);
    for (k = 0; k < kdesc->nKeys; k++) {
	if (MLGF_KEYDESC_IS_MINTYPE(*kdesc, k))
            extremeHashValues[k] |= MLGF_HASHVALUE_SET_EXCEPT_UPPER_N_BITS(srcEntry->nValidBits[k]);
        else
            extremeHashValues[k] = MLGF_HASHVALUE_MASK_UPPER_N_BITS(extremeHashValues[k], srcEntry->nValidBits[k]);
    }

    for (i = 0; i < leafPage->hdr.nEntries; i++) {
	entry = MLGF_ITH_LEAFENTRY(leafPage, i);

	for (k = 0; k < kdesc->nKeys; k++) {

	    if ((MLGF_KEYDESC_IS_MINTYPE(*kdesc, k) && (extremeHashValues[k] > entry->keys[k])) ||
		(MLGF_KEYDESC_IS_MAXTYPE(*kdesc, k) && (extremeHashValues[k] < entry->keys[k]))) {
		extremeHashValues[k] = entry->keys[k];
	    }
	}
    }

#ifdef MBR_MLGF_BUFFER
    /* Set the dirty flag of the buffer for original page. */
    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), leafPid);
    if (e < 0) ERRB1(e, mlgfd, leafPid);
    
    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), leafPid);
    if (e < 0) ERR(e);
#else
	e = mlgf_WritePage(mlgfd, *leafPid, (char*)leafPage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    return(eNOERROR);

} /* mlgf_SplitLeafPage() */
