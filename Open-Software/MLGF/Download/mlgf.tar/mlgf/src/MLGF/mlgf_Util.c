/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_Util.c
 *
 * Description:
 *  Includes various utility functions used in MLGF.
 *
 * Exports:
 *  Boolean mlgf_EqualKeys(MLGF_KeyDesc*, MLGF_HashValue[], MLGF_HashValue[])
 *  Four mlgf_GetObjectFromOverflow(Two, PageID*, MLGF_KeyDesc*, Object*)
 */


#include "common.h"


/*
 * Function: mlgf_EqualKeys(MLGF_KeyDesc*f, MLGF_HashValue[], MLGF_HashValue[])
 *
 * Description:
 *  Compare keys of two objects.
 *
 * Returns:
 *  TRUE if keys of object x are equal to the ones of object y.
 *  FALSE otherwise
 */
Boolean mlgf_EqualKeys(
    MLGF_KeyDesc   *kdesc,	/* IN key descriptor of the given index */
    MLGF_HashValue keys_x[],	/* IN keys of x */
    MLGF_HashValue keys_y[])	/* IN keys of y */
{
    One            k;           /* index variable */


    for (k = 0; k < kdesc->nKeys; k++)
	if (keys_x[k] != keys_y[k]) return(FALSE);

    return(TRUE);

} /* mlgf_EqualKeys() */


/*
 * Function:Four mlgf_GetObjectFromOverflow(Two, PageID*, MLGF_KeyDesc*, Object*)
 *
 * Description:
 *  Get the first object's ObjectID and its extra data of the given overflow
 *  chain.
 *
 * Returns:
 *  Error code
 *    some errors caused by function calls
 */
Four mlgf_GetObjectFromOverflow(
	Two		mlgfd,			/* IN MLGF file descriptor */
    PageID *ovPid,		/* IN first page of overflow chain */
    MLGF_KeyDesc *kdesc,	/* IN key descriptor of the given index */
	Object	*obj)			/* OUT returns the first object */
{
    Four e;			/* error code */
    char *objectItem;		/* points to an element in object array */
    mlgf_OverflowPage *opage;	/* an overflow page */
#ifndef MBR_MLGF_BUFFER
    mlgf_OverflowPage opageBuf;	/* buffer for an overflow page */

	opage = &opageBuf;
#endif  /* MBR_MLGF_BUFFER */


#ifdef MBR_MLGF_BUFFER
    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), ovPid, (char**)&opage);
    if (e < 0) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, *ovPid, (char*)opage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    objectItem = opage->data;

	memcpy((char*)obj, (char*)objectItem, mlgf_leafEntryObjectItemLen(mlgfd,((Object*)objectItem)));

#ifdef MBR_MLGF_BUFFER
    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), ovPid);
    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    return(eNOERROR);

} /* mlgf_GetObjectFromOverflow() */
