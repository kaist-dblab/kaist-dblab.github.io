/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <limits.h>


#define	MAX_ATTRIBUTE_LEN	30
#define MAX_N_ATTRIBUTES	10


void genN_Records(FILE *fd, int nRecords);
void genN_Dimensional_Records(FILE *fd, int nDimension);
void genINT_Typed_Records(FILE *fd);
void genFLOAT_Typed_Records(FILE *fd);
void genSTRING_Typed_Records(FILE *fd);
void genVARSTRING_Typed_Records(FILE *fd);
void genVarTyped_Records(FILE *fd);
void genRecordsWithNonOrganizingAttr(FILE *fd, int nRecords);
void genN_INT_Typed_Points(FILE *fd, int nRecords);
void genN_FLOAT_Typed_Points(FILE *fd, int nRecords);
void genN_Regions(FILE *fd, int nRecords);
float normalDist(float mean, float stdev); 


int main()
{
	int		i;		/* index */
	FILE	*fd;	/* output file descriptor */

	/* open the output file */
	fd = fopen("data.dat", "wb");
	if(fd == NULL)
	{
		printf("Output file open failed.\n");
		exit(1);
	}


	/* choose one of following options and comment out others */
	/* generates n records comprising 4 INT type organizing attributes */
	//genN_Records(fd, 100);
	//genN_Records(fd, 1000);
	//genN_Records(fd, 10000);
	//genN_Records(fd, 100000);
	//genN_Records(fd, 1000000);

	/* generates 10000 records comprising n INT type organizing attributes */
	//genN_Dimensional_Records(fd, 2);
	//genN_Dimensional_Records(fd, 4);
	//genN_Dimensional_Records(fd, 8);

	/* generates 10000 records comprising 4 XXX type organizing attributes */
	//genINT_Typed_Records(fd);
	//genFLOAT_Typed_Records(fd);
	//genSTRING_Typed_Records(fd);
	//genVARSTRING_Typed_Records(fd);

	/* generates 10000 records comprising 4 various type organizing attributes */
	//genVarTyped_Records(fd);

	/* generates n records comprising 4 INT type organizing attribute and 1 VARSTRING type normal attribute */
	//genRecordsWithNonOrganizingAttr(fd, 10000);
	//genRecordsWithNonOrganizingAttr(fd, 100000);
	//genRecordsWithNonOrganizingAttr(fd, 1000000);

	/* generates n points comprising 2 INT type organizing attributes and 1 INT type normal attribute */
	//genN_INT_Typed_Points(fd, 10000);
	//genN_INT_Typed_Points(fd, 100000);
	//genN_INT_Typed_Points(fd, 1000000);

	/* generates n points comprising 2 FLOAT type organizing attributes and 1 INT type normal attribute */
	//genN_FLOAT_Typed_Points(fd, 10000);
	//genN_FLOAT_Typed_Points(fd, 100000);
	genN_FLOAT_Typed_Points(fd, 1000000);

	/* generates n regions comprising 4 INT type organizing attributes and 1 INT type normal attribute */
	//genN_Regions(fd, 10000);
	//genN_Regions(fd, 100000);
	//genN_Regions(fd, 1000000);


	/* close the output file */
	fclose(fd);

	return 0;
}

void genN_Records(FILE *fd, int nRecords)
{
	int 	i, j;		/* index */
	int		min, max;	/* min/max value that can be generated */
	int		nDimensions;	/* # of dimensions */
	int		attr[MAX_N_ATTRIBUTES];	/* attribute value generated */

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random number between min and max */
	min = -1000000;
	max = 1000000;		
	nDimensions = 4;
	for(i=0; i<nRecords; i++)
	{
		for(j=0; j<nDimensions; j++)
		{
			if (j==0)
			{
				attr[j] = 1;
			}
			else
			{
			attr[j] = (int)((double)rand()/((double)RAND_MAX+(double)1)*(max-min)+min);
			}
			fprintf(fd, "%d\n", attr[j]);
		}

		fprintf(fd, "\n");
	}
}

void genN_Dimensional_Records(FILE *fd, int nDimensions)
{
	int 	i, j;	/* index */
	int		min, max;	/* min/max value that can be generated */
	int		nRecords;	/* # of records to be generated */
	int		attr[MAX_N_ATTRIBUTES];	/* attribute value generated */

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random number between min and max */
	min = -1000000;
	max = 1000000;		
	nRecords = 10000;
	for(i=0; i<nRecords; i++)
	{
		for(j=0; j<nDimensions; j++)
		{
			attr[j] = (int)((double)rand()/((double)RAND_MAX+(double)1)*(max-min)+min);
			fprintf(fd, "%d\n", attr[j]);
		}

		fprintf(fd, "\n");
	}
}

void genINT_Typed_Records(FILE *fd)
{
	int 	i, j;	/* index */
	int		min, max;	/* min/max value that can be generated */
	int		nRecords;	/* # of records to be generated */
	int		nDimensions;	/* attribute value generated */
	int		attr[MAX_N_ATTRIBUTES];	/* attribute value generated */

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random number between min and max */
	min = -1000000;
	max = 1000000;		
	nRecords = 10000;
	nDimensions = 4;
	for(i=0; i<nRecords; i++)
	{
		for(j=0; j<nDimensions; j++)
		{
			attr[j] = (int)((double)rand()/((double)RAND_MAX+(double)1)*(max-min)+min);
			fprintf(fd, "%d\n", attr[j]);
		}

		fprintf(fd, "\n");
	}
}

void genFLOAT_Typed_Records(FILE *fd)
{
	int 	i, j;	/* index */
	int		min, max;	/* min/max value that can be generated */
	int		nRecords;	/* # of records to be generated */
	int		nDimensions;	/* attribute value generated */
	float	attr[MAX_N_ATTRIBUTES];	/* attribute value generated */

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random number between min and max */
	min = -1000000;
	max = 1000000;		
	nRecords = 10000;
	nDimensions = 4;
	for(i=0; i<nRecords; i++)
	{
		for(j=0; j<nDimensions; j++)
		{
			attr[j] = (float)((double)rand()/((double)RAND_MAX+(double)1)*(max-min)+min);
			fprintf(fd, "%f\n", attr[j]);
		}

		fprintf(fd, "\n");
	}
}

void genSTRING_Typed_Records(FILE *fd)
{
	int 	i, j;	/* index */
	int		min, max;	/* min/max value that can be generated */
	int		nRecords;	/* # of records to be generated */
	int		nDimensions;	/* attribute value generated */
	char	attr[MAX_N_ATTRIBUTES][MAX_ATTRIBUTE_LEN];	/* attribute value generated */

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random number between min and max */
	/* for 4-bytes-length string type */
	min = 4096;	/* 1000 */
	max = 65535;	/* FFFF */
	nRecords = 10000;
	nDimensions = 4;
	for(i=0; i<nRecords; i++)
	{
		for(j=0; j<nDimensions; j++)
		{
			sprintf(attr[j], "%x", (int)((double)rand()/((double)RAND_MAX+(double)1)*(max-min)+min));
			fprintf(fd, "\"%s\"\n", attr[j]);
		}

		fprintf(fd, "\n");
	}
}

void genVARSTRING_Typed_Records(FILE *fd)
{
	int 	i, j, k;	/* index */
	int		minLen, maxLen;	/* min/max length of varstring that can be generated */
	int		nRecords;	/* # of records to be generated */
	int		nDimensions;	/* attribute value generated */
	int		length;		/* length of the varstring */
	char	attr[MAX_N_ATTRIBUTES][MAX_ATTRIBUTE_LEN];	/* attribute value generated */

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random numbers (each number has a value between '0' and 'F') */
	/* for "maxLen"-bytes-max-length varstring type */
	minLen = 1;
	maxLen = 30;
	nRecords = 1000000;
	nDimensions = 4;
	for(i=0; i<nRecords; i++)
	{
		for(j=0; j<nDimensions; j++)
		{
			length = (int)((double)rand()/((double)RAND_MAX+(double)1)*(maxLen-minLen)+minLen);
			for(k=0; k<length; k++)
			{
				/* gen a character by using hexadecimal number '0' ~ 'F' */
				sprintf(&attr[j][k], "%x", (int)((double)rand()/((double)RAND_MAX+(double)1)*(0x15-0x0)+0x0));
			}
			fprintf(fd, "\"%s\"\n", attr[j]);
		}

		fprintf(fd, "\n");
	}
}

void genVarTyped_Records(FILE *fd)
{
	int 	i;	/* index */
	int		min[MAX_N_ATTRIBUTES], max[MAX_N_ATTRIBUTES];	/* min/max value that can be generated */
	int		nRecords;	/* # of records to be generated */
	int		nDimensions;	/* attribute value generated */
	int		attr1;
	float	attr2;
	char	attr3[MAX_ATTRIBUTE_LEN], attr4[MAX_ATTRIBUTE_LEN];

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random number between min and max */
	min[0] = -1000000;
	max[0] = 1000000;		
	min[1] = -1000000;
	max[1] = 1000000;		
	min[2] = 4096;	/* 0x1000 */
	max[2] = 65535;	/* 0xFFFF */
	min[3] = 0;	/* 0x0 */
	max[3] = 1048575;	/* 0xFFFFF */	
	nRecords = 10000;
	nDimensions = 4;
	for(i=0; i<nRecords; i++)
	{
		attr1 = (int)((double)rand()/((double)RAND_MAX+(double)1)*(max[0]-min[0])+min[0]);
		attr2 = (float)((double)rand()/((double)RAND_MAX+(double)1)*(max[1]-min[1])+min[0]);
		sprintf(attr3, "%x", (int)((double)rand()/((double)RAND_MAX+(double)1)*(max[2]-min[2])+min[2]));
		sprintf(attr4, "%x", (int)((double)rand()/((double)RAND_MAX+(double)1)*(max[3]-min[3])+min[3]));

		fprintf(fd, "%d\n%f\n\"%s\"\n\"%s\"\n\n", attr1, attr2, attr3, attr4);
	}
}

void genRecordsWithNonOrganizingAttr(FILE *fd, int nRecords)
{
	int 	i, j, k;	/* index */
	int		min, max;		/* min/max value that can be generated */
	int		minLen, maxLen;	/* min/max length of varstring that can be generated */
	int		nDimensions;	/* attribute value generated */
	int		length;		/* length of the varstring */
	int		organizingAttr[MAX_N_ATTRIBUTES];	/* attribute value generated */
	char	normalAttr[MAX_ATTRIBUTE_LEN];		/* attribute value generated */

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random number between min and max for organizing attributes */
	/* generate random number between '0' and 'F' for a normal attribute */
	/* for "max"-bytes-max-length varstring type */
	min = -1000000;
	max = 1000000;
	minLen = 1;
	maxLen = 30;
	nDimensions = 5;
	for(i=0; i<nRecords; i++)
	{
		for(j=0; j<nDimensions; j++)
		{
			if (j < 4)	// organizing attributre
			{
				organizingAttr[j] = (int)((double)rand()/((double)RAND_MAX+(double)1)*(max-min)+min);
				fprintf(fd, "%d\n", organizingAttr[j]);
			}
			else	// normal attribute
			{
				length = (int)((double)rand()/((double)RAND_MAX+(double)1)*(maxLen-minLen)+minLen);

				for(k=0; k<length; k++)
				{
					/* gen a character by using hexadecimal number '0' ~ 'F' */
					sprintf(&normalAttr[k], "%x", (int)((double)rand()/((double)RAND_MAX+(double)1)*(0x15-0x0)+0x0));
				}

				fprintf(fd, "\"%s\"\n", normalAttr);
			}
		}

		fprintf(fd, "\n");
	}
}

void genN_INT_Typed_Points(FILE *fd, int nRecords)
{
	int		i, j;       /* index */
	int		nDimensions;    /* # of dimensions */
	int		intAttr;    /* normal attribute value generated */
	int		coordinateAttr[MAX_N_ATTRIBUTES];    /* organizing attribute value generated */
	int min, max;   /* min/max value that can be generated */
	int mean, stdev;    /* for normal distribution */

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random number between min and max */
	min = -1000000; // for uniform distribution
	max = 1000000;  // for uniform distribution
	mean = 0;       // for normal distribution
	stdev = 10;     // for normal distribution
	nDimensions = 2;
	for(i=0; i<nRecords; i++)
	{
		for(j=0; j<nDimensions+1; j++)
		{
			if(j < nDimensions)
			{
				coordinateAttr[j] = (int)((double)rand()/((double)RAND_MAX+(double)1)*(max-min)+min);  // for uniform distribution
				//coordinateAttr[j] = normalDist(mean, stdev);       // for normal distribution
				fprintf(fd, "%d\n", coordinateAttr[j]);
			}
			else
			{
				intAttr = (int)((double)rand()/((double)RAND_MAX+(double)1)*(max-min)+min);
				fprintf(fd, "%d\n", intAttr);
			}
		}

		fprintf(fd, "\n");
	}
}

void genN_FLOAT_Typed_Points(FILE *fd, int nRecords)
{
	int 	i, j;		/* index */
	int		nDimensions;	/* # of dimensions */
	int		intAttr;	/* normal attribute value generated */
	float	    floatAttr[MAX_N_ATTRIBUTES];	/* organizing attribute value generated */
	int	min, max;	/* min/max value that can be generated */
	int	mean, stdev;	/* for normal distribution */

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random number between min and max */
	min = -1000000;	// for uniform distribution
	max = 1000000;	// for uniform distribution
	mean = 0;		// for normal distribution
	stdev = 10;		// for normal distribution
	nDimensions = 2;
	for(i=0; i<nRecords; i++)
	{
		for(j=0; j<nDimensions+1; j++)
		{
			if(j < nDimensions)
			{
				floatAttr[j] = (float)((double)rand()/((double)RAND_MAX+(double)1)*(max-min)+min);	// for uniform distribution
				//floatAttr[j] = normalDist(mean, stdev);		// for normal distribution
				fprintf(fd, "%f\n", floatAttr[j]);
			}
			else
			{
				intAttr = (int)((double)rand()/((double)RAND_MAX+(double)1)*(max-min)+min);
				fprintf(fd, "%d\n", intAttr);
			}
		}

		fprintf(fd, "\n");
	}
}

void genN_Regions(FILE *fd, int nRecords)
{
	int 	i, j;		/* index */
	int		nDimensions;	/* # of dimensions */
	int		intAttr;	/* normal attribute value generated */
	int		center;		/* center value of the region */
	int		range;		/* range value of the region */
	int		minValue, maxValue;	/* values to represent the region */
	double	centerMin, centerMax, rangeMin, rangeMax;	/* min/max value that can be generated */

	/* init the seed */
	srand((unsigned)time(NULL));

	/* generate random number between min and max */
	centerMin = (double)-1000000;	// for uniform distribution
	centerMax = (double)1000000;	// for uniform distribution
	rangeMin = (double)1;	// for uniform distribution
	rangeMax = (double)2000000 * (double)0.01;	// for uniform distribution
	nDimensions = 2;
	for(i=0; i<nRecords; i++)
	{
		for(j=0; j<nDimensions+1; j++)
		{
			if(j < nDimensions)
			{
				/* generate the center value */
				center = (int)((double)rand()/((double)RAND_MAX+(double)1)*(centerMax-centerMin)+centerMin);

				/* generate the range value */
				range = (int)((double)rand()/((double)RAND_MAX+(double)1)*(rangeMax-rangeMin)+rangeMin);

				if (center < -1000000 + (range/2)) {
					minValue = -1000000;
				} else {
					minValue = center - (range/2);
				}
				fprintf(fd, "%d\n", minValue);
				if (center > 1000000 - (range/2)) {
					maxValue = 1000000;
				} else {
					maxValue = center + (range/2);
				}
				fprintf(fd, "%d\n", maxValue);
			}
			else
			{
				intAttr = (int)((double)rand()/((double)RAND_MAX+(double)1)*(centerMax-centerMin)+centerMin);
				fprintf(fd, "%d\n", intAttr);
			}
		}

		fprintf(fd, "\n");
	}
}

float normalDist(float mean, float stdev) {
	float r1, r2;

	r1 = (float)((double)rand()/((double)RAND_MAX+(double)1));
	r2 = (float)((double)rand()/((double)RAND_MAX+(double)1));
	return (mean + stdev*cos(2*3.14*r1)*sqrt(-log(r2)));
}
