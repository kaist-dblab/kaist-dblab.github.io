/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include "mlgf.h"
#include <limits.h>


#define MAX_ATTRIBUTE_LEN	360
#define MAX_N_RECORDS_SEARCHED	300

/* Query type definition */
#define NORMAL_QUERY		0
#define	INTERSECT_QUERY		1	/* perform intersect query for corner transformed records with INT type attrs */

/* Choose the query type */
#define QUERY_TYPE		NORMAL_QUERY
//#define QUERY_TYPE		INTERSECT_QUERY

#define ERROR(e, msg)\
{\
	printf("%s : (error code %d) %s\n", msg, e, MLGF_Error(e));\
	exit(1);\
}
#define ERROR_CHECK(e, msg)	if(e < eNOERROR) ERROR(e, msg);


int isIntValue(char *inputStr, int inputStrLen);
int isFloatValue(char *inputStr, int inputStrLen);
int isValidStringValue(char *inputStr, int inputStrLen);


int main(int argc, char *argv[])
{
	int		i, j;	/* index */
	int		e;	/* error code */
	int		flag;	/* flag indicating whether dot(.) character has been processed or not */
	int		nRecords;	/* # of records inserted */
	int		nQueries;	/* # of queries preformed */
	int		start_time, current_time, timeInMilliSeconds, totalTimeElapsed;	/* for response time */
	char	*mlgfFileName;	/* mlgf file name */
	char	*inputDataFileName;	/* input data file name */
	char	inputStr[MAX_ATTRIBUTE_LEN];	/* character string read from the input data file */
	FILE	*fd;	/* input data file descriptor */
	Two		mlgfd;	/* mlgf file descriptor */
	Two		nKeyAttr;	/* # of organizing (key) attributes */
	Two		nAttr;	/* # of attributes */
	AttributeHeader	*records;	/* records searched */
	QueryRegion		queryRegion[MLGF_MAXNUM_ATTRIBUTES];	/* query region */
	struct timeb	start_timevar, current_timevar;	/* for response time */


	/* parse parameters */
	if(argc < 2)
	{
		printf("USAGE : MLGF_Bulk_Query <mlgf file name> <input data file name>\n");
		exit(1);
	}
	else
	{
		mlgfFileName = argv[1];
		inputDataFileName = argv[2];
	}

	printf("### MLGF Bulk Query starts\n");

	/* init MLGF */ 
	e = MLGF_Init(NUM_BUFS);
	ERROR_CHECK(e, "MLGF_Init()");

	/* open the MLGF file */
	e = MLGF_OpenIndex(mlgfFileName, &mlgfd);
	ERROR_CHECK(e, "MLGF_OpenIndex()");

	printf("\n# MLGF file is opend.\n");

	/* get and print out MLGF info. */
	nKeyAttr = MLGF_GetN_KeyAttr(mlgfd);
	nAttr = MLGF_GetN_Attr(mlgfd);
	printf("\t- # of attributes: %d\n", nAttr);
	for(i=0; i<nAttr; i++)
	{
		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				printf("\t- Type of the attr #%d: INT", i+1); 
				queryRegion[i].minKey.length = MLGF_GetAttrLength(mlgfd, i);
				INT_ATTRIBUTE(&(queryRegion[i].minKey)) = (int*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(INT_ATTRIBUTE(&(queryRegion[i].minKey)) == NULL) {
					ERROR(eMEMORYALLOCERR, "malloc");
				}
				queryRegion[i].maxKey.length = MLGF_GetAttrLength(mlgfd, i);
				INT_ATTRIBUTE(&(queryRegion[i].maxKey)) = (int*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(INT_ATTRIBUTE(&(queryRegion[i].maxKey)) == NULL) {
					ERROR(eMEMORYALLOCERR, "malloc");
				}
				break;
			case FLOAT:
				printf("\t- Type of the attr #%d: FLAOT", i+1); 
				queryRegion[i].minKey.length = MLGF_GetAttrLength(mlgfd, i);
				FLOAT_ATTRIBUTE(&(queryRegion[i].minKey)) = (float*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(FLOAT_ATTRIBUTE(&(queryRegion[i].minKey)) == NULL) {
					ERROR(eMEMORYALLOCERR, "malloc");
				}
				queryRegion[i].maxKey.length = MLGF_GetAttrLength(mlgfd, i);
				FLOAT_ATTRIBUTE(&(queryRegion[i].maxKey)) = (float*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(FLOAT_ATTRIBUTE(&(queryRegion[i].maxKey)) == NULL) {
					ERROR(eMEMORYALLOCERR, "malloc");
				}
				break;
			case STRING:
				printf("\t- Type of the attr #%d: STRING(%d)", i+1, MLGF_GetAttrLength(mlgfd, i)); 
				queryRegion[i].minKey.length = MLGF_GetAttrLength(mlgfd, i);
				STRING_ATTRIBUTE(&(queryRegion[i].minKey)) = (char*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(STRING_ATTRIBUTE(&(queryRegion[i].minKey)) == NULL) {
					ERROR(eMEMORYALLOCERR, "malloc");
				}
				queryRegion[i].maxKey.length = MLGF_GetAttrLength(mlgfd, i);
				STRING_ATTRIBUTE(&(queryRegion[i].maxKey)) = (char*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(STRING_ATTRIBUTE(&(queryRegion[i].maxKey)) == NULL) {
					ERROR(eMEMORYALLOCERR, "malloc");
				}
				break;
			case VARSTRING:
				printf("\t- Type of the attr #%d: VARSTRING(%d)", i+1, MLGF_GetAttrLength(mlgfd, i)); 
				queryRegion[i].minKey.length = MLGF_GetAttrLength(mlgfd, i);
				STRING_ATTRIBUTE(&(queryRegion[i].minKey)) = (char*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(STRING_ATTRIBUTE(&(queryRegion[i].minKey)) == NULL) {
					ERROR(eMEMORYALLOCERR, "malloc");
				}
				queryRegion[i].maxKey.length = MLGF_GetAttrLength(mlgfd, i);
				STRING_ATTRIBUTE(&(queryRegion[i].maxKey)) = (char*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(STRING_ATTRIBUTE(&(queryRegion[i].maxKey)) == NULL) {
					ERROR(eMEMORYALLOCERR, "malloc");
				}
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}

		if(i < nKeyAttr)
		{
			printf(" (organizing (key) attr)\n");
		}
		else
		{
			printf("\n");
		}
		queryRegion[i].fullDomainFlag = FALSE;
	}
	printf("\n");

	/* allocate memory to store the records searched */
	records = (AttributeHeader*)malloc(sizeof(AttributeHeader)*MAX_N_RECORDS_SEARCHED*nAttr);
	if (records == NULL) {
		ERROR(eMEMORYALLOCERR, "malloc");
	}
	for (i=0; i<MAX_N_RECORDS_SEARCHED; i++) {
		for (j=0; j<nAttr; j++) {
			switch (MLGF_GetAttrType(mlgfd, j)) {
				case INT:
					INT_ATTRIBUTE(&(records[nAttr*i+j])) = (int*)malloc(MLGF_GetAttrLength(mlgfd, j));
					if (INT_ATTRIBUTE(&(records[nAttr*i+j])) == NULL) {
						ERROR(eMEMORYALLOCERR, "malloc");
					}
					break;
				case FLOAT:
					FLOAT_ATTRIBUTE(&(records[nAttr*i+j])) = (float*)malloc(MLGF_GetAttrLength(mlgfd, j));
					if (FLOAT_ATTRIBUTE(&(records[nAttr*i+j])) == NULL) {
						ERROR(eMEMORYALLOCERR, "malloc");
					}
					break;
				case STRING:
				case VARSTRING:
					STRING_ATTRIBUTE(&(records[nAttr*i+j])) = (char*)malloc(MLGF_GetAttrLength(mlgfd, j));
					if (STRING_ATTRIBUTE(&(records[nAttr*i+j])) == NULL) {
						ERROR(eMEMORYALLOCERR, "malloc");
					}
					break;
				default:
					printf("Wrong attribute type.\n");
					exit(1);
			}
		}
	}

	/* open the input data file */
	fd = fopen(inputDataFileName, "rb");
	if(fd == NULL)
	{
		printf("Input data file open failed.\n");
		exit(1);
	}

	nQueries = 0;
	totalTimeElapsed = 0;
	while(1)
	{
		/* read a record from the input data file */
		for(i=0; i<nAttr; i++)
		{
			memset(inputStr, 0, MAX_ATTRIBUTE_LEN);
			if(fgets(inputStr, MAX_ATTRIBUTE_LEN, fd) == NULL)
			{
				if(i == 0)	/* EOF */
				{
					break;
				}
				else
				{
					printf("Wrong input data file.\n");
					exit(1);
				}
			}
			else if(inputStr[0] == '\n')
			{
				if(i == 0)	/* redundant blank line */
				{
					i--;	/* read a record from the next line */
					continue;
				}
				else
				{
					printf("Wrong input data file.\n");
					exit(1);
				}
			}
			else
			{
				inputStr[strlen(inputStr)-1] = '\0';	/* eleminate '\n' */
			}

			/* check whether the input value is valid or not */
			switch(MLGF_GetAttrType(mlgfd, i))
			{
				case INT:
					if(!isIntValue(inputStr, strlen(inputStr)))	/* wrong input */
					{
						printf("Wrong input data file.\n");
						exit(1);
					}
					else
					{
						*(INT_ATTRIBUTE(&(queryRegion[i].minKey))) = atoi(inputStr);
						*(INT_ATTRIBUTE(&(queryRegion[i].maxKey))) = atoi(inputStr);
					}
					break;
				case FLOAT:
					if(!isFloatValue(inputStr, strlen(inputStr)))	/* wrong input */
					{
						printf("Wrong input data file.\n");
						exit(1);
					}
					else
					{
						*(FLOAT_ATTRIBUTE(&(queryRegion[i].minKey))) = (float)atof(inputStr);
						*(FLOAT_ATTRIBUTE(&(queryRegion[i].maxKey))) = (float)atof(inputStr);
					}
					break;
				case STRING:
					/* eleminate '"' */
					if(inputStr[0] != '"' || inputStr[strlen(inputStr)-1] != '"')	/* wrong input */
					{
						printf("Wrong input data file.\n");
						exit(1);
					}
					else
					{
						inputStr[strlen(inputStr)-1] = '\0';
						strcpy(inputStr, inputStr+1);

						if(strlen(inputStr) != MLGF_GetAttrLength(mlgfd, i) ||
							!isValidStringValue(inputStr, strlen(inputStr)))	/* wrong input */
						{
							printf("Wrong input data file.\n");
							exit(1);
						}
						else
						{
							memcpy(STRING_ATTRIBUTE(&(queryRegion[i].minKey)), inputStr, strlen(inputStr));
							memcpy(STRING_ATTRIBUTE(&(queryRegion[i].maxKey)), inputStr, strlen(inputStr));
						}
					}
					break;
				case VARSTRING:
					/* eleminate '"' */
					if(inputStr[0] != '"' || inputStr[strlen(inputStr)-1] != '"')	/* wrong input */
					{
						printf("Wrong input data file.\n");
						exit(1);
					}
					else
					{
						inputStr[strlen(inputStr)-1] = '\0';
						strcpy(inputStr, inputStr+1);

						if(strlen(inputStr) > MLGF_GetAttrLength(mlgfd, i) ||
							!isValidStringValue(inputStr, strlen(inputStr)))	/* wrong input */
						{
							printf("Wrong input data file.\n");
							exit(1);
						}
						else
						{
							queryRegion[i].minKey.length = strlen(inputStr);
							queryRegion[i].maxKey.length = strlen(inputStr);
							memcpy(STRING_ATTRIBUTE(&(queryRegion[i].minKey)), inputStr, strlen(inputStr));
							memcpy(STRING_ATTRIBUTE(&(queryRegion[i].maxKey)), inputStr, strlen(inputStr));
						}
					}
					break;
				default:
					printf("Wrong input data file.\n");
					exit(1);
			}
		}

		if(i != nAttr)
		{
			if(i == 0)	/* EOF */
			{
				break;
			}
			else
			{
				printf("Wrong input data file.\n");
				exit(1);
			}
		}
		else
		{
			if (QUERY_TYPE == INTERSECT_QUERY) {
				/* perform intersect query for corner transformed records with INT type attributes */
				for(i=0; i<nKeyAttr; i=i+2) {
					*(INT_ATTRIBUTE(&(queryRegion[i].maxKey))) = *(INT_ATTRIBUTE(&(queryRegion[i+1].minKey)));
					*(INT_ATTRIBUTE(&(queryRegion[i+1].minKey))) = *(INT_ATTRIBUTE(&(queryRegion[i].minKey)));
					*(INT_ATTRIBUTE(&(queryRegion[i].minKey))) = INT_MIN;
					*(INT_ATTRIBUTE(&(queryRegion[i+1].maxKey))) = INT_MAX;
				}
			}

			/* get start time */
			ftime(&start_timevar);

			/* search for the records from MLGF */
			nRecords = MLGF_Query(mlgfd, queryRegion, MAX_N_RECORDS_SEARCHED, records);
			if (nRecords == eTOOMANYRECORDS) {
				nRecords = MAX_N_RECORDS_SEARCHED;
				printf("\n# There are more than %d records that satisfies the query region.\n", nRecords);
			}
			else
			{
				ERROR_CHECK(e, "MLGF_Query()");
				nQueries++;
				if (nRecords == 0) {
					printf("# There is no records searched.\n");
				}
			}

			/* get time elapsed */
			ftime(&current_timevar);
			start_time = start_timevar.time * 1000 + start_timevar.millitm;
			current_time = current_timevar.time * 1000 + current_timevar.millitm;
			timeInMilliSeconds = current_time - start_time;

			totalTimeElapsed += timeInMilliSeconds;

			/* read the next record from the input data file */
			memset(inputStr, 0, MAX_ATTRIBUTE_LEN);
			if(fgets(inputStr, MAX_ATTRIBUTE_LEN, fd) == NULL)	/* EOF */
			{
				break;
			}
			else if(inputStr[0] == '\n')
			{
				continue;
			}
			else
			{
				printf("Wrong input data file.\n");
				exit(1);
			}
		}
	}

	printf("\n# Total %d queries are perfromed\n", nQueries);
	printf("  (Total time elapsed: %dms)\n", totalTimeElapsed);

	/* free memory */
	/* free memory */
	for(i=0; i<nKeyAttr; i++)
	{
		if(queryRegion[i].fullDomainFlag == TRUE)	/* search for full domain */
		{
			continue;
		}
		else	/* memory for queryRegion is allocated only when searching for partial domain */
		{
			switch(MLGF_GetAttrType(mlgfd, i))
			{
				case INT:
					free(INT_ATTRIBUTE(&(queryRegion[i].minKey)));
					free(INT_ATTRIBUTE(&(queryRegion[i].maxKey)));
					break;
				case FLOAT:
					free(FLOAT_ATTRIBUTE(&(queryRegion[i].minKey)));
					free(FLOAT_ATTRIBUTE(&(queryRegion[i].maxKey)));
					break;
				case STRING:
				case VARSTRING:
					free(STRING_ATTRIBUTE(&(queryRegion[i].minKey)));
					free(STRING_ATTRIBUTE(&(queryRegion[i].maxKey)));
					break;
				default:
					printf("Wrong attribute type.\n");
					exit(1);
			}
		}
	}
	for(i=0; i<MAX_N_RECORDS_SEARCHED; i++)
	{
		for(j=0; j<nAttr; j++)
		{
			switch(MLGF_GetAttrType(mlgfd, j))
			{
				case INT:
					free(INT_ATTRIBUTE(&(records[nAttr*i+j])));
					break;
				case FLOAT:
					free(FLOAT_ATTRIBUTE(&(records[nAttr*i+j])));
					break;
				case STRING:
				case VARSTRING:
					free(STRING_ATTRIBUTE(&(records[nAttr*i+j])));
					break;
				default:
					printf("Wrong attribute type.\n");
					exit(1);
			}
		}
	}
	free(records);

	/* close the input data file */
	fclose(fd);

	/* close the MLGF file */
	e = MLGF_CloseIndex(mlgfd);
	ERROR_CHECK(e, "MLGF_CloseIndex()");

	printf("\n# MLGF file is closed.\n");

	/* final MLGF */
	e = MLGF_Final();
	ERROR_CHECK(e, "MLGF_Final()");

	printf("\n\n\n### MLGF Bulk Query ends\n");

	return 0;
}

int isIntValue(char *inputStr, int inputStrLen)
{
    int     i;  /* index */

    for(i=0; i<inputStrLen; i++)
    {
        if(inputStr[i] >= '0' && inputStr[i] <='9') /* valid int value */
        {
            continue;
        }
        else if(i == 0 && inputStr[i] == '-' && inputStrLen > 1)    /* valid int value */
        {
            continue;
        }
        else    /* wrong value */
        {
            break;
        }
    }

    if(inputStrLen == 0 || i < inputStrLen)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

int isFloatValue(char *inputStr, int inputStrLen)
{
    int     i;  /* index */
    int     flag;   /* flag indicating whether dot(.) character has been processed or not */

    flag = FALSE;
    for(i=0; i<inputStrLen; i++)
    {
        if(inputStr[i] >= '0' && inputStr[i] <='9') /* valid float value */
        {
            continue;
        }
        else if(i == 0 && inputStr[i] == '-' && inputStrLen > 1)    /* valid float value */
        {
            continue;
        }
        else if(i != 0 && inputStr[i] == '.' && flag == FALSE)  /* valid float value */
        {
            flag = TRUE;
        }
        else    /* wrong value */
        {
            break;
        }
    }

    if(inputStrLen == 0 || i < inputStrLen)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

int isValidStringValue(char *inputStr, int inputStrLen)
{
    int i;  /* index */

    /* check whether the input character string is valid or not */
    for(i=0; i<inputStrLen; i++)
    {
        if((inputStr[i] >= 'a' && inputStr[i] <= 'z') ||
            (inputStr[i] >= 'A' && inputStr[i] <= 'Z') ||
            (inputStr[i] == ' ') ||
            (inputStr[i] >= '0' && inputStr[i] <= '9')) /* valid string valie */
        {
            continue;
        }
        else    /* wrong value */
        {
            break;
        }
    }

    if(inputStrLen == 0 || i < inputStrLen)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}
