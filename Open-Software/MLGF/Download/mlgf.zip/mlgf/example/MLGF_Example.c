/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include "mlgf.h"


#define MAX_INPUT_STRING_LEN	256
#define MAX_ATTRIBUTE_LEN	360
#define MAX_N_RECORDS_SEARCHED	100

#define ERROR(e, msg)\
{\
	printf("%s : (error code %d) %s\n", msg, e, MLGF_Error(e));\
	exit(1);\
}
#define ERROR_CHECK(e, msg)	if(e < eNOERROR) ERROR(e, msg);


static struct timeb start_timevar;


int createMLGF(char *mlgfFileName, Two *mlgfd);
int openMLGF(char *mlgfFileName, Two *mlgfd);
int closeMLGF(Two mlgfd);
int insertRecordIntoMLGF(Two mlgfd);
int deleteRecordFromMLGF(Two mlgfd);
int searchRecordFromMLGF(Two mlgfd);

int isIntValue(char *inputStr, int inputStrLen);
int isFloatValue(char *inputStr, int inputStrLen);
int isValidStringValue(char *inputStr, int inputStrLen);

void resetTimeElapsed();
void getTimeElapsed(int* timeInMilliSeconds);


int main()
{
	int		e;	/* error code */
	int		quitFlag;	/* flag indicating whether quit this program or not */
	int		inputNum;	/* number entered by user */
	char	inputStr[MAX_INPUT_STRING_LEN];	/* character string entered by user */
	char	mlgfFileName[MAX_INPUT_STRING_LEN];	/* name of MLGF */
	char	cmdStr[MAX_INPUT_STRING_LEN];	/* command string used by system() */
	Two		mlgfd;	/* mlgf file descriptor */


	/* init MLGF */
	e = MLGF_Init(NUM_BUFS);
	ERROR_CHECK(e, "MLGF_Init()");

	printf("### MLGF Example Program starts\n");
	printf("Select an MLGF file to use:\n");
	printf("1. Create a new MLGF file\n");
	printf("2. Use an existing MLGF file\n");
	printf(">");

	/* get a number from user to select the menu */
	while(1)
	{
		memset(inputStr, 0, sizeof(inputStr));
		fgets(inputStr, sizeof(inputStr), stdin);
		inputNum = atoi(inputStr);
		
		/* check whether the user input is valid or not */
		if(inputNum < 1 || inputNum > 2)	/* wrong input */
		{
			printf("Wrong input.\n");
			printf(">");
			continue;
		}
		else	/* valid input */
		{
			break;
		}
	}

	switch(inputNum)
	{
		case 1:		/* create a new MLGF file */
			createMLGF(mlgfFileName, &mlgfd);
			break;
		case 2:		/* use an existing MLGF file */
			openMLGF(mlgfFileName, &mlgfd);
			break;
		default:
			printf("Wrong input.\n");
			exit(1);
	}

	while(quitFlag != TRUE)
	{
		quitFlag = FALSE;

		printf("\n\n\n### Use the MLGF operations\n");
		printf("Select the operation:\n");
		printf("1. Insert a new record into MLGF\n");
		printf("2. Delete a record from MLGF\n");
		printf("3. Search for records from MLGF\n");
		printf("4. Dump MLGF\n");
		printf("5. Quit\n");
		printf(">");

		/* get a number from user to select the menu */
		while(1)
		{
			memset(inputStr, 0, sizeof(inputStr));
			fgets(inputStr, sizeof(inputStr), stdin);
			inputNum = atoi(inputStr);

			/* check whether the user input is valid or not */
			if(inputNum < 1 || inputNum > 5)	/* wrong input */
			{
				printf("Wrong input.\n");
				printf(">");
				continue;
			}
			else	/* valid input */
			{
				break;
			}
		}

		switch(inputNum)
		{
			case 1:	/* insert a new record into MLGF */
				insertRecordIntoMLGF(mlgfd);
				break;
			case 2:	/* delete a record from MLGF */
				deleteRecordFromMLGF(mlgfd);
				break;
			case 3:	/* search for records from MLGF */
				searchRecordFromMLGF(mlgfd);
				break;
			case 4:	/* dump MLGF */
				printf("\n\n\n### Dump MLGF: print out all the pages of MLGF\n");
				e = MLGF_Dump(mlgfd, FALSE, stdout);
				ERROR_CHECK(e, "MLGF_Dump()");
				break;
			case 5:	/* quit */
				quitFlag = TRUE;
				break;
			default:
				printf("Wrong input.\n");
				exit(1);
		}
	}

	/* close the MLGF file */
	closeMLGF(mlgfd);

	printf("\n\n\n### MLGF Example Program ends\n");

	/* final MLGF */
	e = MLGF_Final();
	ERROR_CHECK(e, "MLGF_Final()");

	return 0;
}

int createMLGF(char *mlgfFileName, Two *mlgfd)
{
	int		i;	/* index */
	int		e;	/* error code */
	int		inputNum;	/* number entered by user */
	int		inputStrLen;	/* length of character string entered by user */
	char	inputStr[MAX_INPUT_STRING_LEN];	/* character string entered by user */
	One		nKeyAttr;	/* # of organizing (key) attributes */
	One		nAttr;		/* # of attributes */
	MLGF_HashValue	minMaxTypeVector;			/* bit vector of flags indicating MIN/MAX of MBR for each attribute */
	AttributeType	attrType[MLGF_MAXNUM_ATTRIBUTES];	/* type of attribute */
	One			additionalFunc;

	printf("\n\n\n### Create a new MLGF file\n");
	printf("Input the name of the new MLGF file to create:\n");
	printf("(do not use special characters)\n");
	printf(">");

	/* get the name of the new MLGF file to create from user */
	while(1)
	{
		memset(inputStr, 0, sizeof(inputStr));
		fgets(inputStr, sizeof(inputStr), stdin);
		inputStrLen = strlen(inputStr) - 1;	/* length except '\n' */
		inputStr[inputStrLen] = '\0';	/* eleminate '\n' */
		strcpy(mlgfFileName, inputStr);

		/* check whether the user input is valid or not */
		if(!isValidStringValue(mlgfFileName, inputStrLen))	/* wrong input */
		{
			printf("Wrong input.\n");
			printf(">");
			continue;
		}
		else	/* valid input */
		{
			break;
		}
	}


	printf("Select wheter to use additional functionality or not:\n");
    printf("1: Use additional functionality (more storage space is needed)\n");
    printf("  - Allow data records of a variable lengths\n");
    printf("  - Allow data records with a duplicate hash values of organizing(key) attributes\n");
    printf("2: Use only default functionality\n");
    printf(">");

	while(1)
	{
		memset(inputStr,0,sizeof(inputStr));
		fgets(inputStr,sizeof(inputStr),stdin);
		additionalFunc = (Two)atoi(inputStr);

		if ( additionalFunc < 1 || additionalFunc > 2)
		{
			printf("Wrong input.\n");
			printf(">");
			continue;

		}
		else
		{
			if (additionalFunc == 1)
				additionalFunc = TRUE;
			else
				additionalFunc = FALSE;

			break;
		}
	}

	printf("Input the number of organizing (key) attributes:\n");
	printf("(organizing attributes start from attribute #1.)\n");
	printf(">");

	/* get the number of organizing (key) attributes from user */
	while(1)
	{
		memset(inputStr, 0, sizeof(inputStr));
		fgets(inputStr, sizeof(inputStr), stdin);
		nKeyAttr = (Two)atoi(inputStr);

		/* check whether the user input is valid or not */
		if(nKeyAttr < 1 || nKeyAttr > MLGF_MAXNUM_KEYS)	/* wring input */
		{
			printf("Wrong input.\n");
			printf(">");
			continue;
		}
		else	/* valid input */
		{
			break;
		}
	}

	printf("Input the number of attributes of record (including the number of organizing (key) attributes):\n");
	printf(">");

	/* get the number of attributes of record from user */
	while(1)
	{
		memset(inputStr, 0, sizeof(inputStr));
		fgets(inputStr, sizeof(inputStr), stdin);
		nAttr = (Two)atoi(inputStr);

		/* check whether the user input is valid or not */
		if(nAttr < 1 || nAttr < nKeyAttr)	/* wrong input */
		{
			printf("Wrong input.\n");
			printf(">");
			continue;
		}
		else	/* valid input */
		{
			break;
		}
	}

	if ( additionalFunc == 1)
	{
	printf("Input the types of all the attributes:\n");
	for(i=0; i<nAttr; i++)
	{
		printf("Input the type (number) of attribute #%d:\n", i+1);
		printf("(1: INT, 2: FLOAT, 3: STRING, 4: VARSTRING)\n");
		printf(">");

		/* get the type of the attribute from user */
		while(1)
		{
			memset(inputStr, 0, sizeof(inputStr));
			fgets(inputStr, sizeof(inputStr), stdin);
			inputNum = atoi(inputStr);

			/* check whether the user input is valid or not */
			if(inputNum < 1 || inputNum >4)	/* wrong input */
			{
				printf("Wrong input.\n");
				printf(">");
				continue;
			}
			else	/* valid input */
			{
				break;
			}
		}

		if(inputNum == 3 || inputNum == 4)	/* STRING or VARSTRING */
		{
			if(inputNum == 3)
			{
				printf("Input the length (<=%d) of STRING type:\n", MAX_ATTRIBUTE_LEN);
			}
			else if(inputNum == 4)
			{
				printf("Input the max length (<=%d) of VARSTRING type:\n", MAX_ATTRIBUTE_LEN); 
			}
			printf(">");

			/* get the length or max length of STRING or VARSTRING type from user */
			while(1)
			{
				memset(inputStr, 0, sizeof(inputStr));
				fgets(inputStr, sizeof(inputStr), stdin);
				attrType[i].length = (Two)atoi(inputStr);

				/* check whether the user input is valid or not */
				if(attrType[i].length < 1 || attrType[i].length > MAX_ATTRIBUTE_LEN)	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					break;
				}
			}
		}

		switch(inputNum)
		{
			case 1:	/* INT type */
				attrType[i].dataType = INT;
				attrType[i].length = sizeof(int);
				break;
			case 2:	/* FLOAT Type */
				attrType[i].dataType = FLOAT;
				attrType[i].length = sizeof(float);
				break;
			case 3:	/* STRING type */
				attrType[i].dataType = STRING;
				break;
			case 4:	/* VARSTRING type */
				attrType[i].dataType = VARSTRING;
				break;
			default:
				printf("Wrong input.\n");
				break;
		}
	}
	}
	else
	{
			
	printf("Input the types of all the attributes:\n");
	for(i=0; i<nAttr; i++)
	{
		printf("Input the type (number) of attribute #%d:\n", i+1);
		printf("(1: INT, 2: FLOAT, 3: STRING)\n");
		printf(">");

		/* get the type of the attribute from user */
		while(1)
		{
			memset(inputStr, 0, sizeof(inputStr));
			fgets(inputStr, sizeof(inputStr), stdin);
			inputNum = atoi(inputStr);

			/* check whether the user input is valid or not */
			if(inputNum < 1 || inputNum >3)	/* wrong input */
			{
				printf("Wrong input.\n");
				printf(">");
				continue;
			}
			else	/* valid input */
			{
				break;
			}
		}

		if(inputNum == 3 )	/* STRING or VARSTRING */
		{
			if(inputNum == 3)
			{
				printf("Input the length (<=%d) of STRING type:\n", MAX_ATTRIBUTE_LEN);
			}
			printf(">");

			/* get the length or max length of STRING or VARSTRING type from user */
			while(1)
			{
				memset(inputStr, 0, sizeof(inputStr));
				fgets(inputStr, sizeof(inputStr), stdin);
				attrType[i].length = (Two)atoi(inputStr);

				/* check whether the user input is valid or not */
				if(attrType[i].length < 1 || attrType[i].length > MAX_ATTRIBUTE_LEN)	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					break;
				}
			}
		}

		switch(inputNum)
		{
			case 1:	/* INT type */
				attrType[i].dataType = INT;
				attrType[i].length = sizeof(int);
				break;
			case 2:	/* FLOAT Type */
				attrType[i].dataType = FLOAT;
				attrType[i].length = sizeof(float);
				break;
			case 3:	/* STRING type */
				attrType[i].dataType = STRING;
				break;
			default:
				printf("Wrong input.\n");

		}
	}

	}

	printf("Input the types of the extreme hash values of all the organizing (key) attributes:\n");
	for(i=0; i<nKeyAttr; i++)
	{
		printf("Input the type (number) of the extreme hash value of attribute #%d:\n", i+1);
		printf("(1: MIN_HASH_VALUE, 2: MAX_HASH_VALUE)\n");
		printf(">");

		/* get the type of the extreme hash value of the attribute from user */
		while(1)
		{
			memset(inputStr, 0, sizeof(inputStr));
			fgets(inputStr, sizeof(inputStr), stdin);
			inputNum = atoi(inputStr);

			/* check whether the user input is valid or not */
			if(inputNum < 1 || inputNum > 2)	/* wrong input */
			{
				printf("Wrong input.\n");
				printf(">");
				continue;
			}
			else	/* valid input */
			{
				break;
			}
		}

		switch(inputNum)
		{
			case 1:	/* MIN_HASH_TYPE */
				MLGF_KEYDESC_SET_MINTYPE(minMaxTypeVector, i);
				break;
			case 2:	/* MAX_HASH_TYPE */
				MLGF_KEYDESC_SET_MAXTYPE(minMaxTypeVector, i);
				break;
			default:
				printf("Wrong input.\n");
				break;
		}
	}


	/* create a new MLGF file */
	e = MLGF_CreateIndex(mlgfFileName, nKeyAttr, nAttr, attrType, minMaxTypeVector,additionalFunc);
	ERROR_CHECK(e, "MLGF_CreateIndex()");

	/* open the MLGF file created */
	e = MLGF_OpenIndex(mlgfFileName, mlgfd);
	ERROR_CHECK(e, "MLGF_OpenIndex()");

	printf("\n# MLGF file is created and opend.\n");

	/* print out MLGF info */
	printf("\t- # of attributes: %d\n", nAttr);
	for(i=0; i<nAttr; i++)
	{
		switch(MLGF_GetAttrType(*mlgfd, i))
		{
			case INT:
				printf("\t- Type of the attr #%d: INT", i+1);
				break;
			case FLOAT:
				printf("\t- Type of the attr #%d: FLAOT", i+1);
				break;
			case STRING:
				printf("\t- Type of the attr #%d: STRING(%d)", i+1, MLGF_GetAttrLength(*mlgfd, i));
				break;
			case VARSTRING:
				printf("\t- Type of the attr #%d: VARSTRING(%d)", i+1, MLGF_GetAttrLength(*mlgfd, i));
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}

		if(i < nKeyAttr)
		{
			printf(" (organizing (key) attr)\n");
		}
		else
		{
			printf("\n");
		}
	}

	return 0;
}

int openMLGF(char *mlgfFileName, Two *mlgfd)
{
	int		i;	/* index */
	int		e;	/* error code */
	int		inputNum;	/* number entered by user */
	int		inputStrLen;	/* length of character string entered by user */
	char	inputStr[MAX_INPUT_STRING_LEN];	/* character string entered by user */
	One		nKeyAttr;	/* # of organizing (key) attributes */
	One		nAttr;		/* * of attributes */


	printf("\n\n\n### Open an existing MLGF file\n");
	printf("Input the name of the MLGF file to open:\n");
	printf("(do not use special characters)\n");
	printf(">");

	/* get the name of the MLGF file to open from user */
	while(1)
	{
		memset(inputStr, 0, sizeof(inputStr));
		fgets(inputStr, sizeof(inputStr), stdin);
		inputStrLen = strlen(inputStr) - 1;	/* length except '\n' */
		inputStr[inputStrLen] = '\0';	/* eleminate '\n' */
		strcpy(mlgfFileName, inputStr);

		/* check whether the user input is valid or not */
		if(!isValidStringValue(mlgfFileName, inputStrLen))	/* wrong input */
		{
			printf("Wrong input.\n");
			printf(">");
			continue;
		}
		else	/* valid input */
		{
			break;
		}
	}

	/* open the MLGF file */
	e = MLGF_OpenIndex(mlgfFileName, mlgfd);
	ERROR_CHECK(e, "MLGF_OpenIndex()");

	printf("\n# MLGF file is opend.\n");

	/* print out MLGF info */
	nKeyAttr = MLGF_GetN_KeyAttr(*mlgfd);
	nAttr = MLGF_GetN_Attr(*mlgfd);
	printf("\t- # of attributes: %d\n", nAttr);
	for(i=0; i<nAttr; i++)
	{
		switch(MLGF_GetAttrType(*mlgfd, i))
		{
			case INT:
				printf("\t- Type of the attr #%d: INT", i+1);
				break;
			case FLOAT:
				printf("\t- Type of the attr #%d: FLAOT", i+1);
				break;
			case STRING:
				printf("\t- Type of the attr #%d: STRING(%d)", i+1, MLGF_GetAttrLength(*mlgfd, i));
				break;
			case VARSTRING:
				printf("\t- Type of the attr #%d: VARSTRING(%d)", i+1, MLGF_GetAttrLength(*mlgfd, i));
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}

		if(i < nKeyAttr)
		{
			printf(" (organizing (key) attr)\n");
		}
		else
		{
			printf("\n");
		}
	}

	return 0;
}

int closeMLGF(Two mlgfd)
{
	int		e;

	/* close the MLGF file */
	e = MLGF_CloseIndex(mlgfd);
	ERROR_CHECK(e, "MLGF_CloseIndex()");

	printf("\n# MLGF file is closed.\n");

	return 0;
}

int insertRecordIntoMLGF(Two mlgfd)
{
	int		i;	/* index */
	int		e;	/* error code */
	int		timeInMilliSeconds;	/* for response time */
	int		inputNum;	/* number entered by user */
	int		inputStrLen;	/* length of character string entered by user */
	float	inputRealNum;	/* real number entered by user */
	char	inputStr[MAX_INPUT_STRING_LEN];	/* character string entered by user */
	One		nAttr;		/* # of attributes */
	AttributeHeader	attr[MLGF_MAXNUM_ATTRIBUTES];	/* attribute values */

	/* get the number of attributes of record */
	nAttr = MLGF_GetN_Attr(mlgfd);

	printf("\n\n\n### Insert a new record into MLGF\n");
	printf("Input all the attribute values:\n");

	for(i=0; i<nAttr; i++)
	{
		printf("Input the value of attribute #%d:\n", i+1);
		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				printf("(Type of attribute #%d: INT)\n", i+1);
				break;
			case FLOAT:
				printf("(Type of attribute #%d: FLOAT)\n", i+1);
				break;
			case STRING:
				printf("(Type of attribute #%d: STRING(%d))\n", i+1, MLGF_GetAttrLength(mlgfd, i));
				break;
			case VARSTRING:
				printf("(Type of attribute #%d: VARSTRING(%d))\n", i+1, MLGF_GetAttrLength(mlgfd, i));
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}
		printf(">");

		/* get the value of the attribute from user */
		while(1)
		{
			memset(inputStr, 0, sizeof(inputStr));
			fgets(inputStr, sizeof(inputStr), stdin);
			inputStrLen = strlen(inputStr) - 1; /* length except '\n' */
			inputStr[inputStrLen] = '\0';   /* eleminate '\n' */
	
			/* check whether the user input value is valid or not */
			if(MLGF_GetAttrType(mlgfd, i) == INT)
			{
				if(!isIntValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					inputNum = atoi(inputStr);
					break;
				}
			}
			else if(MLGF_GetAttrType(mlgfd, i) == FLOAT)
			{
				if(!isFloatValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					inputRealNum = (float)atof(inputStr);
					break;
				}
			}
			else if(MLGF_GetAttrType(mlgfd, i) == STRING || MLGF_GetAttrType(mlgfd, i) == VARSTRING)
			{
				if((MLGF_GetAttrType(mlgfd, i) == STRING && inputStrLen != MLGF_GetAttrLength(mlgfd, i)) || inputStrLen > MLGF_GetAttrLength(mlgfd, i) || !isValidStringValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					break;
				}
			}
			else
			{
				printf("Wrong attribute type.\n");
				exit(1);
			}
		}

		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				ATTRIBUTE_LENGTH(&(attr[i])) = MLGF_GetAttrLength(mlgfd, i); 
				INT_ATTRIBUTE(&(attr[i])) = (int*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(INT_ATTRIBUTE(&(attr[i])) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "insertRecordIntoMLGF");
				}
				*(INT_ATTRIBUTE(&(attr[i]))) = inputNum;
				break;
			case FLOAT:
				ATTRIBUTE_LENGTH(&(attr[i])) = MLGF_GetAttrLength(mlgfd, i); 
				FLOAT_ATTRIBUTE(&(attr[i])) = (float*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(FLOAT_ATTRIBUTE(&(attr[i])) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "insertRecordIntoMLGF");
				}
				*(FLOAT_ATTRIBUTE(&(attr[i]))) = inputRealNum;
				break;
			case STRING:
				ATTRIBUTE_LENGTH(&(attr[i])) = MLGF_GetAttrLength(mlgfd, i); 
				STRING_ATTRIBUTE(&(attr[i])) = (char*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(STRING_ATTRIBUTE(&(attr[i])) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "insertRecordIntoMLGF");
				}
				memcpy(STRING_ATTRIBUTE(&(attr[i])), inputStr, MLGF_GetAttrLength(mlgfd, i));
				break;
			case VARSTRING:
				ATTRIBUTE_LENGTH(&(attr[i])) = inputStrLen; 
				STRING_ATTRIBUTE(&(attr[i])) = (char*)malloc(inputStrLen);
				if(STRING_ATTRIBUTE(&(attr[i])) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "insertRecordIntoMLGF");
				}
				memcpy(STRING_ATTRIBUTE(&(attr[i])), inputStr, inputStrLen);
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}
	}

	/* insert the record into MLGF */
	resetTimeElapsed();
	e = MLGF_InsertObject(mlgfd, attr);
	if(e == eDUPLICATEDRECORD)
	{
		printf("\n# Record to be inserted is duplicated.\n");
	}
	else if ( e == eDUPLICATEDKEY)
	{
		printf("\n# Hashed key to be inserted is duplicated.\n");
	}
	else
	{
		ERROR_CHECK(e, "MLGF_InsertObject()");
		printf("\n# Record is inserted into MLGF.\n");
	}
	getTimeElapsed(&timeInMilliSeconds);
	printf("  (Time elapsed: %dms)\n", timeInMilliSeconds);

	/* free memory */
	for(i=0; i<nAttr; i++)
	{
		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				free(INT_ATTRIBUTE(&(attr[i])));
				break;
			case FLOAT:
				free(FLOAT_ATTRIBUTE(&(attr[i])));
				break;
			case STRING:
			case VARSTRING:
				free(STRING_ATTRIBUTE(&(attr[i])));
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}
	}

	return 0;
}

int deleteRecordFromMLGF(Two mlgfd)
{
	int		i;	/* index */
	int		e;	/* error code */
	int		timeInMilliSeconds;	/* for response time */
	int		inputNum;	/* number entered by user */
	int		inputStrLen;	/* length of character string entered by user */
	float	inputRealNum;	/* real number entered by user */
	char	inputStr[MAX_INPUT_STRING_LEN];	/* character string entered by user */
	Two		nAttr;		/* # of attributes */
	AttributeHeader	attr[MLGF_MAXNUM_ATTRIBUTES];	/* attribute values */

	/* get the number of attributes of record */
	nAttr = MLGF_GetN_Attr(mlgfd);

	printf("\n\n\n### Delete a record from MLGF\n");
	printf("Input all the attribute values:\n");

	for(i=0; i<nAttr; i++)
	{
		printf("Input the value of attribute #%d:\n", i+1);
		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				printf("(Type of attribute #%d: INT)\n", i+1);
				break;
			case FLOAT:
				printf("(Type of attribute #%d: FLOAT)\n", i+1);
				break;
			case STRING:
				printf("(Type of attribute #%d: STRING(%d))\n", i+1, MLGF_GetAttrLength(mlgfd, i));
				break;
			case VARSTRING:
				printf("(Type of attribute #%d: VARSTRING(%d))\n", i+1, MLGF_GetAttrLength(mlgfd, i));
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}
		printf(">");

		/* get the value of the attribute from user */
		while(1)
		{
			memset(inputStr, 0, sizeof(inputStr));
			fgets(inputStr, sizeof(inputStr), stdin);
			inputStrLen = strlen(inputStr) - 1; /* length except '\n' */
			inputStr[inputStrLen] = '\0';   /* eleminate '\n' */
	
			/* check whether the user input value is valid or not */
			if(MLGF_GetAttrType(mlgfd, i) == INT)
			{
				if(!isIntValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					inputNum = atoi(inputStr);
					break;
				}
			}
			else if(MLGF_GetAttrType(mlgfd, i) == FLOAT)
			{
				if(!isFloatValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					inputRealNum = (float)atof(inputStr);
					break;
				}
			}
			else if(MLGF_GetAttrType(mlgfd, i) == STRING || MLGF_GetAttrType(mlgfd, i) == VARSTRING)
			{
				if((MLGF_GetAttrType(mlgfd, i) == STRING && inputStrLen != MLGF_GetAttrLength(mlgfd, i)) || inputStrLen > MLGF_GetAttrLength(mlgfd, i) || !isValidStringValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					break;
				}
			}
			else
			{
				printf("Wrong attribute type.\n");
				exit(1);
			}
		}

		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				ATTRIBUTE_LENGTH(&(attr[i])) = MLGF_GetAttrLength(mlgfd, i); 
				INT_ATTRIBUTE(&(attr[i])) = (int*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(INT_ATTRIBUTE(&(attr[i])) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "deleteRecordFromMLGF");
				}
				*(INT_ATTRIBUTE(&(attr[i]))) = inputNum;
				break;
			case FLOAT:
				ATTRIBUTE_LENGTH(&(attr[i])) = MLGF_GetAttrLength(mlgfd, i); 
				FLOAT_ATTRIBUTE(&(attr[i])) = (float*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(FLOAT_ATTRIBUTE(&(attr[i])) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "deleteRecordFromMLGF");
				}
				*(FLOAT_ATTRIBUTE(&(attr[i]))) = inputRealNum;
				break;
			case STRING:
				ATTRIBUTE_LENGTH(&(attr[i])) = MLGF_GetAttrLength(mlgfd, i); 
				STRING_ATTRIBUTE(&(attr[i])) = (char*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(STRING_ATTRIBUTE(&(attr[i])) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "deleteRecordFromMLGF");
				}
				memcpy(STRING_ATTRIBUTE(&(attr[i])), inputStr, MLGF_GetAttrLength(mlgfd, i));
				break;
			case VARSTRING:
				ATTRIBUTE_LENGTH(&(attr[i])) = inputStrLen; 
				STRING_ATTRIBUTE(&(attr[i])) = (char*)malloc(inputStrLen);
				if(STRING_ATTRIBUTE(&(attr[i])) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "deleteRecordFromMLGF");
				}
				memcpy(STRING_ATTRIBUTE(&(attr[i])), inputStr, inputStrLen);
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}
	}

	/* delete the record from MLGF */
	resetTimeElapsed();
	e = MLGF_DeleteObject(mlgfd, attr);
	if(e == eNOTFOUND)
	{
		printf("\n# Record to be deleted is not found.\n");
	}
	else
	{
		ERROR_CHECK(e, "MLGF_DeleteObject()");
		printf("\n# Record is deleted from MLGF.\n");
	}
	getTimeElapsed(&timeInMilliSeconds);
	printf("  (Time elapsed: %dms)\n", timeInMilliSeconds);

	/* free memory */
	for(i=0; i<nAttr; i++)
	{
		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				free(INT_ATTRIBUTE(&(attr[i])));
				break;
			case FLOAT:
				free(FLOAT_ATTRIBUTE(&(attr[i])));
				break;
			case STRING:
			case VARSTRING:
				free(STRING_ATTRIBUTE(&(attr[i])));
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}
	}

	return 0;
}

int searchRecordFromMLGF(Two mlgfd)
{
	int		i, j, k;	/* index */
	int		e;	/* error code */
	int		timeInMilliSeconds;	/* for response time */
	int		inputNum;	/* number entered by user */
	int		inputStrLen;	/* length of character string entered by user */
	int		nRecords;	/* # of records searched */
	float	inputRealNum;	/* real number entered by user */
	char	inputStr[MAX_INPUT_STRING_LEN];	/* character string entered by user */
	Two		nKeyAttr;		/* # of organizing (key) attributes */
	Two		nAttr;		/* # of attributes */
	AttributeHeader	*records;	/* records searched */
	QueryRegion	queryRegion[MLGF_MAXNUM_ATTRIBUTES];	/* query region */


	/* get the number of organizing (key) attributes of record */
	nKeyAttr = MLGF_GetN_KeyAttr(mlgfd);

	/* get the number of attributes of record */
	nAttr= MLGF_GetN_Attr(mlgfd);

	/* allocate memory to store the records searched */
	records = (AttributeHeader*)malloc(sizeof(AttributeHeader)*MAX_N_RECORDS_SEARCHED*nAttr);
	if(records == NULL)
	{
		ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
	}
	for(i=0; i<MAX_N_RECORDS_SEARCHED; i++)
	{
		for(j=0; j<nAttr; j++)
		{
			switch(MLGF_GetAttrType(mlgfd, j))
			{
				case INT:
					INT_ATTRIBUTE(&(records[nAttr*i+j])) = (int*)malloc(MLGF_GetAttrLength(mlgfd, j));
					if(INT_ATTRIBUTE(&(records[nAttr*i+j])) == NULL)
					{
						ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
					}
					break;
				case FLOAT:
					FLOAT_ATTRIBUTE(&(records[nAttr*i+j])) = (float*)malloc(MLGF_GetAttrLength(mlgfd, j));
					if(FLOAT_ATTRIBUTE(&(records[nAttr*i+j])) == NULL)
					{
						ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
					}
					break;
				case STRING:
				case VARSTRING:
					STRING_ATTRIBUTE(&(records[nAttr*i+j])) = (char*)malloc(MLGF_GetAttrLength(mlgfd, j));
					if(STRING_ATTRIBUTE(&(records[nAttr*i+j])) == NULL)
					{
						ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
					}
					break;
				default:
					printf("Wrong attribute type.\n");
					exit(1);
			}
		}
	}

	printf("\n\n\n### Search for records from MLGF\n");
	printf("For all the organizing (key) attributes, input the search range (min, max):\n");
	printf("(the default value is '-', which represents the full domain.)\n");

	/* Specify the query region */
	for(i=0; i<nKeyAttr; i++)
	{
		queryRegion[i].fullDomainFlag = FALSE;

		printf("Input the min value of attribute #%d:\n", i+1);
		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				printf("(Type of attribute #%d: INT)\n", i+1);
				break;
			case FLOAT:
				printf("(Type of attribute #%d: FLOAT)\n", i+1);
				break;
			case STRING:
				printf("(Type of attribute #%d: STRING(%d))\n", i+1, MLGF_GetAttrLength(mlgfd, i));
				break;
			case VARSTRING:
				printf("(Type of attribute #%d: VARSTRING(%d))\n", i+1, MLGF_GetAttrLength(mlgfd, i));
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}
		printf(">");

		/* get the value of the attribute from user */
		while(1)
		{
			memset(inputStr, 0, sizeof(inputStr));
			fgets(inputStr, sizeof(inputStr), stdin);
			inputStrLen = strlen(inputStr) - 1; /* length except '\n' */
			inputStr[inputStrLen] = '\0';   /* eleminate '\n' */

			/* check whether the user input value is '-' */
			if(strcmp(inputStr, "-") == 0 || inputStrLen == 0)	/* search for full domain */
			{
				queryRegion[i].fullDomainFlag = TRUE;
				break;
			}

			queryRegion[i].fullDomainFlag = FALSE;

			/* check whether the user input value is valid or not */
			if(MLGF_GetAttrType(mlgfd, i) == INT)
			{
				if(!isIntValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					inputNum = atoi(inputStr);
					break;
				}
			}
			else if(MLGF_GetAttrType(mlgfd, i) == FLOAT)
			{
				if(!isFloatValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					inputRealNum = (float)atof(inputStr);
					break;
				}
			}
			else if(MLGF_GetAttrType(mlgfd, i) == STRING || MLGF_GetAttrType(mlgfd, i) == VARSTRING)
			{
				if((MLGF_GetAttrType(mlgfd, i) == STRING && inputStrLen != MLGF_GetAttrLength(mlgfd, i)) || inputStrLen > MLGF_GetAttrLength(mlgfd, i) || !isValidStringValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					break;
				}
			}
			else
			{
				printf("Wrong attribute type.\n");
				exit(1);
			}
		}

		if(queryRegion[i].fullDomainFlag == TRUE)	/* search for full domain */
		{
			continue;
		}

		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				queryRegion[i].minKey.length = MLGF_GetAttrLength(mlgfd, i);
				INT_ATTRIBUTE(&(queryRegion[i].minKey)) = (int*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(INT_ATTRIBUTE(&(queryRegion[i].minKey)) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
				}
				*(INT_ATTRIBUTE(&(queryRegion[i].minKey))) = inputNum;
				break;
			case FLOAT:
				queryRegion[i].minKey.length = MLGF_GetAttrLength(mlgfd, i);
				FLOAT_ATTRIBUTE(&(queryRegion[i].minKey)) = (float*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(FLOAT_ATTRIBUTE(&(queryRegion[i].minKey)) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
				}
				*(FLOAT_ATTRIBUTE(&(queryRegion[i].minKey))) = inputRealNum;
				break;
			case STRING:
				queryRegion[i].minKey.length = MLGF_GetAttrLength(mlgfd, i);
				STRING_ATTRIBUTE(&(queryRegion[i].minKey)) = (char*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(STRING_ATTRIBUTE(&(queryRegion[i].minKey)) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
				}
				memcpy(STRING_ATTRIBUTE(&(queryRegion[i].minKey)), inputStr, MLGF_GetAttrLength(mlgfd, i));
				break;
			case VARSTRING:
				queryRegion[i].minKey.length = inputStrLen;
				STRING_ATTRIBUTE(&(queryRegion[i].minKey)) = (char*)malloc(inputStrLen);
				if(STRING_ATTRIBUTE(&(queryRegion[i].minKey)) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
				}
				memcpy(STRING_ATTRIBUTE(&(queryRegion[i].minKey)), inputStr, inputStrLen);
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}

		printf("Input the max value of attribute #%d:\n", i+1);
		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				printf("(Type of attribute #%d: INT)\n", i+1);
				break;
			case FLOAT:
				printf("(Type of attribute #%d: FLOAT)\n", i+1);
				break;
			case STRING:
				printf("(Type of attribute #%d: STRING(%d))\n", i+1, MLGF_GetAttrLength(mlgfd, i));
				break;
			case VARSTRING:
				printf("(Type of attribute #%d: VARSTRING(%d))\n", i+1, MLGF_GetAttrLength(mlgfd, i));
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}
		printf(">");

		/* get the value of the attribute from user */
		while(1)
		{
			memset(inputStr, 0, sizeof(inputStr));
			fgets(inputStr, sizeof(inputStr), stdin);
			inputStrLen = strlen(inputStr) - 1; /* length except '\n' */
			inputStr[inputStrLen] = '\0';   /* eleminate '\n' */
	
			/* check whether the user input value is valid or not */
			if(MLGF_GetAttrType(mlgfd, i) == INT)
			{
				if(!isIntValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					inputNum = atoi(inputStr);
					break;
				}
			}
			else if(MLGF_GetAttrType(mlgfd, i) == FLOAT)
			{
				if(!isFloatValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					inputRealNum = (float)atof(inputStr);
					break;
				}
			}
			else if(MLGF_GetAttrType(mlgfd, i) == STRING || MLGF_GetAttrType(mlgfd, i) == VARSTRING)
			{
				if((MLGF_GetAttrType(mlgfd, i) == STRING && inputStrLen != MLGF_GetAttrLength(mlgfd, i)) || inputStrLen > MLGF_GetAttrLength(mlgfd, i) || !isValidStringValue(inputStr, inputStrLen))	/* wrong input */
				{
					printf("Wrong input.\n");
					printf(">");
					continue;
				}
				else	/* valid input */
				{
					break;
				}
			}
			else
			{
				printf("Wrong attribute type.\n");
				exit(1);
			}
		}

		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				queryRegion[i].maxKey.length = MLGF_GetAttrLength(mlgfd, i);
				INT_ATTRIBUTE(&(queryRegion[i].maxKey)) = (int*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(INT_ATTRIBUTE(&(queryRegion[i].maxKey)) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
				}
				*(INT_ATTRIBUTE(&(queryRegion[i].maxKey))) = inputNum;
				break;
			case FLOAT:
				queryRegion[i].maxKey.length = MLGF_GetAttrLength(mlgfd, i);
				FLOAT_ATTRIBUTE(&(queryRegion[i].maxKey)) = (float*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(FLOAT_ATTRIBUTE(&(queryRegion[i].maxKey)) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
				}
				*(FLOAT_ATTRIBUTE(&(queryRegion[i].maxKey))) = inputRealNum;
				break;
			case STRING:
				queryRegion[i].maxKey.length = MLGF_GetAttrLength(mlgfd, i);
				STRING_ATTRIBUTE(&(queryRegion[i].maxKey)) = (char*)malloc(MLGF_GetAttrLength(mlgfd, i));
				if(STRING_ATTRIBUTE(&(queryRegion[i].maxKey)) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
				}
				memcpy(STRING_ATTRIBUTE(&(queryRegion[i].maxKey)), inputStr, MLGF_GetAttrLength(mlgfd, i));
				break;
			case VARSTRING:
				queryRegion[i].maxKey.length = inputStrLen;
				STRING_ATTRIBUTE(&(queryRegion[i].maxKey)) = (char*)malloc(inputStrLen);
				if(STRING_ATTRIBUTE(&(queryRegion[i].maxKey)) == NULL)
				{
					ERROR(eMEMORYALLOCERR, "searchRecordFromMLGF");
				}
				memcpy(STRING_ATTRIBUTE(&(queryRegion[i].maxKey)), inputStr, inputStrLen);
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}
	}

	/* search for the records from MLGF */
	resetTimeElapsed();
	nRecords = MLGF_Query(mlgfd, queryRegion, MAX_N_RECORDS_SEARCHED, records);
	if(nRecords == eTOOMANYRECORDS)
	{
		nRecords = MAX_N_RECORDS_SEARCHED;
		printf("\n# There are more than %d records that satisfies the query region.\n", nRecords);
	}
	else
	{
		ERROR_CHECK(nRecords, "MLGF_Query()");
		printf("\n# %d records are searched.\n", nRecords);
	}
	getTimeElapsed(&timeInMilliSeconds);
	printf("  (Time elapsed: %dms)\n", timeInMilliSeconds);

	/* print the searched records */
	for(i=0; i<nRecords; i++)
	{
		printf("(");
		for(j=0; j<nAttr; j++)
		{
			switch(MLGF_GetAttrType(mlgfd, j))
			{
				case INT:
					printf("%d", *INT_ATTRIBUTE(&records[nAttr*i+j]));
					break;
				case FLOAT:
					printf("%f", *FLOAT_ATTRIBUTE(&records[nAttr*i+j]));
					break;
				case STRING:
				case VARSTRING:
					printf("\"");
					for(k=0; k<ATTRIBUTE_LENGTH(&records[nAttr*i+j]); k++)
					{
						printf("%c", *(STRING_ATTRIBUTE(&records[nAttr*i+j])+k));
					}
					printf("\"");
					break;
				default:
					printf("Wrong attribute type.\n");
					exit(1);
			}

			if(j+1 < nAttr)
			{
				printf(", ");
			}
		}
		printf(")\n");
	}

	/* free memory */
	for(i=0; i<nKeyAttr; i++)
	{
		if(queryRegion[i].fullDomainFlag == TRUE)	/* search for full domain */
		{
			continue;
		}
		else	/* memory for queryRegion is allocated only when searching for partial domain */
		{
			switch(MLGF_GetAttrType(mlgfd, i))
			{
				case INT:
					free(INT_ATTRIBUTE(&(queryRegion[i].minKey)));
					free(INT_ATTRIBUTE(&(queryRegion[i].maxKey)));
					break;
				case FLOAT:
					free(FLOAT_ATTRIBUTE(&(queryRegion[i].minKey)));
					free(FLOAT_ATTRIBUTE(&(queryRegion[i].maxKey)));
					break;
				case STRING:
				case VARSTRING:
					free(STRING_ATTRIBUTE(&(queryRegion[i].minKey)));
					free(STRING_ATTRIBUTE(&(queryRegion[i].maxKey)));
					break;
				default:
					printf("Wrong attribute type.\n");
					exit(1);
			}
		}
	}
	for(i=0; i<MAX_N_RECORDS_SEARCHED; i++)
	{
		for(j=0; j<nAttr; j++)
		{
			switch(MLGF_GetAttrType(mlgfd, j))
			{
				case INT:
					free(INT_ATTRIBUTE(&(records[nAttr*i+j])));
					break;
				case FLOAT:
					free(FLOAT_ATTRIBUTE(&(records[nAttr*i+j])));
					break;
				case STRING:
				case VARSTRING:
					free(STRING_ATTRIBUTE(&(records[nAttr*i+j])));
					break;
				default:
					printf("Wrong attribute type.\n");
					exit(1);
			}
		}
	}
	free(records);

	return 0;
}

int isIntValue(char *inputStr, int inputStrLen)
{
	int		i;	/* index */

	for(i=0; i<inputStrLen; i++)
	{
		if(inputStr[i] >= '0' && inputStr[i] <='9')	/* valid int value */
		{
			continue;
		}
		else if(i == 0 && inputStr[i] == '-' && inputStrLen > 1)	/* valid int value */
		{
			continue;
		}
		else	/* wrong value */
		{
			break;
		}
	}

	if(inputStrLen == 0 || i < inputStrLen)
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

int isFloatValue(char *inputStr, int inputStrLen)
{
	int		i;	/* index */
	int		flag;	/* flag indicating whether dot(.) character has been processed or not */

	flag = FALSE;
	for(i=0; i<inputStrLen; i++)
	{
		if(inputStr[i] >= '0' && inputStr[i] <='9')	/* valid float value */
		{
			continue;
		}
		else if(i == 0 && inputStr[i] == '-' && inputStrLen > 1)	/* valid float value */
		{
			continue;
		}
		else if(i != 0 && inputStr[i] == '.' && flag == FALSE)	/* valid float value */
		{
			flag = TRUE;
		}
		else	/* wrong value */
		{
			break;
		}
	}

	if(inputStrLen == 0 || i < inputStrLen)
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

int isValidStringValue(char *inputStr, int inputStrLen)
{
	int i;	/* index */

	/* check whether the input character string is valid or not */
	for(i=0; i<inputStrLen; i++)
	{
		if((inputStr[i] >= 'a' && inputStr[i] <= 'z') ||
			(inputStr[i] >= 'A' && inputStr[i] <= 'Z') ||
			(inputStr[i] >= '0' && inputStr[i] <= '9'))	/* valid string valie */
		{
			continue;
		}
		else	/* wrong value */
		{
			break;
		}
	}

	if(inputStrLen == 0 || i < inputStrLen)
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

void resetTimeElapsed()
{
	ftime(&start_timevar);
}

void getTimeElapsed(int* timeInMilliSeconds)
{
	int	start_time, current_time;
	struct timeb	current_timevar;

	ftime(&current_timevar);

	start_time = start_timevar.time * 1000 + start_timevar.millitm;
	current_time = current_timevar.time * 1000 + current_timevar.millitm;

	*timeInMilliSeconds = current_time - start_time;
}
