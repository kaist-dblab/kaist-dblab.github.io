/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#ifndef _COMMON_H_
#define _COMMON_H_

#include <limits.h>

/* Number of buffers */
#define NUM_BUFS	400

#define ADDITIONAL_FUNC_ON 1
#define ADDITIONAL_FUNC_OFF 0
/* Max number of keys */
#define MLGF_MAXNUM_KEYS	10

/* Max number of attributes */
#define MLGF_MAXNUM_ATTRIBUTES	MLGF_MAXNUM_KEYS

/*
 * Type Definitions for the Basic Types
 */
#if defined(_LP64)
/* one byte data type */
typedef char                    One;
typedef unsigned char           UOne;

/* two bytes data type */
typedef short                   Two;
typedef unsigned short          UTwo;

/* four bytes data type */
typedef int                     Four;
typedef unsigned int            UFour;

/* eight bytes data type */
typedef long                    Eight;
typedef unsigned long           UEight;

/* invarialbe size data type */
typedef char                    One_Invariable;
typedef unsigned char           UOne_Invariable;
typedef Two                     Two_Invariable;
typedef UTwo                    UTwo_Invariable;
typedef Four                    Four_Invariable;
typedef UFour                   UFour_Invariable;
typedef Eight                   Eight_Invariable;
typedef UEight                  UEight_Invariable;

/* data & memory align type */
typedef Four_Invariable			ALIGN_TYPE;
typedef Eight_Invariable		MEMORY_ALIGN_TYPE;
#else
/* one byte data type */
typedef char                    One;

/* two bytes data type */
typedef short                   Two;

/* four bytes data type */
typedef long                    Four;
typedef unsigned long           UFour;

/* invarialbe size data type */
typedef UFour                   UFour_Invariable;

/* data & memory align type */
#endif	/* _LP64 */

/* Boolean type */
typedef enum { FALSE, TRUE } Boolean;

#define CONSTANT_ONE					1
#if defined(_LP64)
#define CONSTANT_ALL_BITS_SET(_size)	((sizeof(_size) == 1) ? (0xff) : \
										((sizeof(_size) == 2) ? (0xffff) : \
										((sizeof(_size) == 4) ? (0xffffffff) : (0xffffffffffffffff))))
#else
#define CONSTANT_ALL_BITS_SET(_size)    ((sizeof(_size) == 1) ? (0xff) : \
										((sizeof(_size) == 2) ? (0xffff) : (0xffffffff)))
#endif	/* _LP64 */


/*
 * Type Definition of AttributeType
 */
typedef struct {
	enum { INT, FLOAT, STRING, VARSTRING}	dataType; /* data type */
	Two										length;   /* length */
} AttributeType;


/*
 * Type definition of AttributeHeader for each attribute
 */
typedef struct {
	Two	length;		/* length */
	union {
		int		*intPtr;	/* pointer */
		char	*charPtr;
		float	*floatPtr;
	} field;
} AttributeHeader;

#define	INT_ATTRIBUTE(x)	((x)->field.intPtr)		/* access int pointer */
#define	STRING_ATTRIBUTE(x)	((x)->field.charPtr)	/* access string pointer */
#define	FLOAT_ATTRIBUTE(x)	((x)->field.floatPtr)	/* access float pointer */
#define	ATTRIBUTE_LENGTH(x)	((x)->length)			/* access length field */

/* region specification */
typedef struct {
	One				fullDomainFlag;		/* set TRUE if region is full domain */
	AttributeHeader	minKey;				/* minimum key value */
	AttributeHeader	maxKey;				/* maximum key value */
} QueryRegion;

/*
 * MLGF Key Related Types
 */
typedef UFour_Invariable	MLGF_HashValue;
typedef struct {
    One 		flag;			/* flag */
    One 		nKeys;			/* number of keys */
    Two 		objMaxLen;		/* max length of an object */
    MLGF_HashValue      minMaxTypeVector;	/* bit vector of flags indicating MIN/MAX of MBR for each attribute */
} MLGF_KeyDesc;

#define MLGF_KEYDESC_SET_MINTYPE(minMaxTypeVector, i) \
	(minMaxTypeVector |= (((MLGF_HashValue)CONSTANT_ONE)<<(sizeof(MLGF_HashValue)*CHAR_BIT-1)) >> (i))
#define MLGF_KEYDESC_SET_MAXTYPE(minMaxTypeVector, i) \
	(minMaxTypeVector &= ~((((MLGF_HashValue)CONSTANT_ONE)<<(sizeof(MLGF_HashValue)*CHAR_BIT-1)) >> (i)))

/*
 * Definition for Error
 */
#define eNOERROR					0
#define eBADPARAMETER				-1
#define eDUPLICATEDRECORD			-2
#define eNOTFOUND					-3
#define eTOOMANYRECORDS				-4
#define eMEMORYALLOCERR				-5
#define eSYSERR						-6
#define eDUPLICATEDKEY				-7
#define eVARIABLELENGTHRECORD               -8

/* MLGF interface function prototypes */
Four MLGF_CloseIndex(Two);
Four MLGF_CreateIndex(One*, One, One, AttributeType[], MLGF_HashValue,One);
Four MLGF_DeleteObject(Two, AttributeHeader[]);
Four MLGF_Dump(Two, Boolean, FILE*);
char *MLGF_Error(Four);
Four MLGF_Final();
Four MLGF_Init(Four);
Four MLGF_InsertObject(Two, AttributeHeader[]);
Four MLGF_OpenIndex(One*, Two*);
Four MLGF_Query(Two, QueryRegion[], Four, AttributeHeader[]);

One MLGF_GetN_KeyAttr(Two);
One MLGF_GetN_Attr(Two);
Four MLGF_GetAttrType(Two, Two);
Two MLGF_GetAttrLength(Two, Two);

#endif /* _COMMON_H_ */


