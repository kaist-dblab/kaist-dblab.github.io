/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/* 
 *  Description : 
 *      Return a buffer page which has the disk content indicated by `pageid'.
 *      Before the allocation of a buffer page, look up the page in the buffer
 *      pool using hashing mechanism.   If the page already  exist in the pool
 *      then simply  return it  and set  the reference bit of the correponding
 *      buffer table entry.   Otherwise,  i.e. the page does not exist  in the
 *      pool,  allocate a buffer page (a page selected as victim may force out
 *      by  the  buffer  replacement  algorithm),  read  a  disk page into the 
 *      selected buffer page, and return it.
 *
 *  Return Values : 
 *      a buffer page which corresponds to the disk page indicated by `pageid'
 *
 *  Errors : 
 *      eNOERROR      :  No error
 *      eBADBUFFER    :  Invalid Buffer Page
 *      some errors   :  caused by BfM_AllocPage & BfM_ReadPage
 */

#include <BfM.h>

int BfM_GetPage(int SegmentID, PageID* pageid, void** ReturnPage)
{
    int e;                /* for error */
    int index;            /* index of the buffer pool */
    BfMHashKey key;       /* hash key which will be used in hashing */

    /* Check the validity of given parameters */
    /* Some restrictions may be added         */
    if(ReturnPage == NULL)
        return(eBADBUFFERBFM);


    /* Construct a hash key using the given parameters */
    key.SegID   = SegmentID;
    key.pageid  = *pageid;

    /* Check whether the page exist in the buffer pool */
    if((index = BfM_LookUp(&key))==eNOTFOUNDBFM) { /* Not Exist in the pool */

        /* Allocate a buffer page from the buffer pool */
        index = BfM_AllocPage();


        if(index < 0)  /* Buffer Allocation Error */
            return(index);

        /* Read a page from the disk */
        e = BfM_ReadPage(SegmentID, pageid, &(BfM_BufferPool[index * BfM_PAGESIZE]));

        if(e < 0)  /* Buffer Read Error */
            return e;

        /* fill the buffer table using the given parameters */
        BfM_BufferTable[index].Key.SegID  = SegmentID;
        BfM_BufferTable[index].Key.pageid = *pageid;

        /* set the reference bit */
        BfM_BufferTable[index].bits |= REFER;

        /* Insert the key into the hash table */
        e = BfM_Insert(&key, index);

        if(e < 0)
            return e;

        BfM_BufferTable[index].fixed = 1;
    } else if(index >= 0) { /* exist in the pool */

        (BfM_BufferTable[index].fixed)++;
        /* Set the reference bit of the table indicated by `index' */
        BfM_BufferTable[index].bits |= REFER;
    }

    else  /* some error occurs */
        return(index);

    /* return the page which corresponds to `index' in the buffer pool */
    *ReturnPage = (char*)&BfM_BufferPool[index * BfM_PAGESIZE];

    return(eNOERROR);   /* No error */

}  /* BfM_GetPage */

int BfM_GetNewPage(int SegmentID, PageID* pageid, void** ReturnPage)
{
    int e;                /* for error */
    int index;            /* index of the buffer pool */
    BfMHashKey key;       /* hash key which will be used in hashing */

    /* Check the validity of given parameters */
    /* Some restrictions may be added         */
    if(ReturnPage == NULL)
        return(eBADBUFFERBFM);


    /* Construct a hash key using the given parameters */
    key.SegID   = SegmentID;
    key.pageid  = *pageid;

    /* Check whether the page exist in the buffer pool */
    if((index = BfM_LookUp(&key))==eNOTFOUNDBFM) { /* Not Exist in the pool */

        /* Allocate a buffer page from the buffer pool */
        index = BfM_AllocPage();


        if(index < 0)  /* Buffer Allocation Error */
            return(index);

        /* fill the buffer table using the given parameters */
        BfM_BufferTable[index].Key.SegID  = SegmentID;
        BfM_BufferTable[index].Key.pageid = *pageid;

        /* set the reference bit */
        BfM_BufferTable[index].bits |= REFER;

        /* Insert the key into the hash table */
        e = BfM_Insert(&key, index);

        if(e < 0)
            return e;

        BfM_BufferTable[index].fixed = 1;
    } else if(index >= 0) { /* exist in the pool */

        (BfM_BufferTable[index].fixed)++;
        /* Set the reference bit of the table indicated by `index' */
        BfM_BufferTable[index].bits |= REFER;
    }

    else  /* some error occurs */
        return(index);

    /* return the page which corresponds to `index' in the buffer pool */
    *ReturnPage = (char*)&BfM_BufferPool[index * BfM_PAGESIZE];

    return(eNOERROR);   /* No error */

}  /* BfM_GetNewPage */
