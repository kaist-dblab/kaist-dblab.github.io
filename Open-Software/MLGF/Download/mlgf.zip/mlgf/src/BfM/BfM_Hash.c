/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Some functions are provided to support buffer manager.
 * Each BfMHashKey is mapping to one table entry in a hash table(BfM_HashTable),
 * and each entry has an index which indicates a buffer page in a buffer pool.
 *
 * An ordinary hashing method is used and linear probing strategy is
 * used if collision has occurred.
 */


#include <BfM.h>


#define R_MOD   (BfM_HashTableSize*3)

/* Check the validity of the given key, some restrictions may be added. */
#define CHECKKEY(k)  \
        { if(((k)->SegID < 0) || ((k)->pageid.pageNo < 0))  \
              return(eBADHASHKEYBFM); }

/* If k1 = k2 then true, otherwise false */
#define EQUALKEY(k1, k2) \
          (((k1)->SegID == (k2)->SegID) && ((k1)->pageid.pageNo == (k2)->pageid.pageNo))

#define BfM_hash(k) (((k)->pageid.volNo + (k)->pageid.pageNo) % BfM_HashTableSize)

/* Circular hash table is supported by the following macros */
#define RELOCATABLE(h,l,u) \
            ((l < u) ? ((h <= l) || (h > u)) : ((h <= l) && (h > u)))

/*
 *  Insert a new entry into the hash table.
 *  If collision occurs, then use the linear probing method.
 */
int BfM_Insert(BfMHashKey *key, int index)
{
	int	hashValue;

    CHECKKEY(key);    /* check validity of key */

	if((index < 0) || (index > BfM_MaxBufs))
        return(eBADBUFINDEXBFM);

	hashValue = BfM_hash(key);

	BfM_BufferTable[index].nextHashEntry = BfM_HashTable[hashValue];
	BfM_HashTable[hashValue] = index;

    return(eNOERROR);

}  /* BfM_Insert */


/*
 *  Look up the entry which corresponds to `key' and
 *  Delete the entry from the hash table.
 */
int BfM_Delete(BfMHashKey *key)
{
    int i, prev;
	int	hashValue;

    CHECKKEY(key);    /* check validity of key */

	hashValue = BfM_hash(key);
    /* Look up the key in the hash table */
    for(i = BfM_HashTable[hashValue], prev = NIL; i != NIL; prev = i, i = BfM_BufferTable[i].nextHashEntry) {
		if(EQUALKEY(&(BfM_BufferTable[i].Key), key)) {
			if(prev == NIL)
				BfM_HashTable[hashValue] = BfM_BufferTable[i].nextHashEntry;
			else
				BfM_BufferTable[prev].nextHashEntry = BfM_BufferTable[i].nextHashEntry;

			return(eNOERROR);
		}
	}

	return(eNOTFOUNDBFM);
}  /* BfM_Delete */


/*
 *  Look up the given key in the hash table and return its
 *  corressponding index to the buffer table.
 */
int BfM_LookUp(BfMHashKey *key)
{
    int i, j;     /* indices */
	int	hashValue;

    CHECKKEY(key);    /* check validity of key */

	hashValue = BfM_hash(key);

    /* Look up the hash table to find the key in the buffer table */
    for(i = BfM_HashTable[hashValue]; i != NIL; i = BfM_BufferTable[i].nextHashEntry) {
        if(EQUALKEY(&(BfM_BufferTable[i].Key), key)) {
			return(i);
		}
	}

	return(eNOTFOUNDBFM);
}  /* BfM_LookUp */


/*
 *  Initialize the hash table as each entry has NIL value.
 */
int BfM_InitHashTable(void)
{
    int i;

    for(i = 0;i<BfM_HashTableSize;i++)  BfM_HashTable[i] = NIL;

	return eNOERROR;
}  /* BfM_InitHashTable */
