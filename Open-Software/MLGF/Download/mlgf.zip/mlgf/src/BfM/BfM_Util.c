/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#include <DsM.h>
#include <BfM.h>
#include <malloc.h>

int BfM_IsPageInBuffer(int segmentID, PageID* pageid)
{
    int         index;         /* for an index */
    BfMHashKey  key;           /* a hash key */

    /* Construct a hash key using the given parameters */
    key.SegID  = segmentID;
    key.pageid = *pageid;

    /* Look up the key in the hash table and get a corresponding index */
    index = BfM_LookUp(&key);
    if(index < 0)
        return 0;
    else
        return 1;
}

int BfM_GetPageIndex(int segmentID, PageID* pageid)
{
    int         index;         /* for an index */
    BfMHashKey  key;           /* a hash key */

    /* Construct a hash key using the given parameters */
    key.SegID  = segmentID;
    key.pageid = *pageid;

    /* Look up the key in the hash table and get a corresponding index */
    index = BfM_LookUp(&key);
	return index;
}

BufferTable* BfM_GetBufferTableEntry(int ith)
{
	return &BfM_BufferTable[ith];
}

int BfM_GetNextVictim()
{
	return BfM_NextVictim;
}

int BfM_GetBufferTableSize()
{
	return BfM_MaxBufs;
}

int BfM_CheckBufferSpace(int segmentID, PageID* pageid, int nBuffersNeeded)
{
    BufferTable* bufferTable;
	BufferTable* currentVictim;
    int count           = 0;
    int bufferTableSize = BfM_GetBufferTableSize();
    int nextVictim      = BfM_GetNextVictim();

    if(!BfM_IsPageInBuffer(segmentID, pageid))
        return FALSE;    // ������ page�� ���ٸ�, �� �ʿ䵵 ����.
        
	// BufferTable�� �����Ѵ�.
    bufferTable = (BufferTable*)malloc(sizeof(BufferTable) * bufferTableSize);
	memcpy(bufferTable, BfM_BufferTable, sizeof(BufferTable) * bufferTableSize);
    while(1)
	{
		currentVictim = &bufferTable[nextVictim];
        if(currentVictim->fixed <= 0)
		{
            if(currentVictim->bits & 4)                                 // check refer bits
                currentVictim->bits = currentVictim->bits  & ~REFER;    // clear refer bits
            else
			{
                if(currentVictim->Key.SegID == segmentID && currentVictim->Key.pageid.pageNo == pageid->pageNo)
                    break;												// ������ page�� ������ �ǹǷ�, ���̻� �� �ʿ䰡 ����.
                else
				{
                    currentVictim->bits = currentVictim->bits | REFER;  // set refer bits
                    count += 1;
                    if(count >= nBuffersNeeded)
                        break;											// ���ϴ� �� ��ŭ Ȯ���Ǿ����Ƿ�, ���̻� ���ʿ䰡 ����.
				}
			}
		}
        nextVictim = (nextVictim + 1) % bufferTableSize;
	}

	free(bufferTable);

    if(count < nBuffersNeeded)
        return FALSE;													// ���ϴ� �������� Ȯ�� ����
    else
        return TRUE;													// ���ϴ� �������� Ȯ�� ����
}

int BfM_GetPageSize(void)
{
	return BfM_PAGESIZE;
}

int BfM_GetNUnfixedBuffers(void)
{
	int i, count;

	for(count = 0, i = 0; i < BfM_MaxBufs; i++)
		if(BfM_BufferTable[i].fixed == 0)
			count ++;
	return count;
}

extern VictimCallBackType victimCallBack;
int BFM_SetVictimCallback(VictimCallBackType callback)
{
	victimCallBack = callback;
    return 0;
}
