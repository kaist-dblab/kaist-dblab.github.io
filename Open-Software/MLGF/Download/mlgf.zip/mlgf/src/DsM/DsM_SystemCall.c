/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 *  This file has some functions which correspond to each UNIX system calls.
 */

#include <DsM.h>

int DsM_direct_diskio = FALSE;

/*
 * sys_open() : correspond to open() in UNIX system 
 */
int sys_open(char* name, int mode)
{
    switch(mode) {

        case INPUT  :
#ifdef WIN32
    #ifdef USE_WIN32_FILE_API
			if(DsM_direct_diskio)
				return (int)CreateFile(name, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_NO_BUFFERING, NULL);
			else
				return (int)CreateFile(name, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    #else
            return(open(name, O_WRONLY | O_BINARY));
    #endif            
#else
            return(open(name, O_WRONLY));
#endif

        case OUTPUT :
#ifdef WIN32
    #ifdef USE_WIN32_FILE_API
			if(DsM_direct_diskio)
				return (int)CreateFile(name, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_NO_BUFFERING, NULL);
			else
				return (int)CreateFile(name, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    #else
            return(open(name, O_RDONLY | O_CREAT | O_BINARY, S_IREAD | S_IWRITE));
    #endif            
#else
            return(open(name, O_RDONLY | O_CREAT, S_IREAD | S_IWRITE));
#endif

        case INOUT  :
#ifdef WIN32
    #ifdef USE_WIN32_FILE_API
			if(DsM_direct_diskio)
				return (int)CreateFile(name, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_NO_BUFFERING, NULL);
			else
				return (int)CreateFile(name, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    #else
            return(open(name, O_RDWR | O_CREAT | O_BINARY, S_IREAD | S_IWRITE));
    #endif            
#else
            return(open(name, O_RDWR | O_CREAT, S_IREAD | S_IWRITE));
#endif

        default :
            return(-1);
    }
} /* sys_open */


/*
 * sys_close() : correpond to open() in UNIX system 
 */
int sys_close(int fd)
{
#ifdef WIN32        
    #ifdef USE_WIN32_FILE_API
    if(CloseHandle((void*)fd) == 0)
        return -1;
    else
        return 0;
    #else
    return(close(fd));
    #endif    
#else
    return(close(fd));
#endif    
}  /* sys_close */


/*
 *  sys_lseek() : correspond to lseek() in UNIX system
 */
int sys_lseek(int fd, long offset, int whence)
{
#ifdef WIN32    
    #ifdef USE_WIN32_FILE_API    
    switch(whence)
    {
    case SEEK_SET:
         whence = FILE_BEGIN;
         break;
    case SEEK_CUR:
        whence = FILE_CURRENT;
        break;
    case SEEK_END:        
        whence = FILE_END;
        break;
    }
    return SetFilePointer((void*)fd, offset, NULL, whence);
    #else   
    return(lseek(fd, offset, whence));   /* lseek() is a UNIX system call */
    #endif    
#else
    return(lseek(fd, offset, whence));   /* lseek() is a UNIX system call */
#endif
}  /* sys_lseek */



/*
 *  sys_write() : correspond to write() in UNIX system
 */
int sys_write(int fd, char* buf, int nbytes)
{
#ifdef WIN32        
    #ifdef USE_WIN32_FILE_API    
    int size;
    WriteFile((void*)fd, buf, nbytes, &size, NULL);
    if(size != nbytes)
        return -1;
	else
		return size;
    #else    
    return(write(fd, buf, nbytes));
    #endif
#else
    return(write(fd, buf, nbytes));
#endif    
}  /* sys_write */



/* 
 *  sys_read() : correspond to read() in UNIX system
 */
int sys_read(int fd, char* buf, int nbytes)
{
#ifdef WIN32    
    #ifdef USE_WIN32_FILE_API    
    int size;
    ReadFile((void*)fd, buf, nbytes, &size, NULL);
	return size;
    #else    
    return(read(fd, buf, nbytes));
    #endif    
#else
    return(read(fd, buf, nbytes));
#endif
}  /* sys_read */


/*
 *  sys_system() : corresponding to system() in UNIX system
 */
int sys_system(char* str)
{
    return system(str);
}
