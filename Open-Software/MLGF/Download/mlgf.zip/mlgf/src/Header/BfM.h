/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#include "common.h"
#include <BfM_err.h>

extern int t_BfM;   /* Declared in /Util/trace.c for tracing BfM */


/* for tracing */

#define t_INTERFACE 0 

#define t_BFMHASH 1 


/* The structure of key type which is used as hashing  
   in buffer manager.                                 */

typedef struct BfMHashKey {
    int    SegID;    /* a segment identifier of a file */
    PageID pageid;   /* a page identifier */
} BfMHashKey;


/* The structure of BufferTable which is used in buffer replacement algo. */

typedef struct BufferTable {
    BfMHashKey	Key;        /* identify a page */
    int		fixed;          /* fixed count */
    char	bits;           /* bit 1 : DIRTY, bit 2 : VALID, bit 3 : REFER */
	int		nextHashEntry;
} BufferTable;

#define DIRTY  0x01
#define VALID  0x02
#define REFER  0x04
#define ALL_0  0x00
#define ALL_1  0xff


/* A set of buffers which will contain physical pages and global variables
   for buffer replacement algo.  These are declared in BfM_AllocPage().   */

extern char*		BfM_BufferPool;   /* A set of buffer pages */
extern BufferTable* BfM_BufferTable;  /* Information about buffer pages */
extern int			BfM_NextVictim;   /* The starting point for searching a next victim */
extern int*			BfM_HashTable;
extern int			BfM_MaxBufs;
extern int			BfM_HashTableSize;
extern int			BfM_PAGESIZE;

int		BfM_AllocPage(void);
void	BfM_dump_buffertable(void);
void	BfM_dump_hashtable(void);
char*	BfM_err(int errcode);
int		BfM_Final(void);
int		BfM_FlushPage(int segmentID, PageID* pageid);
int		BfM_Flush(void);
int		BfM_FreePage(int segmentID, PageID* pageid);
int		BfM_GetPage(int segmentID, PageID* pageid, void** ReturnPage);
int		BfM_Insert(BfMHashKey *key, int index);
int		BfM_Delete(BfMHashKey *key);
int		BfM_LookUp(BfMHashKey *key);
int		BfM_InitHashTable(void);
int		BfM_Init(int maxbuffers, int pagesize);
int		BfM_ReadPage(int segmentID, PageID* pageid, void* APage);
int		BfM_SetDirty(int segmentID, PageID* pageid);
int     BfM_IsPageInBuffer(int segmentID, PageID* pageid);
int		BfM_GetPageIndex(int segmentID, PageID* pageid);

BufferTable* BfM_GetBufferTableEntry(int ith);
int          BfM_GetNextVictim();
int          BfM_GetBufferTableSize();
int			 BfM_CheckBufferSpace(int segmentID, PageID* pageid, int nBuffersNeeded);
int			 BfM_GetPageSize(void);
int			 BfM_GetNUnfixedBuffers(void);

typedef void (*VictimCallBackType)(int segid, int pageid);

int     BFM_SetVictimCallback(VictimCallBackType callback);
