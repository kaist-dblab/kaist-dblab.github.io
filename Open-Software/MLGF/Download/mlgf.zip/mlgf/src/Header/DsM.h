/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#include "common.h"
#include <DsM_err.h>   

#ifndef eNOERROR
#define eNOERROR 0
#endif

#define INPUT 0
#define OUTPUT 1
#define INOUT 2

#define MAXFILENAME 1024

/* global variables */
extern long DsM_read_count;		/* declared in DsM_InitFinal.c */
extern long DsM_write_count;	/* declared in DsM_InitFinal.c */
extern long DsM_PAGESIZE;

/* Defined for tracing Disk Manager */

#define t_INTERFACE 0

#define t_SYSTEMCALL 1

#define t_SEGID  2


/* Defined for UNIX system calls */

#define FROM_SET 0     /* from the starting position */

#define FROM_CUR 1     /* from the current position */

#define FROM_END 2     /* from the last position */

int		DsM_Init(int pagesize);
int		DsM_Final();
int		DsM_AppendPage(int SegID);
int		DsM_CloseSegment(int SegID);
char*	DsM_err(int errcode);
int		DsM_FreePage(int SegID, PageID *pageid);
int		DsM_OpenSegment(int SegID, int mode);
int		DsM_ReadPage(int SegID, PageID* pageid, void* apage);
int		DsM_WritePage(int SegID, PageID* pageid, void* apage);

int		sys_open(char* name, int mode);
int		sys_close(int fd);
int		sys_lseek(int fd, long offset, int whence);
int		sys_write(int fd, char* buf, int nbytes);
int		sys_read(int fd, char* buf, int nbytes);
int		sys_system(char* str);

int		dsm_segid_get(int segid);
int		dsm_segid_init(int size);
int		dsm_segid_final(void);
int		dsm_segid_open(int segid, int mode);
int		dsm_segid_close(int segid);
int		dsm_segid_getdesc(int segid, int* desc);
int		dsm_segid_insert(int segid, char* name);
int		dsm_segid_delete(int segid);
int		dsm_segid_new(void);
int		dsm_segid_double(void);
int		dsm_segid_namefromid(int segid, char* name);
int		dsm_segid_idfromname(char* name, int* segid);
int		dsm_segid_dump(char* para);
