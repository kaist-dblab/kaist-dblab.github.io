/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#ifndef _COMMON_H_
#define _COMMON_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#define BEGIN_MACRO do {
#define END_MACRO } while(0)

#define OFFSET_OF(type, mem) ((size_t)((char *)&((type *) 0)->mem - (char *)((type *) 0)))

#define NIL	(-1)
#define NIL_PAGEID	((PageNo)(-1))

#undef MIN
#define MIN(a,b) (((a) < (b)) ? (a):(b))

#undef MAX
#define MAX(a,b) (((a) >= (b)) ? (a):(b))

/* Calculate the alignment boundary */
#define ALIGN sizeof(ALIGN_TYPE)
#define ALIGNED_LENGTH(l) \
			(((l)%ALIGN) ? ((l) - ((l)%ALIGN) + (((l) < 0) ? (-1 * ((Four)(ALIGN))):ALIGN)) : (l))


/* Definition for lseek() paramter */
#define L_BEGIN		0
#define L_CURRENT	1
#define L_END		2

/* Max number of keys */
#define MLGF_MAXNUM_KEYS	10

/* Max number of attributes */
#define MLGF_MAXNUM_ATTRIBUTES	MLGF_MAXNUM_KEYS

/* Max length of an object */
#define OBJECT_MAX_LEN	400


/*
 * Type Definitions for the Basic Types
 */
#if defined(_LP64)
/* one byte data type */
typedef char                    One;
typedef unsigned char           UOne;

/* two bytes data type */
typedef short                   Two;
typedef unsigned short          UTwo;

/* four bytes data type */
typedef int                     Four;
typedef unsigned int            UFour;

/* eight bytes data type */
typedef long                    Eight;
typedef unsigned long           UEight;

/* invarialbe size data type */
typedef char                    One_Invariable;
typedef unsigned char           UOne_Invariable;
typedef Two                     Two_Invariable;
typedef UTwo                    UTwo_Invariable;
typedef Four                    Four_Invariable;
typedef UFour                   UFour_Invariable;
typedef Eight                   Eight_Invariable;
typedef UEight                  UEight_Invariable;

/* data & memory align type */
typedef Four_Invariable			ALIGN_TYPE;
typedef Eight_Invariable		MEMORY_ALIGN_TYPE;
#else
/* one byte data type */
typedef char                    One;

/* two bytes data type */
typedef short                   Two;

/* four bytes data type */
typedef long                    Four;
typedef unsigned long           UFour;

/* data & memory align type */
typedef Four					ALIGN_TYPE;
#endif	/* _LP64 */

#ifdef FALSE
#undef FALSE
#endif

#ifdef TRUE
#undef TRUE
#endif

/* Boolean type */
typedef enum { FALSE, TRUE } Boolean;

#define CONSTANT_ONE					1
#if defined(_LP64)
#define CONSTANT_ALL_BITS_SET(_size)	((sizeof(_size) == 1) ? (0xff) : \
										((sizeof(_size) == 2) ? (0xffff) : \
										((sizeof(_size) == 4) ? (0xffffffff) : (0xffffffffffffffff))))
#else
#define CONSTANT_ALL_BITS_SET(_size)    ((sizeof(_size) == 1) ? (0xff) : \
										((sizeof(_size) == 2) ? (0xffff) : (0xffffffff)))
#endif	/* _LP64 */


/*
 * Type Definition of AttributeType
 */
typedef struct {
	enum { INT, FLOAT, STRING, VARSTRING}	dataType; /* data type */
	Two										length;   /* length */
} AttributeType;


/*
 * Type definition of AttributeHeader for each attribute
 */
typedef struct {
	Two	length;		/* length */
	union {
		int		*intPtr;	/* pointer */
		char	*charPtr;
		float	*floatPtr;
	} field;
} AttributeHeader;

#define	INT_ATTRIBUTE(x)	((x)->field.intPtr)		/* access int pointer */
#define	STRING_ATTRIBUTE(x)	((x)->field.charPtr)	/* access string pointer */
#define	FLOAT_ATTRIBUTE(x)	((x)->field.floatPtr)	/* access float pointer */
#define	ATTRIBUTE_LENGTH(x)	((x)->length)			/* access length field */

/* region specification */
typedef struct {
	One				fullDomainFlag;		/* set TRUE if region is full domain */
	AttributeHeader	minKey;				/* minimum key value */
	AttributeHeader	maxKey;				/* maximum key value */
} QueryRegion;


/*
 * Type Definition of Object
 */
#define OBJ_MAX_LEN	398
typedef struct {
	char	data[OBJ_MAX_LEN];	/* data */
} Object;

/*
 *  If user "USE" additional functions of MLGF then physical object form is
 *
 *  +------------------------------------------+
 *  |                        |				   |
 *  |  Two length of object  |      data       |
 *  |                        |                 |
 *  +------------------------------------------+
 *
 *  else
 *
 *  +------------------------------------------+
 *  |                        				   |
 *  |                   data   	               |
 *  |                                          |
 *  +------------------------------------------+
*/

/*
 * Type Definition of PageID
 */
typedef Four PageNo;
typedef Two VolNo;
typedef VolNo VolID;

typedef struct {
	PageNo pageNo;	/* a PageNo */
	VolNo volNo;	/* a VolNo */
} PageID;

typedef PageNo ShortPageID;	/* referenc a page within a given volume */

/* construct page ID from the given volNo & pageNo */
#define SET_NILPAGEID(x)	((x).pageNo = NIL)
#define EQUAL_PAGEID(x, y)	\
	(((x).volNo == (y).volNo && (x).pageNo == (y).pageNo) ? TRUE:FALSE)
#define IS_NILPAGEID(x)		(((x).pageNo == NIL) ? TRUE:FALSE)
#define MAKE_PAGEID(pid, volume, page)  \
	(pid).volNo = (volume),	\
	(pid).pageNo = (page)

/*
 * MLGF Key Related Types
 */
typedef UFour	MLGF_HashValue;
typedef struct {
    One 		flag;			/* flag */
    One 		nKeys;			/* number of keys */
    Two 		objMaxLen;		/* max length of an object */
    MLGF_HashValue      minMaxTypeVector;	/* bit vector of flags indicating MIN/MAX of MBR for each attribute */
} MLGF_KeyDesc;

/* type definition of MortonValue */
typedef MLGF_HashValue	MortonValue;
typedef struct {
	UFour			nBits;
	MortonValue		val[MLGF_MAXNUM_KEYS];
} mlgf_MortonValue;

#define MLGF_KEYDESC_CLEAR_MINMAXTYPEVECTOR(kdesc) \
	((kdesc).minMaxTypeVector = 0)
#define MLGF_KEYDESC_SET_MINTYPE(kdesc, i) \
	((kdesc).minMaxTypeVector |= (((MLGF_HashValue)CONSTANT_ONE)<<(sizeof(MLGF_HashValue)*CHAR_BIT-1)) >> (i))
#define MLGF_KEYDESC_SET_MAXTYPE(kdesc, i) \
	((kdesc).minMaxTypeVector &= ~((((MLGF_HashValue)CONSTANT_ONE)<<(sizeof(MLGF_HashValue)*CHAR_BIT-1)) >> (i)))
#define MLGF_KEYDESC_IS_MINTYPE(kdesc, i) \
	((kdesc).minMaxTypeVector & ((((MLGF_HashValue)CONSTANT_ONE)<<(sizeof(MLGF_HashValue)*CHAR_BIT-1)) >> (i)))
#define MLGF_KEYDESC_IS_MAXTYPE(kdesc, i) \
	(!((kdesc).minMaxTypeVector & ((((MLGF_HashValue)CONSTANT_ONE)<<(sizeof(MLGF_HashValue)*CHAR_BIT-1)) >> (i))))

#define MLGF_HASHVALUE_MIN	((MLGF_HashValue)0x0)
#define MLGF_HASHVALUE_MAX	(MLGF_HASHVALUE_ALL_BITS_SET)

#define MLGF_MAXNUM_VALIDBITS		(CHAR_BIT*sizeof(MLGF_HashValue))
#define MLGF_HASHVALUE_MSB_SET		((MLGF_HashValue)(((MLGF_HashValue)CONSTANT_ONE)<<(sizeof(MLGF_HashValue)*CHAR_BIT-1)))
#define MLGF_HASHVALUE_ALL_BITS_SET	((MLGF_HashValue)(CONSTANT_ALL_BITS_SET(MLGF_HashValue)))
#define MLGF_HASHVALUE_MAXNUM_BITS      (CHAR_BIT*sizeof(MLGF_HashValue))
#define MLGF_MORTONVALUE_MAXNUM_BITS	(CHAR_BIT*sizeof(MortonValue))
#define MLGF_MORTONVALUE_MSB_SET	((MortonValue)(((MortonValue)CONSTANT_ONE)<<(sizeof(MortonValue)*CHAR_BIT-1)))
#define MLGF_MORTONVALUE_ALL_BITS_SET	((MortonValue)(CONSTANT_ALL_BITS_SET(MortonValue)))

/* bias to make hash value be positive */
#define BIAS	(((MLGF_HashValue)CONSTANT_ALL_BITS_SET(MLGF_HashValue)/2) +1)

/* Comparison Related Constants */
#define EQUAL 0
#define GREAT 1
#define LESS  2

/* Additional Function Usage */

#define ADDITIONAL_FUNC_OFF 0
#define ADDITIONAL_FUNC_ON 1

/*
 * Type Definition of Page
 */
#define PAGESIZE	4096

/* Type definition for log sequence number */
typedef struct Lsn_T_tag {
	UFour	offset;		/* byte position in a log volume */
	UFour	wrapCount;	/* # of wrapping around a log volume */
} Lsn_T;

/* Type definition for the normal page */
typedef struct PageHdr_T_tag {
	PageID	pid;		/* page id of this page */
	Four	flags;
	Four	reserved;
	PageID	fidOrIid;	/* file id or index id containing this page */
	Lsn_T	lsn;		/* page lsn */
	Four	logRecLen;	/* log record length */
} PageHdr;

typedef struct Page_tag {
	PageHdr	header;
	char	data[PAGESIZE-sizeof(PageHdr)];
} Page;

/* Type vector indicates page's type */
#define PAGE_TYPE_VECTOR_MASK	0xf
#define PAGE_TYPE_VECTOR_RESET_MASK	(CONSTANT_ALL_BITS_SET(Four)-PAGE_TYPE_VECTOR_MASK)

#define MLGF_PAGE_TYPE	0x6

#define RESET_PAGE_TYPE(page)		(((Page *)(page))->header.flags &= PAGE_TYPE_VECTOR_RESET_MASK)
#define SET_PAGE_TYPE(page, type)   (RESET_PAGE_TYPE(page), ((Page *)(page))->header.flags |= type)

#define PAGE_TEMP_VECTOR_MASK	0x10
#define PAGE_TEMP_VECTOR_RESET_MASK	(CONSTANT_ALL_BITS_SET(Four)-PAGE_TEMP_VECTOR_MASK)

#define IS_TEMP_PAGE(page)			(((Page *)(page))->header.flags & PAGE_TEMP_VECTOR_MASK)
#define SET_TEMP_PAGE_FLAG(page)	(((Page *)(page))->header.flags |= PAGE_TEMP_VECTOR_MASK)
#define RESET_TEMP_PAGE_FLAG(page)	(((Page *)(page))->header.flags &= PAGE_TEMP_VECTOR_RESET_MASK)

/* Type vector indicates mlgf page's type */
#define MLGF_DIRECTORYPAGE	1
#define MLGF_LEAFPAGE		2
#define MLGF_OVERFLOWPAGE	4
#define MLGF_ROOTPAGE		8
#define MLGF_FREEPAGE		0x10

/* Type definition for mlgf_AnyPage */
typedef struct mlgf_AnyPageHdr_T_tag {
	PageID	pid;			/* page id of this page */
	One		type;			/* Internal, Leaf, or Overflow */
} mlgf_AnyPageHdr_T;

#define MLGF_AP_FIXED	(sizeof(mlgf_AnyPageHdr_T))

typedef struct {
	mlgf_AnyPageHdr_T	hdr;	/* page header */
	char	data[PAGESIZE-MLGF_AP_FIXED];	/* data area */
} mlgf_AnyPage;

/* Type definition for the directory page */
typedef struct mlgf_DirectoryPageHdr_T_tag {
    PageID	pid;			/* page id of this page */
    One		type;			/* Internal, Leaf, or Overflow */
    One		height;			/* height of this page */
    Two		nEntries;		/* number of the stored entries */
} mlgf_DirectoryPageHdr_T;

#define MLGF_DP_FIXED (sizeof(mlgf_DirectoryPageHdr_T))

typedef struct {
    mlgf_DirectoryPageHdr_T		hdr;							/* page header */
    char						data[PAGESIZE-MLGF_DP_FIXED];	/* data area */
} mlgf_DirectoryPage;

/*
 *
 *  Directory page form is 
 *
 *	+--------------------+
 *  |	header part		 |
 *  |--------------------|
 *  |					 |
 *  |   data part		 |  -- mlgf_DirectoryEntry is stored at data part
 *  |					 |
 *  |					 |
 *  +--------------------+	
 *
 */ 

#define MLGF_DP_THETA(dirPage, entryLen) ((dirPage)->hdr.nEntries*(entryLen))

/* Type definition for directory entry */
typedef struct {
	ShortPageID	spid;		/* PageID of the child page */
	Two			theta;		/* number of used bytes in child page */
	One			nValidBits[MLGF_MAXNUM_KEYS];	/* number of valid bits of hash values */
												/* implicitly followed by hash values */
	MLGF_HashValue	hashValue[MLGF_MAXNUM_KEYS];	/* hash values */
} mlgf_DirectoryEntry;

/*
 *  mlgf_DirectoryEntry form is 
 *  +-------------------------------------------------------+
 *  |        |         |             |                      |  
 *  | spid   | theta   |  nvaildBits | hashValue[numOfKeys] |  
 *  |        |         |             |                      | 
 *  +-------------------------------------------------------+
 *  
 */ 

#define MLGF_DIRENTRY_FIXED OFFSET_OF(mlgf_DirectoryEntry, nValidBits[0])
#define MLGF_DIRENTRY_LENGTH(nKeys)	(ALIGNED_LENGTH(MLGF_DIRENTRY_FIXED+sizeof(One)*nKeys) + \
										nKeys*sizeof(MLGF_HashValue))
#define MLGF_DIRENTRY_HASHVALUEPTR(entry, nKeys) \
			((MLGF_HashValue*) ((char*)entry + ALIGNED_LENGTH(MLGF_DIRENTRY_FIXED + sizeof(One)*nKeys)))
#define MLGF_MAX_DIRENTRIES(nKeys)	((PAGESIZE-MLGF_DP_FIXED)/MLGF_DIRENTRY_LENGTH(nKeys))
#define MLGF_ITH_DIRENTRY(dirPage, entryNo, entryLen) \
			((mlgf_DirectoryEntry*)&(dirPage)->data[(entryLen)*(entryNo)])
#define MLGF_NEXT_DIRENTRY(dirEntry, entryLen) \
	((mlgf_DirectoryEntry*)((char*)(dirEntry) + entryLen))

/* Type definition for the leaf page */
typedef struct mlgf_LeafPageHdr_T_tag {
    PageID pid;             /* page id of this page */
    One	type;               /* Internal, Leaf, or Overflow */
    Two nEntries;			/* number of the stored entries */
    Two free;               /* offset of contiguous free area on page */
    Two unused;             /* number of unused bytes which are not */
                            /* part of the contiguous free space */
} mlgf_LeafPageHdr_T;

#define MLGF_LP_FIXED (sizeof(mlgf_LeafPageHdr_T) + sizeof(Two))

typedef struct {
    mlgf_LeafPageHdr_T hdr;
    char data[PAGESIZE-MLGF_LP_FIXED]; /* data area */
    Two slot[1];		       /* slot array, indexes backward */
} mlgf_LeafPage;

/*
 *
 *  Leaf page form is 
 *  +--------------------+
 *  |	header part		 |
 *  |--------------------|
 *  |					 |
 *  |   data part		 |  -- mlgf_Leafentry is stored at data part
 *  |					 |
 *  |					 |
 *  |					 |
 *  |--------------------|  -- this boundary is not fixed
 *  |			slot[0]  |
 *  +--------------------+	
 *
 */

#define MLGF_LP_FREE(apage) (MLGF_LP_CFREE(apage) + (apage)->hdr.unused)
#define MLGF_LP_CFREE(apage) \
	(PAGESIZE - MLGF_LP_FIXED - (apage)->hdr.free - ((apage)->hdr.nEntries-1)*sizeof(Two))
#define MLGF_LP_THETA(apage) \
	((apage)->hdr.free - (apage)->hdr.unused + sizeof(Two)*((apage)->hdr.nEntries))

/* Type definition for leaf entry */
typedef struct {
	MLGF_HashValue	keys[MLGF_MAXNUM_KEYS];		/* key values */
	char dummy[sizeof(Object)];					/* space reservation */

	/* After the real number of keys there comes the list of objects. */
	/* If the list is too long, then overflow */
	/* page no of the first overflow page is placed. */
} mlgf_LeafEntry;

/*
 *
 *  If user "USE" additional functions of MLGF then leaf entry form is
 *  +-----------------------------------------------------------------------------------------------------+
 *  |                                |                          |                         |               | 
 *  | MLGF_HashValue keys[numOfKeys] | Two totalObjLen          | Two nObjects            |  data records |
 *  |                                | (length of data records) | (number of data records |               |
 *  |                                |                          |   in same leaf entry)   |               | 
 *  +-----------------------------------------------------------------------------------------------------+
 *
 *  else did "NOT USE" additional functions
 *  +-------------------------------------------------+
 *  |								 |   		      |  
 *  | MLGF_HashValue keys[numOfKeys] |  data records  |
 *	|								 |                | 
 *  +-------------------------------------------------+
 *
 *
 */

#define MLGF_LEAFENTRY_LENGTH(_useAddFunc,_nKeys, _totalObjLen, _nObjects) \
	( _useAddFunc) ? ( sizeof(Two) + sizeof(Two) + sizeof(MLGF_HashValue)*(_nKeys) + (((_nObjects) < 0) ? sizeof(ShortPageID):_totalObjLen) ) \
					: (sizeof(MLGF_HashValue)*(_nKeys) + (((_nObjects) < 0 ) ? sizeof(ShortPageID) : _totalObjLen))

#define MLGF_NEW_LEAFENTRY_LENGTH(_useAddFunc,_nKeys, _totalObjLen) \
	(_useAddFunc) ? (sizeof(Two) + sizeof(Two) + sizeof(MLGF_HashValue)*(_nKeys) + _totalObjLen) : (sizeof(MLGF_HashValue)*(_nKeys) + _totalObjLen)
#define MLGF_LEAFENTRY_FIRST_OVERFLOW(_nKeys, entry) \
	(*((ShortPageID*)((entry)->keys + ((_nKeys)+1))))
#define MLGF_LEAFENTRY_FIRST_OBJECT(_useAddFunc,_nKeys, entry) \
	( _useAddFunc) ? ((char*)(entry->keys + ((_nKeys)+1))) : ((char*)(entry->keys + (_nKeys)))
#define MLGF_ITH_LEAFENTRY(leafPage, entryNo) \
	((mlgf_LeafEntry*)&(leafPage)->data[(leafPage)->slot[-(entryNo)]])

/* Type definition for overflow page */
typedef struct mlgf_OverflowPageHdr_T_tag {
    PageID pid;                 /* page id of this page */
    One	type;                   /* Internal, Leaf, or Overflow */
    Two totalObjLen;			/* total length of objects */
    Two nObjects;               /* number of the stored objects */
    ShortPageID prevPage;       /* previous overflow page */
    ShortPageID nextPage;       /* next overflow page */
} mlgf_OverflowPageHdr_T;

#define MLGF_OP_FIXED (sizeof(mlgf_OverflowPageHdr_T))

typedef struct {
    mlgf_OverflowPageHdr_T hdr;
    char data[PAGESIZE-MLGF_OP_FIXED]; /* data area */
} mlgf_OverflowPage;

#define MLGF_OP_FREE(apage)	(PAGESIZE - MLGF_OP_FIXED - (apage)->hdr.totalObjLen)

/* Type definiton for mlgf_Page */
typedef union {
	mlgf_AnyPage		any;		/* page which consists of common fileds */
	mlgf_DirectoryPage	directory;	/* directory page */
	mlgf_LeafPage		leaf;		/* leaf page */
	mlgf_OverflowPage	overflow;	/* overflow page */
} mlgf_Page;

/* threshold */
#define MLGF_OP_HALF_THRESHOLD	((PAGESIZE-MLGF_OP_FIXED)/2)
#define MLGF_DP_THRESHOLD		((PAGESIZE-MLGF_DP_FIXED)/2)
#define MLGF_LP_THRESHOLD		((PAGESIZE-MLGF_LP_FIXED)/2)
/* Threshold for converting from normal entry to overflow page */
#define MLGF_OP_IN_THRESHOLD	((PAGESIZE-MLGF_OP_FIXED)/3)
/* Threshold for converting from overflow page to normal entry */
#define MLGF_OP_OUT_THRESHOLD	((PAGESIZE-MLGF_OP_FIXED)/4)


/* 
 * MLGF Catalog Related Types
 */
typedef struct {
	AttributeType 	attrType[MLGF_MAXNUM_ATTRIBUTES];	/* type of each attribute */
	One				useAdditionalFunc;
	One				numOfKeys;							/* the number of keys (organizing attributes) */
	One				flag;								/* flag */
	One				numOfAttrs;							/* the number of attributes of the object (including the number of organizing attributes) */
	PageID			rootPage;							/* root page number */
	Two				objMaxLen;							/* max length of the object */
	MLGF_HashValue			minMaxTypeVector;			/* bit vector of flags indicating MIN/MAX of MBR for each attribute */
} Control;

struct free_page_list {
	PageID					pid;		/* page number */
	struct free_page_list	*next;		/* next free page pointer */
};
typedef struct free_page_list	FreePageList;

#define OPENFILETABLE_INCREMENT_SIZE	10
typedef struct {
	int				ino;		/* inode number: for checking multiple open */
	int				count;		/* number of opens */
	int				os_fd;		/* OS level file descriptor */
	Control			controlInfo;
	FreePageList	freePageList;
	PageID			pageCount;
#ifdef MBR_MLGF_BUFFER
	int				dsmSegId;
#endif	/* MBR_MLGF_BUFFER */
} OpenFileTableEntry;

#define IS_VALID_MLGFD(x) \
	((x) >= 0 && (x) < maxEntriesOfOpenFileTable && openFileTable[x].ino != NIL)

#define OPENFILE_INO(x)				(openFileTable[x].ino)
#define OPENFILE_COUNT(x)			(openFileTable[x].count)
#define OPENFILE_OS_FD(x)			(openFileTable[x].os_fd)
#define OPENFILE_CONTROL(x)			(openFileTable[x].controlInfo)
#define OPENFILE_FREEPAGELIST(x)	(openFileTable[x].freePageList)
#define OPENFILE_PAGECOUNT(x)		(openFileTable[x].pageCount)
#ifdef MBR_MLGF_BUFFER
#define OPENFILE_DSMSEGID(x)		(openFileTable[x].dsmSegId)
#endif  /* MBR_MLGF_BUFFER */

#define NUM_OF_KEYS(x)	(OPENFILE_CONTROL(x).numOfKeys)


/* Init entry no */
#define MLGF_NOENTRY	-1

#define KEY_SAME 2
#define WHOLE_SAME 1
/*
 * Type definition for program status variable
 */
typedef union mlgf_InsertStatus_T_tag {
	struct {
        unsigned objectInserted      : 1;
        unsigned mbrUpdated          : 1;
        unsigned thetaUpdated        : 1;
        unsigned overflow            : 1;
        unsigned objectInEmptyRegion : 1;
    } flags;
    UFour	allFlags;
} mlgf_InsertStatus_T;

typedef union mlgf_DeleteStatus_T_tag {
    struct {
        unsigned notFound            : 1;
        unsigned mbrUpdated          : 1;
        unsigned thetaUpdated        : 1;
        unsigned underflow           : 1;
        unsigned emptyPage           : 1;
    } flags;
    UFour	allFlags;
} mlgf_DeleteStatus_T;


/*
 * Declaration extern variables for MLGF
 */
extern OpenFileTableEntry	*openFileTable;
extern int	maxEntriesOfOpenFileTable;
extern int		nDirPages;
extern int		nLeafPages;
extern float	dirPageOccupancyRatio;
extern float	leafPageOccupancyRatio;

extern int cocount;

/*
 * Definition for Error
 */
#define eNOERROR					0
#define eBADPARAMETER				-1
#define eDUPLICATEDRECORD			-2
#define eNOTFOUND					-3
#define eTOOMANYRECORDS				-4
#define eMEMORYALLOCERR				-5
#define eSYSERR						-6
#define eDUPLICATEDKEY				-7
#define eVARIABLELENGTHRECORD				-8

#define ERR(e) \
BEGIN_MACRO \
	printf("Error : %d in %s:%d\n", ((Four)(e)), __FILE__, __LINE__); \
	return(e); \
END_MACRO

#define ERRB1(e, mlgfd, pid) \
BEGIN_MACRO \
	printf("Error : %d in %s:%d\n", ((Four)(e)), __FILE__, __LINE__); \
	(Four) BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), (pid)); \
	if (1) return(e); \
END_MACRO

#define ERRB2(e, mlgfd, pid1, pid2) \
BEGIN_MACRO \
	printf("Error : %d in %s:%d\n", ((Four)(e)), __FILE__, __LINE__); \
	(Four) BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), (pid1)); \
	(Four) BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), (pid2)); \
	if (1) return(e); \
END_MACRO


/*
 * Other Macros
 */

#define MLGF_HASHVALUE_ITH_BIT_SET(i) ((MLGF_HashValue)0x1 << (MLGF_HashValue)(MLGF_HASHVALUE_MAXNUM_BITS - (i)))

#define MLGF_HASHVALUE_UPPER_N_BITS_SET(n) \
	((n) ? (MLGF_HASHVALUE_ALL_BITS_SET << (MLGF_HashValue)(MLGF_HASHVALUE_MAXNUM_BITS - n)):(MLGF_HashValue)0)

#define MLGF_HASHVALUE_MASK_UPPER_N_BITS(val, n) \
	( (MLGF_HashValue)val & MLGF_HASHVALUE_UPPER_N_BITS_SET(n) )

#define MLGF_HASHVALUE_SET_EXCEPT_UPPER_N_BITS(n) \
	(((n) == MLGF_HASHVALUE_MAXNUM_BITS) ? 0:(MLGF_HASHVALUE_ALL_BITS_SET >> (n)))

#define MLGF_MORTONVALUE_UPPER_N_BITS_SET(n) \
	((n) ? (MLGF_MORTONVALUE_ALL_BITS_SET << (MortonValue)(MLGF_MORTONVALUE_MAXNUM_BITS - n)):(MortonValue)0)

#define MLGF_COPY_DIRECTORY_PAGE(dstPage, dstPid, srcPage, isRoot) \
BEGIN_MACRO \
    *(dstPage) = *(srcPage); \
    (dstPage)->hdr.type = MLGF_DIRECTORYPAGE; \
    if (isRoot) (dstPage)->hdr.type |= MLGF_ROOTPAGE; \
    (dstPage)->hdr.pid = dstPid; \
END_MACRO

#define MLGF_INIT_DIRECTORY_PAGE(_apage, _isTmp, _pid, _height, _isRoot) \
BEGIN_MACRO \
    SET_PAGE_TYPE(_apage, MLGF_PAGE_TYPE); \
    if (_isTmp) SET_TEMP_PAGE_FLAG(_apage); \
    else        RESET_TEMP_PAGE_FLAG(_apage); \
    (_apage)->hdr.pid = _pid; \
    (_apage)->hdr.type = (_isRoot == TRUE) ? (MLGF_DIRECTORYPAGE | MLGF_ROOTPAGE) : MLGF_DIRECTORYPAGE; \
    (_apage)->hdr.height = _height; \
    (_apage)->hdr.nEntries = 0; \
END_MACRO

#define MLGF_INIT_LEAF_PAGE(_apage, _isTmp, _pid) \
BEGIN_MACRO \
    SET_PAGE_TYPE(_apage, MLGF_PAGE_TYPE); \
    if (_isTmp) SET_TEMP_PAGE_FLAG(_apage); \
    else        RESET_TEMP_PAGE_FLAG(_apage); \
    (_apage)->hdr.pid = _pid; \
    (_apage)->hdr.type = MLGF_LEAFPAGE; \
    (_apage)->hdr.nEntries = 0; \
    (_apage)->hdr.free = 0; \
    (_apage)->hdr.unused = 0; \
END_MACRO


#define MLGF_INIT_OVERFLOW_PAGE(_apage, _isTmp, _pid, _prevPage, _nextPage, _totalObjLen) \
BEGIN_MACRO \
    SET_PAGE_TYPE(_apage, MLGF_PAGE_TYPE); \
    if (_isTmp) SET_TEMP_PAGE_FLAG(_apage); \
    else        RESET_TEMP_PAGE_FLAG(_apage); \
    (_apage)->hdr.pid = _pid; \
    (_apage)->hdr.type = MLGF_OVERFLOWPAGE; \
    (_apage)->hdr.nObjects = 0; \
    (_apage)->hdr.prevPage = _prevPage; \
    (_apage)->hdr.nextPage = _nextPage; \
    (_apage)->hdr.totalObjLen= _totalObjLen; \
END_MACRO

#define MLGF_INSERT_SLOTS_IN_MLGF_PAGE(_apage, _idx, _n) \
    memmove(&((_apage)->slot[-((_apage)->hdr.nEntries - 1 + (_n))]), \
			&((_apage)->slot[-((_apage)->hdr.nEntries - 1)]), \
			sizeof(Two)*((_apage)->hdr.nEntries - (_idx)))







/*
 * Function Prototypes
 */
/* MLGF internal function prototypes */
Four mlgf_AllocPage(Two, PageID*);
Boolean mlgf_BuddyTest(One, mlgf_DirectoryEntry*, mlgf_DirectoryEntry*, One*);
Four mlgf_ChangeLeafEntrySize(mlgf_LeafPage*, One, Two, Two, Two,Two);
Boolean mlgf_CommonRegionTest(One, mlgf_DirectoryEntry*, mlgf_DirectoryEntry*);
void mlgf_CompactLeafPage(mlgf_LeafPage*, One,Two, Two);
Four mlgf_CompareMortonValue(mlgf_MortonValue*, mlgf_MortonValue*, Boolean);
Four mlgf_CreateOverflow(Two, PageID*, mlgf_LeafPage*, MLGF_KeyDesc*, Two);
Four mlgf_DeleteFromDirectory(mlgf_DirectoryPage*, MLGF_KeyDesc*, Two);
Four mlgf_DeleteObjectFromLeaf(Two, PageID*, mlgf_LeafPage*, MLGF_KeyDesc*, MLGF_HashValue[], Object*, mlgf_DirectoryEntry*, mlgf_DeleteStatus_T*);
Four mlgf_DeleteOverflow(Two, PageID*, PageID*, MLGF_KeyDesc*, MLGF_HashValue[], Object*, Four*);
Four mlgf_DumpDirectoryPage(Two, PageID*, FILE*);
Four mlgf_DumpLeafPage(Two, PageID*, Boolean, FILE*);
Four mlgf_DumpOverflowPage(Two, PageID*, Boolean, FILE*);
Boolean mlgf_EqualKeys(MLGF_KeyDesc*, MLGF_HashValue[], MLGF_HashValue[]);
Boolean mlgf_FindBuddyEntry(mlgf_DirectoryPage*, One, mlgf_DirectoryEntry*, Two*, One*);
Boolean mlgf_FindEntry(mlgf_DirectoryPage*, One, MLGF_HashValue[], Two*);
Four mlgf_FreePage(Two, PageID);
Four mlgf_GetHashValue(Two, AttributeHeader[], MLGF_HashValue[]);

Four mlgf_ExactMatchQueryRecursive(Two,QueryRegion[], PageID, MLGF_HashValue[], Four, AttributeHeader[],mlgf_MortonValue*);
void mcopy(void*, void*, int);
Two loadTwo(void*);
void setTwo(Two, void*);
Four loadFour(void* );
void setFour(Four, void*);
Two mlgf_leafGetNObjects(Two, mlgf_LeafEntry*);
void mlgf_leafSetNObjects(Two, mlgf_LeafEntry*, Two);
Two mlgf_leafGetTotalObjLen(Two, mlgf_LeafEntry*);
void mlgf_leafSetTotalObjLen(Two, mlgf_LeafEntry*, Two);
Two mlgf_leafEntryLength(Two, One, Two, Two);
Two mlgf_newLeafEntryLength(Two, One, Two);
Two mlgf_leafEntryObjctItemLen(Two, Object*);

void mlgf_GetMaxRegion(MLGF_KeyDesc*, mlgf_DirectoryPage*, mlgf_DirectoryEntry*, MLGF_HashValue[], mlgf_DirectoryEntry*);
Four mlgf_GetMortonValue(MLGF_HashValue[], One[], mlgf_MortonValue*, One);
void mlgf_GetHashValueForRangeQuery(Two, QueryRegion[], MLGF_HashValue[], MLGF_HashValue[]);
Four mlgf_GetObjectFromOverflow(Two, PageID*, MLGF_KeyDesc*, Object*);
Four mlgf_GetOpenFileTableEntry();
Four mlgf_InsertIntoDirectory(mlgf_DirectoryPage*, MLGF_KeyDesc*, mlgf_DirectoryEntry*);
Four mlgf_InsertOverflow(Two, PageID*, PageID*, MLGF_KeyDesc*, MLGF_HashValue[], Object*);
Four mlgf_MergeDirectoryPage(Two, mlgf_DirectoryPage*, MLGF_KeyDesc*, Two*, mlgf_DirectoryEntry*);
Four mlgf_MergeLeafPage(Two, mlgf_DirectoryPage*, MLGF_KeyDesc*, Two*, mlgf_DirectoryEntry*);
Four mlgf_ReadPage(Two, PageID, char*);
Boolean mlgf_SearchDirPageInMortonOrder(mlgf_DirectoryPage*, MLGF_KeyDesc*, mlgf_MortonValue*, Boolean, Two*);
Boolean mlgf_SearchLeafPageInMortonOrder(mlgf_LeafPage*, MLGF_KeyDesc*, mlgf_MortonValue*, Two*);
Boolean mlgf_SearchObjectArray(char*, Object*, Four, Two*, Four*, Two);
Four mlgf_SplitDirectoryPage(Two, PageID*, MLGF_KeyDesc*, mlgf_DirectoryEntry*, mlgf_DirectoryEntry*, mlgf_DirectoryEntry*);
void mlgf_SplitDirectoryRegion(mlgf_DirectoryPage*, One, mlgf_DirectoryEntry*, mlgf_DirectoryEntry*, mlgf_DirectoryEntry*, One*);
Four mlgf_SplitLeafPage(Two, PageID*, MLGF_KeyDesc*, MLGF_HashValue*, Object*, mlgf_DirectoryEntry*, mlgf_DirectoryEntry*);
void mlgf_SplitLeafRegion(mlgf_LeafPage*, MLGF_KeyDesc*, MLGF_HashValue[], mlgf_DirectoryEntry*, mlgf_DirectoryEntry*, One*);
Four mlgf_WritePage(Two, PageID, char*);


/* MLGF interface function prototypes */
Four MLGF_CloseIndex(Two);
Four MLGF_CreateIndex(One*, One, One, AttributeType[], MLGF_HashValue,One);
Four MLGF_DeleteObject(Two, AttributeHeader[]);
Four MLGF_Dump(Two, Boolean, FILE*);
char *MLGF_Error(Four);
Four MLGF_Final();
Four MLGF_Init(Four);
Four MLGF_InsertObject(Two, AttributeHeader[]);
Four MLGF_OpenIndex(One*, Two*);
Four MLGF_Query(Two, QueryRegion[], Four, AttributeHeader[]);

One MLGF_GetN_KeyAttr(Two);
One MLGF_GetN_Attr(Two);
Four MLGF_GetAttrType(Two, Two);
Two MLGF_GetAttrLength(Two, Two);
#endif /* _COMMON_H_ */

