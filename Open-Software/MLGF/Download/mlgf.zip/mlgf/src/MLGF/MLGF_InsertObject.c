/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: MLGF_InsertObject.c
 *
 * Description:
 *  Insert an ObjectID into the given MLGF index.
 *
 * Exports:
 *  Four MLGF_InsertObject(Two, AttributeHeader[])
 */


#include <assert.h>
#include "common.h"


/* Internal Fucntion Prototypes */
Four mlgf_InsertRecursive(Two, PageID*, MLGF_KeyDesc*, MLGF_HashValue[], Object*, mlgf_DirectoryEntry*,
							mlgf_DirectoryEntry*, mlgf_InsertStatus_T*);


/*
 * Function: Four MLGF_InsertObject(Two, AttributeHeader[])
 *
 * Description:
 *  Insert an ObjectID into the given MLGF index.
 *
 * Returns:
 *  Error code
 *    some errors caused by function calls
 */
Four MLGF_InsertObject(
	Two					mlgfd,					/* IN MLGF file descriptor */
	AttributeHeader		*attrValues)			/* IN array of attribute values (object) to insert */
{
    Four                e;                      /* error code */
    One                 i;                      /* index */
    Two                 entryLen;               /* length of a directory entry */
    PageID              newPid;                 /* PageID of the newly allocated page */
    mlgf_DirectoryPage  *newPage;               /* pointer to buffer for new page  */
    mlgf_DirectoryPage  *rootPage;              /* pointer to buffer for root page */
    mlgf_DirectoryEntry newEntry;               /* directory entry for new page */
    mlgf_DirectoryEntry rootEntry;              /* directory entry for old root page */
    mlgf_DirectoryEntry overflowInRoot;         /* directroy entry which are overflowed */
    mlgf_InsertStatus_T status;
	PageID				rootPid;				/* root page of MLGF */
	MLGF_KeyDesc		kdesc;					/* key descriptor of MLGF */
	MLGF_HashValue		keys[MLGF_MAXNUM_KEYS];	/* hash values of keys */
	Object				obj;					/* object to insert */
	char				*dataPtr;				/* pointer to data of object */
	Two					len;
#ifndef MBR_MLGF_BUFFER
    mlgf_DirectoryPage  newPageBuf;               /* buffer for new page  */
    mlgf_DirectoryPage  rootPageBuf;              /* buffer for root page */
	
	newPage = &newPageBuf;
	rootPage = &rootPageBuf;
#endif  /* MBR_MLGF_BUFFER */


    /* Check parameters. */
    if (!IS_VALID_MLGFD(mlgfd) || attrValues == NULL)
		ERR(eBADPARAMETER);

	if ( OPENFILE_CONTROL(mlgfd).useAdditionalFunc == FALSE)
	{
		for(i=0; i<OPENFILE_CONTROL(mlgfd).numOfAttrs; i++)
		{
			if (OPENFILE_CONTROL(mlgfd).attrType[i].dataType == VARSTRING)
			{
				ERR(eVARIABLELENGTHRECORD);
			}
		}
	}

	if ( OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
		len = sizeof(Two);
	else
		len = 0;

	dataPtr = &obj.data[0];
	for(i=0; i<OPENFILE_CONTROL(mlgfd).numOfAttrs; i++)
	{
		if (OPENFILE_CONTROL(mlgfd).attrType[i].dataType == VARSTRING)
		{
			if (ATTRIBUTE_LENGTH(&(attrValues[i])) > OPENFILE_CONTROL(mlgfd).attrType[i].length ||
					ATTRIBUTE_LENGTH(&(attrValues[i])) <= 0)
				ERR(eBADPARAMETER);
		}
		else
		{
			if (ATTRIBUTE_LENGTH(&(attrValues[i])) != OPENFILE_CONTROL(mlgfd).attrType[i].length)
				ERR(eBADPARAMETER);
		}
		
		switch(OPENFILE_CONTROL(mlgfd).attrType[i].dataType)
		{
			case INT:
				memcpy((char*)&dataPtr[len],
						(char*)INT_ATTRIBUTE(&(attrValues[i])),
						ATTRIBUTE_LENGTH(&(attrValues[i])));
				e = mlgf_GetHashValue(OPENFILE_CONTROL(mlgfd).attrType[i].dataType,
											&attrValues[i], &keys[i]);
				if(e<0) ERR(e);
				break;
			case FLOAT:
				memcpy((char*)&dataPtr[len],
						(char*)FLOAT_ATTRIBUTE(&(attrValues[i])),
						ATTRIBUTE_LENGTH(&(attrValues[i])));
				e = mlgf_GetHashValue(OPENFILE_CONTROL(mlgfd).attrType[i].dataType,
											&attrValues[i], &keys[i]);
				if(e<0) ERR(e);
				break;
			case STRING:
				memcpy((char*)&dataPtr[len],
						(char*)STRING_ATTRIBUTE(&(attrValues[i])),
						ATTRIBUTE_LENGTH(&(attrValues[i])));
				e = mlgf_GetHashValue(OPENFILE_CONTROL(mlgfd).attrType[i].dataType,
											&attrValues[i], &keys[i]);
				if(e<0) ERR(e);
				break;
			case VARSTRING:
				memcpy((char*)&dataPtr[len], (char*)&(ATTRIBUTE_LENGTH(&(attrValues[i]))), sizeof(Two));
				len += sizeof(Two);
				memcpy((char*)&dataPtr[len],
						(char*)STRING_ATTRIBUTE(&(attrValues[i])),
						ATTRIBUTE_LENGTH(&(attrValues[i])));
				e = mlgf_GetHashValue(OPENFILE_CONTROL(mlgfd).attrType[i].dataType,
											&attrValues[i], &keys[i]);
				if(e<0) ERR(e);
				break;
		}
		len += ATTRIBUTE_LENGTH(&(attrValues[i]));
	}
	if ( OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
	{
		len -= sizeof(Two);
		memcpy((char*)&dataPtr[0],&len,sizeof(Two));

	}

	rootPid = OPENFILE_CONTROL(mlgfd).rootPage;
	kdesc.flag = OPENFILE_CONTROL(mlgfd).flag;
	kdesc.nKeys = OPENFILE_CONTROL(mlgfd).numOfKeys;
	kdesc.objMaxLen = OPENFILE_CONTROL(mlgfd).objMaxLen;
	kdesc.minMaxTypeVector = OPENFILE_CONTROL(mlgfd).minMaxTypeVector;

    /* `rootEntry' is the entry for root page. */
    rootEntry.spid = rootPid.pageNo;
    rootEntry.theta = 0;	/* ignore this field for root page */
    for (i = 0; i < kdesc.nKeys; i++) rootEntry.nValidBits[i] = 0;

    do {
        /* call recursion */
        status.allFlags = 0;
        e = mlgf_InsertRecursive(mlgfd, &rootPid, &kdesc, keys, &obj, &rootEntry, &overflowInRoot, &status);
		if (e == eDUPLICATEDRECORD)	return(eDUPLICATEDRECORD);
		else if ( e == eDUPLICATEDKEY) return (eDUPLICATEDKEY);
		else if (e < 0) ERR(e);

        if (status.flags.overflow) {	/* root page split */
            /* Allocate a new page for the directory page. */
            e = mlgf_AllocPage(mlgfd, &newPid);
            if (e < 0) ERR(e);

#ifdef MBR_MLGF_BUFFER
            e = BfM_GetNewPage(OPENFILE_DSMSEGID(mlgfd), &newPid, (char**)&newPage);
            if (e < 0) ERR(e);

            /* Read the root page into the buffer. */
            e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &rootPid, (char**)&rootPage);
            if (e < 0) ERRB1(e, mlgfd, &newPid);
#else
			/* Read the root page into the buffer. */
			e = mlgf_ReadPage(mlgfd, rootPid, (char*)rootPage);
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

            /* Copy the root page contents to the new page. */
            MLGF_COPY_DIRECTORY_PAGE(newPage, newPid, rootPage, FALSE);

#ifdef MBR_MLGF_BUFFER
            e= BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &newPid);
            if (e < 0) ERRB2(e, mlgfd, &rootPid, &newPid);
#else
			e = mlgf_WritePage(mlgfd, newPid, (char*)newPage);
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

            rootEntry.spid = newPid.pageNo;
            e = mlgf_SplitDirectoryPage(mlgfd, &newPid, &kdesc, &overflowInRoot, &rootEntry, &newEntry);
#ifdef MBR_MLGF_BUFFER
            if (e < 0) ERRB2(e, mlgfd, &rootPid, &newPid);
#else
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

            /* 'entryLen' is the length of a directory entry. */
            entryLen = MLGF_DIRENTRY_LENGTH(kdesc.nKeys);

            /* Construct the new root page. */
            memcpy(&rootPage->data[0], (char*)&rootEntry, entryLen);
            memcpy(&rootPage->data[entryLen], (char*)&newEntry, entryLen);

            rootPage->hdr.nEntries = 2;
            rootPage->hdr.height ++;

#ifdef MBR_MLGF_BUFFER
            e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &newPid);
            if (e < 0) ERRB1(e, mlgfd, &rootPid);

            e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &rootPid);
            if (e < 0) ERRB1(e, mlgfd, &rootPid);

            e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &rootPid);
            if (e < 0) ERR(e);
#else
			e = mlgf_WritePage(mlgfd, rootPid, (char*)rootPage);
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
        }

    } while (!status.flags.objectInserted);

    return(eNOERROR);

} /* MLGF_InsertObject() */


/*
 * Module: Four mlgf_InsertRecursive(Two, PageID*, MLGF_KeyDesc*, MLGF_HashValue[], Object*, mlgf_DirectoryEntry*,
 *							mlgf_DirectoryEntry*, mlgf_InsertStatus_T*);
 *
 * Description:
 *  insert an object into mlgf index, recursively
 *
 * Returns:
 *  Error code
 */
Four mlgf_InsertRecursive(
	Two					mlgfd,					/* IN MLGF file descriptor */
    PageID              *root,                  /* IN root of subtree */
    MLGF_KeyDesc        *kdesc,                 /* IN key descriptor of MLGF */
    MLGF_HashValue      *keys,                  /* IN hash values of keys */
	Object				*obj,					/* IN object to insert */
    mlgf_DirectoryEntry *entryToRoot,           /* INOUT entry which indicates parent */
    mlgf_DirectoryEntry *overflowInRoot,        /* OUT entry which failed to insert */
    mlgf_InsertStatus_T *status)                /* INOUT current status */
{
    Four                e;                      /* error code */
    Boolean             isTmp;
    Two                 entryNo;                /* index to some entry */
    Two                 entryLen;               /* length of a directory entry */
    One                 buddyKey;               /* key on which buddys can be merged */
    PageID              child;                  /* PageID of the child page */
    PageID              newPid;                 /* PageID of the newly allocated page */
    Boolean             found;                  /* TRUE if we find something */
    Boolean             insertEntryFlag;        /* TRUE when we are to insert an entry in root */
    mlgf_Page           *apage;                 /* an MLGF page */
    mlgf_Page           *newPage;               /* an MLGF page */
    mlgf_DirectoryEntry *entryToChild;          /* entry pointing the child page */
    mlgf_DirectoryEntry entryToChild_tmp;       /* temporary copy for new update */
    mlgf_DirectoryEntry overflowInChild;        /* entry overflowed in child page */
    MLGF_HashValue      *hx, *hy;               /* points to arrary of hash values in an entry */
    One                 k;
#ifndef MBR_MLGF_BUFFER
    mlgf_Page           apageBuf;                 /* buffer for an MLGF page */
    mlgf_Page           newPageBuf;               /* buffer for an MLGF page */
	
	apage = &apageBuf;
	newPage = &newPageBuf;
#endif  /* MBR_MLGF_BUFFER */


    /* Read the current page into the buffer. */
#ifdef MBR_MLGF_BUFFER
    e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), root, (char**)&apage);
    if (e < 0) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, *root, (char*)apage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    if (apage->any.hdr.type & MLGF_LEAFPAGE) { /* leaf page */

	/* insert the new object into the leaf page */
	e = mlgf_InsertIntoLeaf(mlgfd, root, &apage->leaf, kdesc, keys, obj, entryToRoot, status); 
#ifdef MBR_MLGF_BUFFER
	if (e == eDUPLICATEDRECORD)
	{
		e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), root);
		if (e < 0) ERR(e);

		return(eDUPLICATEDRECORD);
	}
	else if ( e == eDUPLICATEDKEY)
	{
		e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), root);
		if (e < 0) ERR(e);

		return(eDUPLICATEDKEY);
	}
	else if (e < 0) ERRB1(e, mlgfd, root);
#else
	if (e == eDUPLICATEDRECORD)	return(eDUPLICATEDRECORD);
	else if ( e== eDUPLICATEDKEY) return ( eDUPLICATEDKEY);
	else if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

#ifdef MBR_MLGF_BUFFER
		e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), root);
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

		return(eNOERROR);
    }

    /* From this point, the page is a directory page. */

    /* Initialize 'insertEntryFlag' to FALSE. */
    /* It has TRUE when we should insert a new entry into current page. */
    insertEntryFlag = FALSE;

    /* Calculate the length of a directory entry. */
    entryLen = MLGF_DIRENTRY_LENGTH(kdesc->nKeys);

    /* find region to go next time */
    found = mlgf_FindEntry(&apage->directory, kdesc->nKeys, keys, &entryNo);

    /*
     * If found is FALSE, it means that we are inserting
     * record into empty region.
     * So we first find mergable(buddy) region.
     * If we find one, insert record into that region,
     * else allocate new page.
     */
    if (found) {
	entryToChild = MLGF_ITH_DIRENTRY(&apage->directory, entryNo, entryLen);

	MAKE_PAGEID(child, root->volNo, entryToChild->spid);

    } else {

	status->flags.objectInEmptyRegion = 1;

	/* find maximum region which buddy entry can contain. */
	mlgf_GetMaxRegion(kdesc, &apage->directory, entryToRoot, keys, overflowInRoot);

	/* find buddy region */
	found = mlgf_FindBuddyEntry(&apage->directory, kdesc->nKeys, overflowInRoot, &entryNo, &buddyKey);

	if (found) {
		/* Buddy region should not exist since regions are always maximized */
		printf("Error : Buddy region should not exist since regions are always maximized (in %s:%d)\n", __FILE__, __LINE__);

		/* Follwings are temporary codes to handle the case in which buddy region exist */

	    entryToChild = MLGF_ITH_DIRENTRY(&apage->directory, entryNo, entryLen);

            memcpy(overflowInRoot, entryToChild, entryLen);
            overflowInRoot->nValidBits[buddyKey] -- ;

            e = mlgf_DeleteFromDirectory(&apage->directory, kdesc, entryNo);
#ifdef MBR_MLGF_BUFFER
            if (e < 0) ERRB1(e, mlgfd, root);
#else
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	    e = mlgf_InsertIntoDirectory(&apage->directory, kdesc, overflowInRoot);
#ifdef MBR_MLGF_BUFFER
            if (e < 0) ERRB1(e, mlgfd, root);
#else
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

            found = mlgf_FindEntry(&apage->directory, kdesc->nKeys, keys, &entryNo);
            assert(found == TRUE);

            entryToChild = MLGF_ITH_DIRENTRY(&apage->directory, entryNo, entryLen);
	    MAKE_PAGEID(child, root->volNo, entryToChild->spid);

#ifdef MBR_MLGF_BUFFER
	    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), root);
		if (e < 0) ERRB1(e, mlgfd, root);
#else
		e = mlgf_WritePage(mlgfd, *root, (char*)apage);
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	} else {
	    /* Allocate a page for the child. */
        e = mlgf_AllocPage(mlgfd, &newPid);
#ifdef MBR_MLGF_BUFFER
		if (e < 0) ERRB1(e, mlgfd, root);
#else
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
            
	    /* Read the leaf page into the buffer. */
#ifdef MBR_MLGF_BUFFER
	    e = BfM_GetNewPage(OPENFILE_DSMSEGID(mlgfd), &newPid, (char**)&newPage);
	    if (e < 0) {
			ERRB1(e, mlgfd, root);
	    }
#endif  /* MBR_MLGF_BUFFER */

	    if (apage->directory.hdr.height == 1) /* child is the leaf page. */

            MLGF_INIT_LEAF_PAGE(&newPage->leaf, FALSE, newPid);
	    else
               MLGF_INIT_DIRECTORY_PAGE(&newPage->directory, FALSE,
                                        newPid, apage->directory.hdr.height - 1, FALSE);

#ifdef MBR_MLGF_BUFFER
        e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &newPid);
        if (e < 0) ERRB1(e, mlgfd, root);

	    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &newPid);
	    if (e < 0) {
			ERRB1(e, mlgfd, root);
	    }
#else
		e = mlgf_WritePage(mlgfd, newPid, (char*)newPage);
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	    overflowInRoot->spid = newPid.pageNo;
	    entryToChild = overflowInRoot;
	    MAKE_PAGEID(child, root->volNo, entryToChild->spid);
	    insertEntryFlag = TRUE;
	    entryNo = MLGF_NOENTRY;
	}
    }

    /* go to next page */
    memcpy(&entryToChild_tmp, entryToChild, entryLen);
    e = mlgf_InsertRecursive(mlgfd, &child, kdesc, keys, obj, &entryToChild_tmp, &overflowInChild, status);
#ifdef MBR_MLGF_BUFFER
	if (e == eDUPLICATEDRECORD)
	{
		e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), root);
		if (e < 0) ERR(e);

		return(eDUPLICATEDRECORD);
	}
	else if ( e== eDUPLICATEDKEY)
	{
		e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), root);
		if (e < 0) ERR(e);

		return(eDUPLICATEDKEY);

	}
	else if (e < 0) ERRB1(e, mlgfd, root);
#else
	if (e == eDUPLICATEDRECORD)	return(eDUPLICATEDRECORD);
	else if ( e== eDUPLICATEDKEY) return(eDUPLICATEDKEY);
	else if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    if (status->flags.thetaUpdated) {

        entryToChild->theta = entryToChild_tmp.theta;
#ifdef MBR_MLGF_BUFFER
        e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), root);
        if (e < 0) ERR(e);
#else
		e = mlgf_WritePage(mlgfd, *root, (char*)apage);
        if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

        status->flags.thetaUpdated = 0;
    }

    if (status->flags.mbrUpdated) {

        hx = MLGF_DIRENTRY_HASHVALUEPTR(entryToChild, kdesc->nKeys);
        hy = MLGF_DIRENTRY_HASHVALUEPTR(&entryToChild_tmp, kdesc->nKeys);

        for (k = 0; k < kdesc->nKeys; k++) hx[k] = hy[k];

#ifdef MBR_MLGF_BUFFER
		e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), root);
        if (e < 0) ERR(e);
#else
		e = mlgf_WritePage(mlgfd, *root, (char*)apage);
        if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

        status->flags.mbrUpdated = 0;

        /*
        ** Update the MBR of the entry 'entryToRoot'
        */
        hx = MLGF_DIRENTRY_HASHVALUEPTR(entryToRoot, kdesc->nKeys);
        for (k = 0; k < kdesc->nKeys; k++) {

            if ((MLGF_KEYDESC_IS_MINTYPE(*kdesc, k) && (hx[k] > hy[k])) ||
                (MLGF_KEYDESC_IS_MAXTYPE(*kdesc, k) && (hx[k] < hy[k]))) {
                hx[k] = hy[k];
                status->flags.mbrUpdated = 1;
            }
        }
    }

    if (insertEntryFlag == TRUE) {

        /*
        ** Update the MBR of the entry 'entryToRoot'
        */
        hx = MLGF_DIRENTRY_HASHVALUEPTR(entryToRoot, kdesc->nKeys);
        hy = MLGF_DIRENTRY_HASHVALUEPTR(overflowInRoot, kdesc->nKeys);
        for (k = 0; k < kdesc->nKeys; k++) {

            if ((MLGF_KEYDESC_IS_MINTYPE(*kdesc, k) && (hx[k] > hy[k])) ||
                (MLGF_KEYDESC_IS_MAXTYPE(*kdesc, k) && (hx[k] < hy[k]))) {
                hx[k] = hy[k];
                status->flags.mbrUpdated = 1;
            }
        }
    }

    if (status->flags.overflow) {
	/* Split the child page. */
	if (apage->directory.hdr.height == 1) { /* child is the leaf page. */

	    e = mlgf_SplitLeafPage(mlgfd, &child, kdesc, keys, obj, &entryToChild_tmp, overflowInRoot);
	} else
	    e = mlgf_SplitDirectoryPage(mlgfd, &child, kdesc, &overflowInChild, &entryToChild_tmp, overflowInRoot);

#ifdef MBR_MLGF_BUFFER
	if (e < 0) ERRB1(e, mlgfd, root);
#else
    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	/* entryToChild was updated in the previous call. */
    memcpy(entryToChild, &entryToChild_tmp, entryLen);
#ifdef MBR_MLGF_BUFFER
	e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), root);
    if (e < 0) ERR(e);
#else
	e = mlgf_WritePage(mlgfd, *root, (char*)apage);
    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	status->flags.overflow = 0;
	insertEntryFlag = TRUE;
    }

    if (insertEntryFlag) {
	if (apage->directory.hdr.nEntries < MLGF_MAX_DIRENTRIES(kdesc->nKeys)) {

	    /* Insert a new entry. */
	    e = mlgf_InsertIntoDirectory(&apage->directory, kdesc, overflowInRoot);
#ifdef MBR_MLGF_BUFFER
        if (e < 0) ERRB1(e, mlgfd, root);
#else
	    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	    entryToRoot->theta += entryLen;
        status->flags.thetaUpdated = 1;

#ifdef MBR_MLGF_BUFFER
	    e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), root);
        if (e < 0) ERRB1(e, mlgfd, root);

#else
		e = mlgf_WritePage(mlgfd, *root, (char*)apage);
	    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	} else
	    status->flags.overflow = 1;
    }

#ifdef MBR_MLGF_BUFFER
    e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), root);
    if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    return(eNOERROR);

} /* mlgf_InsertRecursive() */
