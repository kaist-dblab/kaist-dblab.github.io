/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: MLGF_Query.c
 *
 * Description:
 *  Find objects in the given region from the mlgf file.
 * 	Called with 'objs' NULL, this just returns the number of objects
 *  in the given region.
 *  Return the number of objects in the given region.
 *  Return eTOOMANYRECORDS if the buffer is too small to return the result
 *  (In this case we return with `records' filled with 'num'-th records.)
 *
 * Exports:
 *  Four MLGF_Query(Two, QueryRegion[], Four, AttributeHeader[])
 */

#include 		<sys/types.h>
#include		<sys/timeb.h>
#include        "common.h"

/* internal function prototype */
Four mlgf_QueryRecursive(Two, QueryRegion[], PageID, MLGF_HashValue[], MLGF_HashValue[], Four, AttributeHeader[]);


/*
 * Function: MLGF_Query(Two mlgfd, QueryRegion *region, Four num, AttributeHeader *records)
 * 
 * Description:
 *  Find objects in the given region from the mlgf file.
 *  Called with 'objs' NULL, this just returns the number of objects
 *  in the given region.
 *  Return the number of objects in the given region.
 *  Return eTOOMANYRECORDS if the buffer is too small to return the result
 *  (In this case we return with `records' filled with 'num'-th records.)
 * 
 * Returns:
 *  1) The number of objects in the given region
 *  2) Error code
 *    eBADPARAMETER
 *    eMEMORYALLOCERR
 *    some errors caused by function calls
 */
Four MLGF_Query(
	Two				mlgfd,			/* IN MLGF file descriptor */
    QueryRegion		*region,        /* IN query region */
	Four			num,			/* IN size of the prepared buffer for query result */
	AttributeHeader	*records)		/* OUT space to return the result */
{
	Two			i;
    Two         k;
    Four        nRecords;       /* number of records matched */
    PageID      rootPageID;     /* root page ID */
    MLGF_HashValue	*minHashValues;	/* minimum hash values of the query region */
    MLGF_HashValue	*maxHashValues;	/* maximum hash values of the query region */
	One			nValidBits[MLGF_MAXNUM_KEYS];
	mlgf_MortonValue	keyMortonVal;
	mlgf_MortonValue   *keyMortonPtr;
	Two exactMatch;

    /* check parameters */
    if(!IS_VALID_MLGFD(mlgfd))	ERR(eBADPARAMETER);
    for(k = 0; k < OPENFILE_CONTROL(mlgfd).numOfKeys; k++) {
		if(region[k].fullDomainFlag == TRUE)
			continue;
		else if(OPENFILE_CONTROL(mlgfd).attrType[k].dataType == VARSTRING) {
            if(region[k].minKey.length > OPENFILE_CONTROL(mlgfd).attrType[k].length ||
                region[k].maxKey.length > OPENFILE_CONTROL(mlgfd).attrType[k].length)
				ERR(eBADPARAMETER);
        } else {
            if(region[k].minKey.length != OPENFILE_CONTROL(mlgfd).attrType[k].length ||
                region[k].maxKey.length != OPENFILE_CONTROL(mlgfd).attrType[k].length)
				ERR(eBADPARAMETER);
        }
    }
  
	if ( OPENFILE_CONTROL(mlgfd).useAdditionalFunc == FALSE)
	{
		for(i=0; i<OPENFILE_CONTROL(mlgfd).numOfAttrs; i++)
		{
			if (OPENFILE_CONTROL(mlgfd).attrType[i].dataType == VARSTRING)
			{
				ERR(eVARIABLELENGTHRECORD);
			}
		}
	}

    /* get root page ID */
    rootPageID = OPENFILE_CONTROL(mlgfd).rootPage;


    /* Get hash values of the keys. */
    minHashValues = (MLGF_HashValue*)malloc(sizeof(MLGF_HashValue)*NUM_OF_KEYS(mlgfd));
    if(minHashValues == NULL) ERR(eMEMORYALLOCERR);
    maxHashValues = (MLGF_HashValue*)malloc(sizeof(MLGF_HashValue)*NUM_OF_KEYS(mlgfd));
    if(maxHashValues == NULL) {
        free(maxHashValues);
		ERR(eMEMORYALLOCERR);
    }

	/* get hash value for range query and find query type */


	(void) mlgf_GetHashValueForRangeQuery(mlgfd, region, minHashValues, maxHashValues);
   	nRecords = mlgf_QueryRecursive(mlgfd, region, rootPageID, minHashValues, maxHashValues, num, records);

    free(minHashValues);
    free(maxHashValues);

    return(nRecords);
}


/*
 * Function: mlgf_QueryRecursive(Two, QueryRegion[], PageID, MLGF_HashValue[], MLGF_HashValue[], Four, AttributeHeader[])
 *
 * Description:
 *  Recursive function that traverse the MLGF tree to find objects
 *  in the given range.
 *
 * Returns:
 *  1) The number of objects in the given region
 *  2) Error code
 *    eTOOMANYRECORDS
 *    some errors caused by function calls
 */
Four mlgf_QueryRecursive(
	Two				mlgfd,			/* IN MLGF file descriptor */
	QueryRegion		*region,		/* IN query region */
	PageID			currentPageID,	/* IN current page ID */
	MLGF_HashValue	*minHashValues,	/* IN hash value of minimum keys */
	MLGF_HashValue	*maxHashValues, /* IN hash value of maximum keys */
	Four			num,			/* IN size of the prepared buffer for query result */
	AttributeHeader	*records)		/* space to return the result */
{
    int	 	e;		/* error code */
    Two					i, j, k;
	Two					entryLen;		/* length of a directory entry */
	Two					varAttrValLen;	/* length of attribute value of VARSTRING type */
    Four				nRecords;		/* number of records in the query region of a subtree */
    Four				totalRecords;	/* number of records in the query region */
	Four				currentOffset;	/* offset of current object */
	char				*objectItem;	/* starting point of object item of object list */
	char				*attrValue;		/* point to an attribute value in object item */
    PageID				nextPageID;		/* page ID to go next time */
	PageID				ovPageID;		/* page ID of overflow page */
	mlgf_Page			*apage;			/* an MLGF page */
	mlgf_OverflowPage	*opage;			/* an overflow page */
	mlgf_DirectoryEntry	*dirEntry;		/* a directory entry */
	mlgf_LeafEntry		*leafEntry;		/* a leaf entry */
	MLGF_KeyDesc		kdesc;			/* key descriptor of this index */
	MLGF_HashValue		min, max;		/* range of hash values represented by an entry */
	MLGF_HashValue		*hashVector;	/* vector of hash values */
	Two					loc;
#ifndef MBR_MLGF_BUFFER
	mlgf_Page			apageBuf;		/* buffer for an MLGF page */
	mlgf_OverflowPage	opageBuf;		/* buffer an overflow page */

	apage = &apageBuf;
	opage = &opageBuf;
#endif  /* MBR_MLGF_BUFFER */


	kdesc.flag = OPENFILE_CONTROL(mlgfd).flag;
	kdesc.nKeys = OPENFILE_CONTROL(mlgfd).numOfKeys;
	kdesc.objMaxLen = OPENFILE_CONTROL(mlgfd).objMaxLen;
	kdesc.minMaxTypeVector = OPENFILE_CONTROL(mlgfd).minMaxTypeVector;
    
    
	/* Read the current page into the buffer. */
#ifdef MBR_MLGF_BUFFER
	e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &currentPageID, (char**)&apage);
	if (e < 0) ERR(e);
#else
	e = mlgf_ReadPage(mlgfd, currentPageID, (char*)apage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

	if(apage->any.hdr.type & MLGF_LEAFPAGE) {	/* leaf page */

		/* find the objects in the given range */
		totalRecords = 0;	/* `totalRecords' denotes the number of objects in the leaf&overflow page. */
		for(i=0; i<apage->leaf.hdr.nEntries; i++)
		{
			leafEntry = MLGF_ITH_LEAFENTRY(&apage->leaf, i);

			/* compare the hash values. */
			for(k=0; k<kdesc.nKeys; k++)
			{
				if(leafEntry->keys[k] < minHashValues[k] || leafEntry->keys[k] > maxHashValues[k])
					break;
			}

			/* go to the top of the loop if this entry is not matched. */
			if(k < kdesc.nKeys)
				continue;

			/* current entry has objects in the given region. */
			if ( mlgf_leafGetNObjects(mlgfd,leafEntry) >=0 ) {
				/* points to the first object of the current entry. */
			 //	objectItem = MLGF_LEAFENTRY_FIRST_OBJECT(kdesc.nKeys, leafEntry);
			 	objectItem = MLGF_LEAFENTRY_FIRST_OBJECT(OPENFILE_CONTROL(mlgfd).useAdditionalFunc,kdesc.nKeys, leafEntry);

				
				for(j=0; j< mlgf_leafGetNObjects(mlgfd,leafEntry); j++)
				{
					if (records == NULL)
					{
						/* just count the number of objects. */
						++totalRecords;
					}
					else
					{
						if(++totalRecords > num) {
#ifdef MBR_MLGF_BUFFER
							e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &currentPageID);
							if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

							return(eTOOMANYRECORDS);
						}

						if (OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
							loc = sizeof(Two);
						else
							loc = 0;
						/* copy the object to recordPtr */
						attrValue = &((Object*)objectItem)->data[loc];
						for(k=0; k<OPENFILE_CONTROL(mlgfd).numOfAttrs; k++)
						{
							switch(OPENFILE_CONTROL(mlgfd).attrType[k].dataType)
							{
								case INT:
									memcpy((char*)INT_ATTRIBUTE(records),	(char*)attrValue,
											OPENFILE_CONTROL(mlgfd).attrType[k].length);
									ATTRIBUTE_LENGTH(records) = OPENFILE_CONTROL(mlgfd).attrType[k].length;
									attrValue += OPENFILE_CONTROL(mlgfd).attrType[k].length;
									break;
								case FLOAT:
									memcpy((char*)FLOAT_ATTRIBUTE(records),	(char*)attrValue,
											OPENFILE_CONTROL(mlgfd).attrType[k].length);
									ATTRIBUTE_LENGTH(records) = OPENFILE_CONTROL(mlgfd).attrType[k].length;
									attrValue += OPENFILE_CONTROL(mlgfd).attrType[k].length;
									break;
								case STRING:
									memcpy((char*)STRING_ATTRIBUTE(records),	(char*)attrValue,
											OPENFILE_CONTROL(mlgfd).attrType[k].length);
									ATTRIBUTE_LENGTH(records) = OPENFILE_CONTROL(mlgfd).attrType[k].length;
									attrValue += OPENFILE_CONTROL(mlgfd).attrType[k].length;
									break;
								case VARSTRING:
									varAttrValLen = *((Two*)attrValue);
									memcpy((char*)STRING_ATTRIBUTE(records),	(char*)attrValue+sizeof(Two),
											varAttrValLen);
									ATTRIBUTE_LENGTH(records) = varAttrValLen;
									attrValue = attrValue + sizeof(Two) + varAttrValLen;
									break;
							}
							
							records++;
						}
					}

					/* points to the next object. */
					objectItem = objectItem + mlgf_leafEntryObjectItemLen(mlgfd,((Object*)objectItem));
				}
			} else {	/* overflow entry */
				MAKE_PAGEID(ovPageID, currentPageID.volNo,
						MLGF_LEAFENTRY_FIRST_OVERFLOW(kdesc.nKeys, leafEntry));

				do {
					/* Read the overflow page into the buffer. */
#ifdef MBR_MLGF_BUFFER
					e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &ovPageID, (char**)&opage);
					if (e < 0) ERRB1(e, mlgfd, &currentPageID);
#else
					e = mlgf_ReadPage(mlgfd, ovPageID, (char*)opage);
					if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

					currentOffset = 0;
					for(j=0; j<opage->hdr.nObjects; j++)
					{
						objectItem = &opage->data[currentOffset];

						if (records == NULL)
						{
							/* just count the number of objects. */
							++totalRecords;
						}
						else
						{
							if(++totalRecords > num) {
#ifdef MBR_MLGF_BUFFER
								e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &ovPageID);
								if (e < 0) ERRB1(e, mlgfd, &currentPageID);
#endif  /* MBR_MLGF_BUFFER */

								return(eTOOMANYRECORDS);
							}

							/* copy the object to recordPtr */

						if (OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
							loc = sizeof(Two);
						else
							loc = 0;

							attrValue = &((Object*)objectItem)->data[loc];
							for(k=0; k<OPENFILE_CONTROL(mlgfd).numOfAttrs; k++)
							{
								switch(OPENFILE_CONTROL(mlgfd).attrType[k].dataType)
								{
									case INT:
										memcpy((char*)INT_ATTRIBUTE(records),	(char*)attrValue,
												OPENFILE_CONTROL(mlgfd).attrType[k].length);
										ATTRIBUTE_LENGTH(records) = OPENFILE_CONTROL(mlgfd).attrType[k].length;
										attrValue += OPENFILE_CONTROL(mlgfd).attrType[k].length;
										break;
									case FLOAT:
										memcpy((char*)FLOAT_ATTRIBUTE(records),	(char*)attrValue,
												OPENFILE_CONTROL(mlgfd).attrType[k].length);
										ATTRIBUTE_LENGTH(records) = OPENFILE_CONTROL(mlgfd).attrType[k].length;
										attrValue += OPENFILE_CONTROL(mlgfd).attrType[k].length;
										break;
									case STRING:
										memcpy((char*)STRING_ATTRIBUTE(records),	(char*)attrValue,
												OPENFILE_CONTROL(mlgfd).attrType[k].length);
										ATTRIBUTE_LENGTH(records) = OPENFILE_CONTROL(mlgfd).attrType[k].length;
										attrValue += OPENFILE_CONTROL(mlgfd).attrType[k].length;
										break;
									case VARSTRING:
										varAttrValLen = *((Two*)attrValue);
										memcpy((char*)STRING_ATTRIBUTE(records),	(char*)attrValue+sizeof(Two),
												varAttrValLen);
										ATTRIBUTE_LENGTH(records) = varAttrValLen;
										attrValue = attrValue + sizeof(Two) + varAttrValLen;
										break;
								}

								records++;
							}
						}

						/* points to the next object. */
						currentOffset += mlgf_leafEntryObjectItemLen(mlgfd,((Object*)objectItem));
					}

#ifdef MBR_MLGF_BUFFER
					e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &ovPageID);
					if (e < 0) ERRB1(e, mlgfd, &currentPageID);
#endif  /* MBR_MLGF_BUFFER */

					/* get the PageID of the next overflow page. */
					ovPageID.pageNo = opage->hdr.nextPage;
				} while(!IS_NILPAGEID(ovPageID));
			}
		}

#ifdef MBR_MLGF_BUFFER
		e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &currentPageID);
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

		return(totalRecords);
    }
    
	/* Get the length of a directory entry. */
	entryLen = MLGF_DIRENTRY_LENGTH(kdesc.nKeys);

	/* find the entry in the given range. */
    for(totalRecords = 0, i = 0; i < apage->directory.hdr.nEntries; i++) {

		dirEntry = MLGF_ITH_DIRENTRY(&apage->directory, i, entryLen);

		hashVector = MLGF_DIRENTRY_HASHVALUEPTR(dirEntry, kdesc.nKeys);

        for(k = 0; k < kdesc.nKeys; k++) {
			if (MLGF_KEYDESC_IS_MINTYPE(kdesc,k)) {
				min = hashVector[k];
				max = MLGF_HASHVALUE_SET_EXCEPT_UPPER_N_BITS(dirEntry->nValidBits[k]) | hashVector[k];
			} else {	/* max type attribute */
				min = MLGF_HASHVALUE_MASK_UPPER_N_BITS(hashVector[k], dirEntry->nValidBits[k]);
				max = hashVector[k];
			}

			if (min > maxHashValues[k] || max < minHashValues[k]) break;
        }

        /* if the region has some common region with this entry, go recursively */
        if(k == kdesc.nKeys) {
			MAKE_PAGEID(nextPageID, currentPageID.volNo, dirEntry->spid);
    		nRecords = mlgf_QueryRecursive(mlgfd, region, nextPageID, minHashValues, maxHashValues, num, records);
            if(nRecords < 0) {
#ifdef MBR_MLGF_BUFFER
				e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &currentPageID);
				if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

				return(nRecords);
			}

            if(records != NULL) {
                num -= nRecords;
                records += nRecords*OPENFILE_CONTROL(mlgfd).numOfAttrs;
            }
            totalRecords += nRecords;
        }
    }

#ifdef MBR_MLGF_BUFFER
		e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &currentPageID);
		if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

    return(totalRecords);
}

