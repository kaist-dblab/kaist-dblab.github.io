/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_CompactPage.c
 *
 * Description:
 *  Includes page compage routines.
 *
 * Exports:
 *  void mlgf_CompactLeafPage(mlgf_LeafPage*, One, Two)
 */


#include "common.h"


/*
 * Function: void mlgf_CompactLeafPage(mlgf_LeafPage*, One, Two)
 *
 * Description:
 *  Reorganizes the leaf page to make sure the unused bytes in the page
 *  are located contiguously "in the middle", between the entries and the
 *  slot array. To compress out holes, entries must be moved toward the
 *  beginning of the page.
 *
 * Return Values :
 *  None
 *
 * Side Effects :
 *  The leaf page is reorganized to comact the space.
 */
void mlgf_CompactLeafPage(
    mlgf_LeafPage       *apage,                 /* INOUT leaf page to compact */
    One                 nKeys,                  /* IN # of keys */
    Two					slotNo,                 /* IN slot to go to the boundary of free space */
    Two					mlgfd)					/* IN MLGF file descriptor */
{
    mlgf_LeafPage       tpage;                  /* temporay page used to save the given page */
    Two                 apageDataOffset;        /* where the next object is to be moved */
    Two                 len;                    /* length of the leaf entry */
    Two                 i;                      /* index variable */
    mlgf_LeafEntry      *entry;                 /* an entry in leaf page */


    /* save the slotted page */
    tpage = *apage;

    apageDataOffset = 0;	/* start at the beginning of the data area */

    for (i = 0; i < tpage.hdr.nEntries; i++)
	if (i != slotNo) {

	    /* 'entry' points to the currently moved leaf entry. */
	    entry = MLGF_ITH_LEAFENTRY(&tpage, i); 

	    /* copy the entire entry to the reorganized page */
	     len = MLGF_LEAFENTRY_LENGTH(OPENFILE_CONTROL(mlgfd).useAdditionalFunc,nKeys, mlgf_leafGetTotalObjLen(mlgfd,entry),mlgf_leafGetNObjects(mlgfd,entry));

	    memcpy(&apage->data[apageDataOffset], (char*)entry, len);
	    apage->slot[-i] = apageDataOffset;

	    apageDataOffset += len; /* make it point the next move position */
	}

    if (slotNo != NIL) {

	/* move the specified object to the end */

	/* 'entry' points to the currently moved leaf entry. */
	entry =  MLGF_ITH_LEAFENTRY(&tpage, slotNo); 

	/* copy the entire entry to the reorganized page */
	 len = MLGF_LEAFENTRY_LENGTH(OPENFILE_CONTROL(mlgfd).useAdditionalFunc,nKeys, mlgf_leafGetTotalObjLen(mlgfd,entry),mlgf_leafGetNObjects(mlgfd,entry));

	memcpy(&apage->data[apageDataOffset], (char*)entry, len);
	apage->slot[-slotNo] = apageDataOffset;

	apageDataOffset += len; /* make it point the next move position */
    }

    /* set the control variables */
    apage->hdr.free = apageDataOffset; /* start pos. of contiguous space */
    apage->hdr.unused = 0;		   /* no fragmented unused space */


} /* mlgf_CompactLeafPage() */
