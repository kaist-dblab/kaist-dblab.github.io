/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_FindEntry.c
 *
 * Description:
 *  Find an entry corresponding to the region which contains the given point.
 *
 * Exports:
 *  Boolean mlgf_FindEntry(mlgf_DirectroyPage*, One, MLGF_HashValue[], Two*)
 *
 * Returns:
 *  TRUE : if there is an entry associated with a region conaining the given point.
 *  FALSE : otherwise.
 */


#include "common.h"


Boolean mlgf_FindEntry(
    mlgf_DirectoryPage  *dirPage,               /* IN a directory page */
    One                 nKeys,                  /* IN # of keys of MLGF */
    MLGF_HashValue      *keys,                  /* IN hash values of keys */
    Two                 *entryNo)               /* OUT entry which includes the keys */
{
    Two                 i;                      /* index variable */
    One                 j;                      /* index variable */
    Two                 entryLen;               /* length of a directroy entry */
    MLGF_HashValue      xor;                    /* XOR value of two hash values */
    One                 *entryNumValidBits;     /* points to nValidBits[] field in an entry */
    MLGF_HashValue      *entryHashValues;       /* points to array of hash values in an entry */
    mlgf_DirectoryEntry *entry;                 /* a directory entry of MLGF */


    /* Calculate the directory entry length. */
    entryLen = MLGF_DIRENTRY_LENGTH(nKeys);

    /*
    ** Find an entry containing the given point.
    */
    /* first entry */
    entry = (mlgf_DirectoryEntry*)&dirPage->data[0];
    entryNumValidBits = entry->nValidBits;
    entryHashValues = MLGF_DIRENTRY_HASHVALUEPTR(entry, nKeys);

    for (i = 0; i < dirPage->hdr.nEntries; i++) {

	for (j = 0; j < nKeys; j++) {
	    if (entryNumValidBits[j] == 0) continue;

	    xor = entryHashValues[j] ^ keys[j];

	    if ((xor >> (MLGF_MAXNUM_VALIDBITS - entryNumValidBits[j])) != 0) break;
	}

	if (j == nKeys) {	/* found */
	    *entryNo = i;
	    return(TRUE);
	}

	/* Points to the nValidBits field in the next entry. */
	entryNumValidBits = entryNumValidBits + entryLen;

	/* Points to the field, hashValues[] in the next entry. */
	entryHashValues = (MLGF_HashValue*)((char*)entryHashValues + entryLen);
    }

    return(FALSE);

} /* mlgf_FindEntry() */
