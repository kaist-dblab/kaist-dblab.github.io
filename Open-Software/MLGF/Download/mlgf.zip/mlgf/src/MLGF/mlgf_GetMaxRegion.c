/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_GetMaxRegion.c
 *
 * Description:
 *  Initially 'regionVector' contains a point. We increase the region as big
 *  as possible. The region cannot be bigger than the directory page region
 *  and cannot overlap other regions in the same directory page..
 *
 * Exports:
 *  void mlgf_GetMaxRegion(MLGF_KeyDesc*, mlgf_DirectoryPage*, mlgf_DirectoryEntry*, MLGF_HashValue[], mlgf_DirectoryEntry*)
 *
 * Returns:
 *  None
 */


#include "common.h"


void mlgf_GetMaxRegion(
    MLGF_KeyDesc        *kdesc,         /* IN key descriptor of MLGF */
    mlgf_DirectoryPage  *dirPage,       /* IN a directory page */
    mlgf_DirectoryEntry *parentEntry,   /* IN entry for directory page */
    MLGF_HashValue      *keys,          /* IN keys of a point */
    mlgf_DirectoryEntry *childEntry)    /* OUT entry for the given point */
{
    One                 i;
    Two                 j;              /* index variables */
    Two                 entryLen;       /* length of a directory entry */
    MLGF_HashValue      *hx;            /* pointer to array of hash values */
    Boolean             changeFlag;     /* TRUE if a change occurs */
    mlgf_DirectoryEntry *otherEntry;    /* temporary directory entries */


    /* Calculate the length of a directory entry. */
    entryLen = MLGF_DIRENTRY_LENGTH(kdesc->nKeys);

    /* 'hx' points to array of hash values of the given region vector. */
    hx = MLGF_DIRENTRY_HASHVALUEPTR(childEntry, kdesc->nKeys);

    /* Initialize 'childEntry'. */
    for (i = 0; i < kdesc->nKeys; i++) {
	childEntry->nValidBits[i] = parentEntry->nValidBits[i];
	hx[i] = keys[i];
    }

    /* find the split starting point; this method is valid when using cyclic split policy */
    for (i = 1; i < kdesc->nKeys; i++)
	if (childEntry->nValidBits[i-1] != childEntry->nValidBits[i]) break;
    if (i == kdesc->nKeys) i = 0;

    for ( ; ; ) {
	/* test if the entry has common region */
	/* with other regions in directory page or not */
	for (j = 0; j < dirPage->hdr.nEntries; j++) {
	    otherEntry = (mlgf_DirectoryEntry*)&dirPage->data[entryLen*j];
	    if (mlgf_CommonRegionTest(kdesc->nKeys, childEntry, otherEntry) == TRUE) break;
	}

	/* If there is no region conflict, then the region is maximized. */
	if (j == dirPage->hdr.nEntries) break;

	/* There is a region conflict. */
	/* increase the number of valid bits by 1. */
	childEntry->nValidBits[i] ++;
	i = (i+1) % kdesc->nKeys;
    }

    /*
     * Set MBR.
     */
    for (i = 0; i < kdesc->nKeys; i++) {
        if (MLGF_KEYDESC_IS_MINTYPE(*kdesc, i))
            hx[i] &= MLGF_HASHVALUE_ALL_BITS_SET; /* set maximum value */
        else
            hx[i] &= MLGF_HASHVALUE_UPPER_N_BITS_SET(childEntry->nValidBits[i]); /* set minimum value */
    }

} /* mlgf_GetMaxRegion() */
