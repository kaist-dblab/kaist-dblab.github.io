/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_InsertIntoDirectory.c
 *
 * Description:
 *  Insert a directory entry into the directory page.
 *
 * Exports:
 *  Four mlgf_InsertIntoDirectory(mlgf_DirectoryPage*, MLGF_KeyDesc*, mlgf_DirectoryEntry*)
 *
 * Returns:
 *  None
 */


#include "common.h"


Four mlgf_InsertIntoDirectory(
    mlgf_DirectoryPage  *dirPage,       /* INOUT where the new entry is inserted */
    MLGF_KeyDesc        *kdesc,         /* IN key descriptor of used index */
    mlgf_DirectoryEntry *insertedEntry) /* IN entry to be inserted */
{
    Four                e;              /* error code */
    Two                 entryNo;        /* index on entry array */
    Two                 entryLen;       /* length of a directory entry */
    mlgf_MortonValue    morton;         /* morton value of the inserted index */
    mlgf_DirectoryEntry *entry;         /* points to the insertion position */
    Two                 i;


    /* Get the length of a directory entry. */
    entryLen = MLGF_DIRENTRY_LENGTH(kdesc->nKeys);

    /* Get the morton value of the inserted entry. */
    mlgf_GetMortonValue(MLGF_DIRENTRY_HASHVALUEPTR(insertedEntry, kdesc->nKeys),
			insertedEntry->nValidBits, &morton, kdesc->nKeys);

    mlgf_SearchDirPageInMortonOrder(dirPage, kdesc, &morton, TRUE, &entryNo); 

    /* 'entry' points to the insertion position. */
    entry = MLGF_ITH_DIRENTRY(dirPage, entryNo, entryLen);

    /* Make room for the inserted index. */
    memmove((char*)entry+entryLen, entry, (dirPage->hdr.nEntries-entryNo)*entryLen);

    /* Insert the new entry. */
    memcpy((char*)entry, (char*)insertedEntry, entryLen);

    /* increase the number of entries in directory page. */
    dirPage->hdr.nEntries ++;

    return(eNOERROR); 

} /* mlgf_InsertIntoDirectory() */
