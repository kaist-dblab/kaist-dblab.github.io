/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_InsertIntoLeaf.c
 *
 * Description:
 *  Insert an object into the given leaf page.
 *  It is assumed that there is no overflow because the caller has checked
 *  the free space before calling.
 */


#include "common.h"


Four mlgf_InsertIntoLeaf(
	Two							mlgfd,					/* IN MLGF file descriptor */
    PageID                      *root,                  /* IN  root page ID */ 
    mlgf_LeafPage               *apage,                 /* INOUT pointer to a leaf page */
    MLGF_KeyDesc                *kdesc,                 /* IN key descriptor for MLGF */
    MLGF_HashValue              keys[],                 /* IN hash values of key values */
	Object						*obj,					/* IN object to insert */
    mlgf_DirectoryEntry         *entryToLeaf,           /* INOUT entry pointing to this leaf page */
    mlgf_InsertStatus_T         *status)                /* INOUT program current status */
{
    Four                        e;                      /* error code */
    One                         i, k;					/* temporary index variable */
    Two                         elemNo;                 /* index on object array */
    Two                         entryLen;               /* length of a leaf entry */
    Two                         neededSpace;            /* amount of space needed to insert new object */
    Two                         entryNo;                /* slot No. of entry with the given keys */
    char                        *objectItemPtr;         /* points to object item where the new object will be inserted */
    PageID                      ovPid;                  /* PageID of the first overflow page of an entry */
    Boolean                     found;                  /* TRUE if we find something to want */
    mlgf_LeafEntry              *entry;                 /* points to leaf entry */
    mlgf_MortonValue            keyMortonVal;           /* mroton value for the key */
    One                         nValidBits[MLGF_MAXNUM_KEYS]; /* used for getting morton value */
    MLGF_HashValue              *entryHashValues;       /* points to arrary of hash values in an entry */
	Four						elemOffset;				/* element offset of the object in object array */
    Two							nObjects;				/* number of object */
    Two							totalObjLen;			/* length of total object */
    Two							len;					/* length of entry */
	Two							dupType;				/* duplicated type */

    /* If the object is to be inserted into the empty region, there should
       be an SMO before this call. Try the insertion again. */
    if (status->flags.objectInEmptyRegion == 1) return(eNOERROR);


    /* Get the morton value of the keys. */
    for (i = 0; i < kdesc->nKeys; i++)
	nValidBits[i] = MLGF_MAXNUM_VALIDBITS;

    mlgf_GetMortonValue(keys, nValidBits, &keyMortonVal, kdesc->nKeys);


    /* Search the leaf page for the entry whose keys are equal to the given keys. */
    found = mlgf_SearchLeafPageInMortonOrder(apage, kdesc, &keyMortonVal, &entryNo);

    if (found) {		/* same keys exist */
	entry = MLGF_ITH_LEAFENTRY(apage, entryNo);

	if (mlgf_leafGetNObjects(mlgfd,entry) < 0) { /* overflow chain */

	    /* Get the PageID of the first overflow page. */
	    MAKE_PAGEID(ovPid, apage->hdr.pid.volNo, MLGF_LEAFENTRY_FIRST_OVERFLOW(kdesc->nKeys, entry));

	    /* Insert the new object into the overflow chain. */
	    dupType = mlgf_InsertOverflow(mlgfd, root, &ovPid, kdesc, keys, obj); 
		if ( dupType != FALSE )
		{
			switch( OPENFILE_CONTROL(mlgfd).useAdditionalFunc )
			{
				case FALSE :
				{
					if ( dupType == WHOLE_SAME )
						return (eDUPLICATEDRECORD);
					else if ( dupType == KEY_SAME)
						return (eDUPLICATEDKEY);
				}
				case TRUE :
					return (eDUPLICATEDRECORD);
			}
		}	

	    status->flags.objectInserted = 1;

	} else {		/* normal entry */
 	      entryLen = MLGF_LEAFENTRY_LENGTH(OPENFILE_CONTROL(mlgfd).useAdditionalFunc,kdesc->nKeys, mlgf_leafGetTotalObjLen(mlgfd,entry), mlgf_leafGetNObjects(mlgfd,entry));
	     neededSpace = mlgf_leafEntryObjectItemLen(mlgfd,obj);
		/* check if the same object already exist. */
		

		dupType = mlgf_SearchObjectArray(MLGF_LEAFENTRY_FIRST_OBJECT(OPENFILE_CONTROL(mlgfd).useAdditionalFunc,kdesc->nKeys, entry), obj, mlgf_leafGetNObjects(mlgfd,entry), &elemNo, &elemOffset,mlgfd);
		if ( dupType != FALSE )
		{
			switch( OPENFILE_CONTROL(mlgfd).useAdditionalFunc )
			{
				case FALSE :
				{
					if ( dupType == WHOLE_SAME )
						return (eDUPLICATEDRECORD);
					else if ( dupType == KEY_SAME)
						return (eDUPLICATEDKEY);
				}
				case TRUE :
					return (eDUPLICATEDRECORD);
			}
		}

	    if (entryLen + neededSpace > MLGF_OP_IN_THRESHOLD) {
		/* make an overflow chain */
		e = mlgf_CreateOverflow(mlgfd, root, apage, kdesc, entryNo);
		if (e < 0) ERR(e);
                
	    } else {
		if (neededSpace > MLGF_LP_FREE(apage)) {
                    status->flags.overflow = 1;
                    return(eNOERROR);
                }

                e = mlgf_ChangeLeafEntrySize(apage, kdesc->nKeys, entryNo, entryLen, entryLen + neededSpace,mlgfd);
                if (e < 0) ERR(e);

                /* In mlgf_ChangeLeafEntrySize(), entry may be moved to someplace. */
                entry = MLGF_ITH_LEAFENTRY(apage, entryNo);

		/* points to the insert position. */
		if ( OPENFILE_CONTROL(mlgfd).useAdditionalFunc)
			 objectItemPtr = (char*)((entry)->keys + kdesc->nKeys+1) + mlgf_leafGetTotalObjLen(mlgfd,entry);
		else
			 objectItemPtr = (char*)((entry)->keys + kdesc->nKeys) + mlgf_leafGetTotalObjLen(mlgfd,entry);

		totalObjLen = mlgf_leafGetTotalObjLen(mlgfd,entry);
		mlgf_leafSetTotalObjLen(mlgfd,entry,totalObjLen + neededSpace);
	 	nObjects = mlgf_leafGetNObjects(mlgfd,entry);
		mlgf_leafSetNObjects(mlgfd,entry,nObjects+1);
                status->flags.objectInserted = 1;
	    }

#ifdef MBR_MLGF_BUFFER
            e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &apage->hdr.pid);
            if (e < 0) ERR(e);
#else
			e = mlgf_WritePage(mlgfd, apage->hdr.pid, (char*)apage);
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
	}

    } else {	
		// not found
		/* need a new entry */
	/* We also need space for slot array. */
	len = mlgf_leafEntryObjectItemLen(mlgfd,obj);
	 neededSpace = MLGF_NEW_LEAFENTRY_LENGTH(OPENFILE_CONTROL(mlgfd).useAdditionalFunc,kdesc->nKeys, len + sizeof(Two));

	if (neededSpace > MLGF_LP_FREE(apage)) {
            status->flags.overflow = 1;
            return(eNOERROR);
        }

	if (neededSpace > MLGF_LP_CFREE(apage))
	    mlgf_CompactLeafPage(apage, kdesc->nKeys, NIL,mlgfd);

	/* Allocate space for the new object. */
	/* move slot values */
        MLGF_INSERT_SLOTS_IN_MLGF_PAGE(apage, entryNo, 1);
	apage->slot[-entryNo] = apage->hdr.free;
	apage->hdr.nEntries++;
	apage->hdr.free += (neededSpace - sizeof(Two));

	/* Insert entry. */
	entry = MLGF_ITH_LEAFENTRY(apage, entryNo);
	mlgf_leafSetNObjects(mlgfd,entry,1);
	len = mlgf_leafEntryObjectItemLen(mlgfd,obj);
	mlgf_leafSetTotalObjLen(mlgfd,entry,len);
	for (i = 0; i < kdesc->nKeys; i++) entry->keys[i] = keys[i];
	objectItemPtr = MLGF_LEAFENTRY_FIRST_OBJECT(OPENFILE_CONTROL(mlgfd).useAdditionalFunc,kdesc->nKeys, entry);

	len = mlgf_leafEntryObjectItemLen(mlgfd,obj);
	memcpy((char*)objectItemPtr, (char*)obj, len);

	status->flags.objectInserted = 1;
#ifdef MBR_MLGF_BUFFER
	e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &apage->hdr.pid);
    if (e < 0) ERR(e);
#else
	e = mlgf_WritePage(mlgfd, apage->hdr.pid, (char*)apage);
	if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
    }

    /*
     * Update 'THETA' value
     */
    if (MLGF_LP_THETA(apage) != entryToLeaf->theta) {
        entryToLeaf->theta = MLGF_LP_THETA(apage);
        status->flags.thetaUpdated = 1;
    }

    /*
    ** Update the MBR of the entry 'entryToLeaf'
    */
    if (status->flags.objectInserted) {
        entryHashValues = MLGF_DIRENTRY_HASHVALUEPTR(entryToLeaf, kdesc->nKeys);
        for (k = 0; k < kdesc->nKeys; k++) {

            if ((MLGF_KEYDESC_IS_MINTYPE(*kdesc, k) && (entryHashValues[k] > keys[k])) ||
                (MLGF_KEYDESC_IS_MAXTYPE(*kdesc, k) && (entryHashValues[k] < keys[k]))) {
                entryHashValues[k] = keys[k];
                status->flags.mbrUpdated = 1;
            }
        }
    }

    return(eNOERROR);

} /* mlgf_InsertIntoLeaf() */
