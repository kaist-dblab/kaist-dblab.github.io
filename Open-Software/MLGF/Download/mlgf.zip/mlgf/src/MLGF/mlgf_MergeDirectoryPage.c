/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_MergeDirectoryPage.c
 *
 * Description:
 *  Merge two directory pages into one.
 */


#include <assert.h>
#include "common.h"


Four mlgf_MergeDirectoryPage(
	Two					mlgfd,					/* IN mlgf file descriptor */
    mlgf_DirectoryPage  *dirPage,               /* INOUT a directory page */
    MLGF_KeyDesc        *kdesc,                 /* IN key descriptor of used index */
    Two                 *mergedEntryNo,			/* IN entry to be merged */
												/* OUT merged entry */
	mlgf_DirectoryEntry	*entryToDirPage)		/* IN entry for this directory page */
{
    Four                e;                      /* error code */
	Two					i;						/* index variable */
    Two                 entryLen;               /* the length of a directory entry */
    Two                 buddyEntryNo;           /* entry no of buddy entry of merged entry */
    One                 buddyKey;               /* attribute no of buddy key */
	One					buddyKey_tmp;			/* attribute no of buddy key */
    PageID              pid;                    /* a temporary PageID */
    PageID              mergePid;
    Boolean             found;                  /* TRUE if buddy entry is found */
    Boolean             mergeFlag;              /* TRUE if a merge occurs */
    mlgf_DirectoryPage  *mergedPage;            /* merged directory page */
    mlgf_DirectoryPage  *buddyPage;             /* buddy page of merged directory page */
    mlgf_DirectoryEntry *mergedEntry;           /* entry for merged page */
    mlgf_DirectoryEntry *buddyEntry;            /* entry for buddy page of merged page */
    mlgf_DirectoryEntry buddyEntry_old;         /* old version of buddy entry */
	mlgf_DirectoryEntry	mergedEntry_tmp;		/* temporary copy of entry for new update */
    MLGF_HashValue      *extremeHashValues_x, *extremeHashValues_y;     /* points to array of extreme(= min or max) hash values */
	MLGF_HashValue		bitmask;				/* bitmask for fiding buddy */
    One                 k;
#ifndef MBR_MLGF_BUFFER
    mlgf_DirectoryPage  mergedPageBuf;			/* buffer for merged directory page */
    mlgf_DirectoryPage  buddyPageBuf;			/* buffer for buddy page of merged directory page */

	mergedPage = &mergedPageBuf;
	buddyPage = &buddyPageBuf;
#endif  /* MBR_MLGF_BUFFER */

#ifndef NDEBUG
   // Four count = 0;
#endif


    /* Calculate the length of a directory entry. */
    entryLen = MLGF_DIRENTRY_LENGTH(kdesc->nKeys);

    mergedEntry = MLGF_ITH_DIRENTRY(dirPage, *mergedEntryNo, entryLen);

    mergeFlag = FALSE;		/* Intialize mergeFlag to FALSE. */

    /* Repeat until the merge is impossible. */
    for ( ; ; ) {

		/* Get the domain number of buddy key */
		for (buddyKey=0; buddyKey<kdesc->nKeys-1; buddyKey++) {
			if (mergedEntry->nValidBits[buddyKey] != mergedEntry->nValidBits[buddyKey+1])
				break;
		}

		/* if the # of valid bits of the entry is same that of parent, finish the merge process */
		if(mergedEntry->nValidBits[buddyKey] == entryToDirPage->nValidBits[buddyKey]) break;

		/* Get bit mask used for finding the buddy */
		bitmask = MLGF_HASHVALUE_ITH_BIT_SET(mergedEntry->nValidBits[buddyKey]);

		/* Find the buddy entry with non-empty region. */
		found = FALSE;
		if (MLGF_DIRENTRY_HASHVALUEPTR(mergedEntry, kdesc->nKeys)[buddyKey] & bitmask) {	// buddy entry is a previous entry
			buddyEntryNo = *mergedEntryNo - 1;
			if (buddyEntryNo >= 0) {
				buddyEntry = MLGF_ITH_DIRENTRY(dirPage, buddyEntryNo, entryLen);
				if (mlgf_BuddyTest(kdesc->nKeys, mergedEntry, buddyEntry, &buddyKey_tmp))
					found = TRUE;
			}
		} else {	// buddy entry is a next entry	
			buddyEntryNo = *mergedEntryNo + 1;
			if (buddyEntryNo < dirPage->hdr.nEntries) {
				buddyEntry = MLGF_ITH_DIRENTRY(dirPage, buddyEntryNo, entryLen);
				if (mlgf_BuddyTest(kdesc->nKeys, mergedEntry, buddyEntry, &buddyKey_tmp))
					found = TRUE;
			}
		}

		if (!found) {	/* if there is not buddy region, exit the loop. */
			/* Check whether there is a mergable buddy with empty region */
			/* copy the mergedEntry */
			memcpy(&mergedEntry_tmp, mergedEntry, entryLen);

			/* decrease # of valid bits:  expand the region */
			mergedEntry_tmp.nValidBits[buddyKey]--;

			/* test if the entry has common region with other entries in directory page or not */
			/* since entries are sorted in z-order, it is enough to test with previous or next entry */
			if (mlgf_CommonRegionTest(kdesc->nKeys, buddyEntry, &mergedEntry_tmp) == TRUE) {
				/* there is a entry that has common region */
				/* i.e., there is not a mergable buddy with empty region */
				/* finish the merge process */
				break;
			} else {
				/* there is no entry that has common region */
				/* i.e., there is a mergable buddy with empty region */
				/* merge the mergedEntry with the buddy with empty region */
				memcpy(mergedEntry->nValidBits, mergedEntry_tmp.nValidBits, kdesc->nKeys);
				mergeFlag = TRUE;
			}
		} else {	/* if there is the buddy entry with non-empty region */
			assert(buddyKey == buddyKey_tmp);

			/* there is not enough space to merge two pages */
			if (mergedEntry->theta + buddyEntry->theta > PAGESIZE - MLGF_DP_FIXED)
			    break;


			/* From now, merge the mergedEntry with the buddy entry with non-empty region */

			mergeFlag = TRUE;

			if (buddyEntryNo > *mergedEntryNo) { /* swap two entries */
			    buddyEntryNo = *mergedEntryNo;
			    *mergedEntryNo = buddyEntryNo + 1;

			    buddyEntry = MLGF_ITH_DIRENTRY(dirPage, buddyEntryNo, entryLen);
			    mergedEntry = MLGF_ITH_DIRENTRY(dirPage, *mergedEntryNo, entryLen);
			}


			/*
			 * Merge the page pointed by 'mergedEntry'
			 * into the page pointed by 'buddyEntry'.
			 */

			/* get PageIDs of buddy page and merged page */
			MAKE_PAGEID(pid, dirPage->hdr.pid.volNo, buddyEntry->spid);
			MAKE_PAGEID(mergePid, dirPage->hdr.pid.volNo, mergedEntry->spid);

#ifdef MBR_MLGF_BUFFER
			/* Read the buddy page into the buffer. */
			e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &pid, (char**)&buddyPage);
			if (e < 0) ERR(e);

			/* Read the merged page into the buffer. */
			e = BfM_GetPage(OPENFILE_DSMSEGID(mlgfd), &mergePid, (char**)&mergedPage);
			if (e < 0) {
			    ERRB1(e, mlgfd, &pid);
			}
#else
			e = mlgf_ReadPage(mlgfd, pid, (char*)buddyPage);
			if (e < 0) ERR(e);

			e = mlgf_ReadPage(mlgfd, mergePid, (char*)mergedPage);
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

			/* move entries in 'mergedPage' into the 'buddyPage' */
			memcpy((char*)MLGF_ITH_DIRENTRY(buddyPage, buddyPage->hdr.nEntries, entryLen),
			       (char*)MLGF_ITH_DIRENTRY(mergedPage, 0, entryLen),
			       mergedPage->hdr.nEntries*entryLen);


			/* Increase the # of entries in buddyPage. */
			buddyPage->hdr.nEntries += mergedPage->hdr.nEntries;

#ifdef MBR_MLGF_BUFFER
			e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &mergePid);
			if (e < 0) ERRB1(e, mlgfd, &pid);
#endif  /* MBR_MLGF_BUFFER */

			e = mlgf_FreePage(mlgfd, mergePid);
#ifdef MBR_MLGF_BUFFER
			if (e < 0) ERRB1(e, mlgfd, &pid);
#else
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */

			/* Update the buddyEntry. */
	        memcpy(&buddyEntry_old, buddyEntry, entryLen);
			buddyEntry->nValidBits[buddyKey] --;
			buddyEntry->theta = MLGF_DP_THETA(buddyPage, entryLen);

	        /*
	         * Set the MBR of the buddy page
	         */
	        extremeHashValues_x = MLGF_DIRENTRY_HASHVALUEPTR(buddyEntry, kdesc->nKeys);
	        extremeHashValues_y = MLGF_DIRENTRY_HASHVALUEPTR(mergedEntry, kdesc->nKeys);
	        for (k = 0; k < kdesc->nKeys; k++) {

			    if (MLGF_KEYDESC_IS_MINTYPE(*kdesc, k)) {
		                if (extremeHashValues_x[k] > extremeHashValues_y[k]) extremeHashValues_x[k] = extremeHashValues_y[k];
            	} else { /* MAXTYPE */
	                if (extremeHashValues_x[k] < extremeHashValues_y[k]) extremeHashValues_x[k] = extremeHashValues_y[k];
	            }
	        }

#ifdef MBR_MLGF_BUFFER
			e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &pid);
			if (e < 0) ERRB1(e, mlgfd, &pid);

			e = BfM_FreePage(OPENFILE_DSMSEGID(mlgfd), &pid);
			if (e < 0) ERR(e);
#else
			e = mlgf_WritePage(mlgfd, pid, (char*)buddyPage);
			if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
        
			/* Delete 'mergedEntry'. */
			e = mlgf_DeleteFromDirectory(dirPage, kdesc, *mergedEntryNo);
			if (e < 0) ERR(e);

			mergedEntry = buddyEntry;
			*mergedEntryNo = buddyEntryNo;
	    }
	}

    if (mergeFlag) {

#ifdef MBR_MLGF_BUFFER
        e = BfM_SetDirty(OPENFILE_DSMSEGID(mlgfd), &dirPage->hdr.pid);
        if (e < 0) ERR(e);
#else
		e = mlgf_WritePage(mlgfd, dirPage->hdr.pid, (char*)dirPage);if (e < 0) ERR(e);
#endif  /* MBR_MLGF_BUFFER */
    }

    assert(dirPage->hdr.nEntries != 0);

    return(eNOERROR);

} /* mlgf_MergeDirectoryPage() */
