/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

/*
 * Module: mlgf_Morton.c
 *
 * Description:
 *  Morton Order Value Handling Routines
 *
 * Exports:
 *  Four mlgf_GetMortonValue(MLGF_HashValue[], One[], mlgf_MortonValue*, One)
 *  Boolean mlgf_SearchDirPageInMortonOrder(mlgf_DirectoryPage*, MLGF_KeyDesc*,
 *                                          mlgf_MortonValue*, Two*)
 *  Boolean mlgf_SearchLeafPageInMortonOrder(mlgf_LeafPage*, MLGF_KeyDesc*,
 *                                           mlgf_MortonValue*, Two*)
 *
 * Assumes:
 *  cyclic split and merge with the splitted buddy
 */


#include "common.h"


/*
 * Function: Four mlgf_GetMortonValue(MLGF_HashValue[], One[], mlgf_MortonValue*, One)
 *
 * Description:
 *  Get the Morton order value from the hash values.
 *
 * Returns:
 *  number of bits to be used in morton value
 */
Four mlgf_GetMortonValue(
    MLGF_HashValue              hash[],         /* IN hash values */
    One                         nValidBits[],   /* IN number of valid bits of each hash value */
    mlgf_MortonValue            *morton,        /* OUT Morton order values */
    One                         nKeys)          /* IN # of hash values */
{
    UFour						i;
    One                         j;
    register UFour				*mortonPtr;     /* pointer to destination */
    register MLGF_HashValue     srcMask;        /* mask for source */
    register MLGF_HashValue     dstMask;        /* mask for destination */


    /* Initialize the destination mask. */
    dstMask = MLGF_MORTONVALUE_MSB_SET;

    /* Clear all bits. */
    memset((char*)(morton->val), 0, sizeof(MLGF_HashValue)*nKeys);

    mortonPtr = morton->val;

    srcMask = MLGF_HASHVALUE_MSB_SET;
    for (i = 0; i < MLGF_MAXNUM_VALIDBITS; i++, srcMask >>= (unsigned)CONSTANT_ONE) {

	for (j = 0; j < nKeys; j++) {

	    if (i >= nValidBits[j]) {
                morton->nBits = i*nKeys + j;
                return(morton->nBits);
            }

	    /* Set the correspondent bit if the source bit is set. */
	    if (hash[j] & srcMask) *mortonPtr |= dstMask;

	    dstMask >>= (unsigned)1;
	    if (!dstMask) {
                dstMask = MLGF_MORTONVALUE_MSB_SET;
		mortonPtr ++;	/* points to the next element */
	    }
	}
    }

    morton->nBits = nKeys*MLGF_MAXNUM_VALIDBITS;

    return(morton->nBits);

} /* mlgf_GetMortonValue() */




/*
 * Function: Four mlgf_CompareMortonValue(mlgf_MortonValue*, mlgf_MortonValue*, Boolean)
 *
 * Description:
 *  Compare two morton values.
 *
 * Returns:
 *  Result of comparison
 *    EQUAL : morton_x and morton_y are same
 *    GREAT : morton_x is greater than morton_y
 *    LESS  : morton_x is less than morton_y
 */
Four mlgf_CompareMortonValue(
    mlgf_MortonValue            *morton_x,              /* IN morton value of x */
    mlgf_MortonValue            *morton_y,              /* IN morton value of y */
    Boolean                     fullCompareFlag)        /* IN comare full value if TRUE, compare only valid bits otherwise */
{
    register One                i;
    UFour						remainedBits;
    UFour						mask;
    UFour						nBits;


    nBits = MIN(morton_x->nBits, morton_y->nBits);


    for (i = 0; i < nBits/(sizeof(morton_x->val[0])*CHAR_BIT); i++) {
	if (morton_x->val[i] > morton_y->val[i]) return(GREAT);

	if (morton_x->val[i] < morton_y->val[i]) return(LESS);
    }

    remainedBits = nBits % (sizeof(morton_x->val[0]) * CHAR_BIT);

    if (remainedBits > 0) {
        mask = MLGF_MORTONVALUE_UPPER_N_BITS_SET(remainedBits);

	if ((morton_x->val[i]&mask) > (morton_y->val[i]&mask)) return(GREAT);
	if ((morton_x->val[i]&mask) < (morton_y->val[i]&mask)) return(LESS);
    }

    if (!fullCompareFlag) return(EQUAL); /* same value when compare only valid bits */

    if (morton_x->nBits > morton_y->nBits) return(GREAT);
    if (morton_x->nBits < morton_y->nBits) return(LESS);

    return(EQUAL);

} /* mlgf_CompareMortonValue() */



/*
 * Function: Boolean mlgf_SearchDirPageInMortonOrder(mlgf_DirectoryPage*,
 *                                    MLGF_KeyDesc*, mlgf_MortonValue*, Two*)
 *
 * Description:
 *  Search a directory page for the entry whose morton value is the smallest
 *  but not less than the given morton value. When a directory entry's
 *  morton value is comapred, only the valid bits are used in the comparison.
 *
 * Returns:
 *  TRUE if we find an entry which includes the key serarched for
 *  FALSE otherwise
 */
Boolean mlgf_SearchDirPageInMortonOrder(
    mlgf_DirectoryPage  *dirPage,               /* IN a directory page */
    MLGF_KeyDesc        *kdesc,                 /* IN key descriptor */
    mlgf_MortonValue    *keyMortonVal,          /* IN mroton value for the key */
    Boolean             fullCompareFlag,        /* IN compare full value if TRUE */
    Two                 *entryNo)               /* OUT entry no to be returned */
{
    Four                cmp;                    /* result of comparison */
    Two                 entryLen;               /* length of a directory entry */
    Two                 low, mid, high;         /* variables for binary search */
    mlgf_DirectoryEntry *dirEntry;              /* a directory entry */
    mlgf_MortonValue    entryMortonVal;         /* morton value for the entry */
	Four				count;

	count=0;

    /* Get the directory entry length. */
    entryLen = MLGF_DIRENTRY_LENGTH(kdesc->nKeys);

    low = 0;
    high = dirPage->hdr.nEntries - 1;

    while (low <= high) {
	mid = (low + high) / 2;

	/* dirEntry points to 'mid'-th entry. */
	dirEntry = MLGF_ITH_DIRENTRY(dirPage, mid, entryLen);

	mlgf_GetMortonValue(MLGF_DIRENTRY_HASHVALUEPTR(dirEntry, kdesc->nKeys),
                            dirEntry->nValidBits, &entryMortonVal, kdesc->nKeys);

	/* Compare the search_for_key's morton value to the entry morton value. */
	cmp = mlgf_CompareMortonValue(keyMortonVal, &entryMortonVal, fullCompareFlag);
	count++;
	if (cmp == EQUAL) {	/* found!!! */
	    *entryNo = mid;
	    return(TRUE);
	}

	if (cmp == LESS) high = mid - 1;
	else low = mid + 1;
    }

    *entryNo = low;
    return(FALSE);		/* not found!!! */

} /* mlgf_SearchDirPageInMortonOrder() */



/*
 * Function: Boolean mlgf_SearchLeafPageInMortonOrder(mlgf_LeafPage*,
 *                                    MLGF_KeyDesc*, mlgf_MortonValue*, Two*)
 *
 * Description:
 *  Search a leaf page for the entry whose morton value is the smallest
 *  but not less than the given morton value.
 *
 * Returns:
 *  TRUE if we find an entry which includes the key serarched for
 *  FALSE otherwise
 */
Boolean mlgf_SearchLeafPageInMortonOrder(
    mlgf_LeafPage       *leafPage,              /* IN a leaf page */
    MLGF_KeyDesc        *kdesc,                 /* IN key descriptor */
    mlgf_MortonValue    *keyMortonVal,          /* IN mroton value for the key */
    Two                 *entryNo)               /* OUT entry no to be returned */
{
    One                 i;
    Four                cmp;                    /* result of comparison */
    Two                 low, mid, high;         /* variables for binary search */
    mlgf_LeafEntry      *entry;                 /* a leaf entry */
    mlgf_MortonValue    entryMortonVal;         /* morton value for the entry */
    One                 nValidBits[MLGF_MAXNUM_KEYS]; /* used for getting morton value */


    /* Initialize the array of number of valid bits used for Morton Value. */
    for (i = 0; i < MLGF_MAXNUM_KEYS; i++)
	nValidBits[i] = MLGF_MAXNUM_VALIDBITS;


    low = 0;
    high = leafPage->hdr.nEntries - 1;

    while (low <= high) {
	mid = (low + high) / 2;

	/* entry points to 'mid'-th entry. */
	entry = MLGF_ITH_LEAFENTRY(leafPage, mid);

	mlgf_GetMortonValue(entry->keys, nValidBits, &entryMortonVal, kdesc->nKeys);

	/* Compare the search_for_key's morton value to the entry morton value. */
	cmp = mlgf_CompareMortonValue(keyMortonVal, &entryMortonVal, TRUE);

	if (cmp == EQUAL) {	/* found!!! */
	    *entryNo = mid;
	    return(TRUE);
	}

	if (cmp == LESS) high = mid - 1;
	else low = mid + 1;
    }

    *entryNo = low;
    return(FALSE);		/* not found!!! */

} /* mlgf_SearchLeafPageInMortonOrder() */


