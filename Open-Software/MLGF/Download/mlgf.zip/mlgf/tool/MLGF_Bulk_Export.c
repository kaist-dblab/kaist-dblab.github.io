/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "mlgf.h"


#define ERROR(e, msg)\
{\
	printf("%s : (error code %d) %s\n", msg, e, MLGF_Error(e));\
	exit(1);\
}
#define ERROR_CHECK(e, msg)	if(e < eNOERROR) ERROR(e, msg);


int main(int argc, char *argv[])
{
	int		i;	/* index */
	int		e;	/* error code */
	char	*mlgfFileName;	/* mlgf file name */
	char	*outputDataFileName;	/* output data file name */
	FILE	*fd;	/* output data file descriptor */
	Two		mlgfd;	/* mlgf file descriptor */
	Two		nKeyAttr;	/* # of organizing (key) attributes */
	Two		nAttr;	/* # of attributes */


	/* parse parameters */
	if(argc < 2)
	{
		printf("USAGE : MLGF_Bulk_Export <mlgf file name> <output data file name>\n");
		exit(1);
	}
	else
	{
		mlgfFileName = argv[1];
		outputDataFileName = argv[2];
	}

	printf("### MLGF Bulk Export starts\n");

	/* init MLGF */
	e = MLGF_Init(NUM_BUFS);
	ERROR_CHECK(e, "MLGF_Init()");

	/* open the MLGF file */
	e = MLGF_OpenIndex(mlgfFileName, &mlgfd);
	ERROR_CHECK(e, "MLGF_OpenIndex()");

	printf("\n# MLGF file is opend.\n");

	/* get and print out MLGF info. */
	nKeyAttr = MLGF_GetN_KeyAttr(mlgfd);
	nAttr = MLGF_GetN_Attr(mlgfd);
	printf("\t- # of attributes: %d\n", nAttr);
	for(i=0; i<nAttr; i++)
	{
		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				printf("\t- Type of the attr #%d: INT", i+1); 
				break;
			case FLOAT:
				printf("\t- Type of the attr #%d: FLAOT", i+1); 
				break;
			case STRING:
				printf("\t- Type of the attr #%d: STRING(%d)", i+1, MLGF_GetAttrLength(mlgfd, i)); 
				break;
			case VARSTRING:
				printf("\t- Type of the attr #%d: VARSTRING(%d)", i+1, MLGF_GetAttrLength(mlgfd, i)); 
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}

		if(i < nKeyAttr)
		{
			printf(" (organizing (key) attr)\n");
		}
		else
		{
			printf("\n");
		}
	}

	/* open the output data file */
	fd = fopen(outputDataFileName, "wb");
	if(fd == NULL)
	{
		printf("Output data file open failed.\n");
		exit(1);
	}

	/* dump all the records into the output data file in the bulk export format */
	e = MLGF_Dump(mlgfd, TRUE, fd);
	ERROR_CHECK(e, "MLGF_Dump()");

	printf("\n# All the records of mlgf are exported into the output data file.\n");

	/* close the output data file */
	fclose(fd);

	/* close the MLGF file */
	e = MLGF_CloseIndex(mlgfd);
	ERROR_CHECK(e, "MLGF_CloseIndex()");

	printf("\n# MLGF file is closed.\n");

	/* final MLGF */
	e = MLGF_Final();
	ERROR_CHECK(e, "MLGF_Final()");

	printf("\n\n\n### MLGF Bulk Export ends\n");

	return 0;
}
