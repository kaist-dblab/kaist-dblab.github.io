/******************************************************************************/
/*                                                                            */
/*    The Multilevel Grid File (MLGF)                                         */
/*    Version 4.0                                                             */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al. (1994-2016)               */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: kywhang@gmail.com                                               */
/*                                                                            */
/*    Bibliography:                                                           */
/*    [1] Whang, K. and Krishnamurthy, R., "The Multilevel Grid File - A      */
/*        Dynamic Hierarchical Multidimensional File Structure," In Proc. 2nd */
/*        Int'l Conf. on Database Systems for Advanced Applications, pp.      */
/*        449-459, 1991.                                                      */
/*    [2] Whang, K., Kim, S., and Wiederhold, G., "Dynamic Maintenance of     */
/*        Data Distribution for Selectivity Estimation," The VLDB Journal,    */
/*        Vol. 3, No. 1, pp. 29-51, 1994.                                     */
/*    [3] Lee, J., Lee, Y., and Whang, K., "A Region Splitting Strategy for   */
/*        Physical Database Design of Multidimensional File Organizations,"   */
/*        In Proc. 23rd Int'l Conf. on Very Large Data Bases, pp. 416-425,    */
/*        1997.                                                               */
/*    [4] Song, J., Whang, K., Lee, Y., Lee, M., and Kim, S., "Spatial Join   */
/*        Processing Using Corner Transformation, IEEE Transactions on        */
/*        Knowledge and Data Engineering (TKDE), Vol. 11, No. 4, pp. 688-695, */
/*        1999.                                                               */
/*    [5] Song, J. et al., "The Clustering Property of Corner Transformation  */
/*        for Spatial Database Applications," Information and Software        */
/*        Technology, Vol. 44, No. 7, pp. 419-429, 2002.                      */
/*    [6] Lee, M., Whang, K., Han, W., and Song, I., "Transform-Space View:   */
/*        Performing Spatial Join in the Transform Space Using Original-Space */
/*        Indexes," IEEE Transactions on Knowledge and Data Engineering       */
/*        (TKDE), Vol 18, No. 2, pp. 245-260, 2006.                           */
/*    [7] Dai, H., Whang, K., and Su, H., "Locality of Corner Transformation  */
/*        for Multidimensional Spatial Access Methods," Electronic Notes in   */
/*        Theoretical Computer Science, Vol. 212, pp. 133-148, 2008.          */
/*                                                                            */
/******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include "mlgf.h"


#define MAX_ATTRIBUTE_LEN	360

#define ERROR(e, msg)\
{\
	printf("%s : (error code %d) %s\n", msg, e, MLGF_Error(e));\
	exit(1);\
}
#define ERROR_CHECK(e, msg)	if(e < eNOERROR) ERROR(e, msg);


int isIntValue(char *inputStr, int inputStrLen);
int isFloatValue(char *inputStr, int inputStrLen);
int isValidStringValue(char *inputStr, int inputStrLen);


int main(int argc, char *argv[])
{
	int		i, j;	/* index */
	int		e;	/* error code */
	int		flag;	/* flag indicating whether dot(.) character has been processed or not */
	int		nRecords;	/* # of records inserted */
	int		start_time, current_time, timeInMilliSeconds, totalTimeElapsed;	/* for response time */
	char	*mlgfFileName;	/* mlgf file name */
	char	*inputDataFileName;	/* input data file name */
	char	inputStr[MAX_ATTRIBUTE_LEN];	/* character string read from the input data file */
	FILE	*fd;	/* input data file descriptor */
	Two		mlgfd;	/* mlgf file descriptor */
	Two		nKeyAttr;	/* # of organizing (key) attributes */
	Two		nAttr;	/* # of attributes */
	AttributeHeader	attr[MLGF_MAXNUM_ATTRIBUTES];	/* record to be inserted */
	struct timeb	start_timevar, current_timevar;	/* for response time */


	/* parse parameters */
	if(argc < 2)
	{
		printf("USAGE : MLGF_Bulk_Import <mlgf file name> <input data file name>\n");
		exit(1);
	}
	else
	{
		mlgfFileName = argv[1];
		inputDataFileName = argv[2];
	}

	printf("### MLGF Bulk Import starts\n");

	/* init MLGF */ 
	e = MLGF_Init(NUM_BUFS);
	ERROR_CHECK(e, "MLGF_Init()");

	/* open the MLGF file */
	 e = MLGF_OpenIndex(mlgfFileName, &mlgfd);

	ERROR_CHECK(e, "MLGF_OpenIndex()");

	printf("\n# MLGF file is opend.\n");

	/* get and print out MLGF info. */
	nKeyAttr = MLGF_GetN_KeyAttr(mlgfd);
	nAttr = MLGF_GetN_Attr(mlgfd);
	printf("\t- # of attributes: %d\n", nAttr);
	for(i=0; i<nAttr; i++)
	{
		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				printf("\t- Type of the attr #%d: INT", i+1); 
				ATTRIBUTE_LENGTH(&(attr[i])) = MLGF_GetAttrLength(mlgfd, i);
				INT_ATTRIBUTE(&(attr[i])) = (int*)malloc(MLGF_GetAttrLength(mlgfd, i));
				break;
			case FLOAT:
				printf("\t- Type of the attr #%d: FLAOT", i+1); 
				ATTRIBUTE_LENGTH(&(attr[i])) = MLGF_GetAttrLength(mlgfd, i);
				FLOAT_ATTRIBUTE(&(attr[i])) = (float*)malloc(MLGF_GetAttrLength(mlgfd, i));
				break;
			case STRING:
				printf("\t- Type of the attr #%d: STRING(%d)", i+1, MLGF_GetAttrLength(mlgfd, i)); 
				ATTRIBUTE_LENGTH(&(attr[i])) = MLGF_GetAttrLength(mlgfd, i);
				STRING_ATTRIBUTE(&(attr[i])) = (char*)malloc(MLGF_GetAttrLength(mlgfd, i));
				break;
			case VARSTRING:
				printf("\t- Type of the attr #%d: VARSTRING(%d)", i+1, MLGF_GetAttrLength(mlgfd, i)); 
				ATTRIBUTE_LENGTH(&(attr[i])) = MLGF_GetAttrLength(mlgfd, i);
				STRING_ATTRIBUTE(&(attr[i])) = (char*)malloc(MLGF_GetAttrLength(mlgfd, i));
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}

		if(i < nKeyAttr)
		{
			printf(" (organizing (key) attr)\n");
		}
		else
		{
			printf("\n");
		}
	}
	printf("\n");

	/* open the input data file */
 	fd = fopen(inputDataFileName, "rb");
	if(fd == NULL)
	{
		printf("Input data file open failed.\n");
		exit(1);
	}

	nRecords = 0;
	totalTimeElapsed = 0;
	while(1)
	{
		/* read a record from the input data file */
		for(i=0; i<nAttr; i++)
		{
			memset(inputStr, 0, MAX_ATTRIBUTE_LEN);
			if(fgets(inputStr, MAX_ATTRIBUTE_LEN, fd) == NULL)
			{
				if(i == 0)	/* EOF */
				{
					break;
				}
				else
				{
					printf("Wrong input data file.\n");
					exit(1);
				}
			}
			else if(inputStr[0] == '\n')
			{
				if(i == 0)	/* redundant blank line */
				{
					i--;	/* read a record from the next line */
					continue;
				}
				else
				{
					printf("Wrong input data file.\n");
					exit(1);
				}
			}
			else
			{
				inputStr[strlen(inputStr)-1] = '\0';	/* eleminate '\n' */
			}

			/* check whether the input value is valid or not */
			switch(MLGF_GetAttrType(mlgfd, i))
			{
				case INT:
					if(!isIntValue(inputStr, strlen(inputStr)))	/* wrong input */
					{
						printf("Wrong input data file.\n");
						exit(1);
					}
					else
					{
						*(INT_ATTRIBUTE(&(attr[i]))) = atoi(inputStr);
					}
					break;
				case FLOAT:
					if(!isFloatValue(inputStr, strlen(inputStr)))	/* wrong input */
					{
						printf("Wrong input data file.\n");
						exit(1);
					}
					else
					{
						*(FLOAT_ATTRIBUTE(&(attr[i]))) = (float)atof(inputStr);
					}
					break;
				case STRING:
					/* eleminate '"' */
					if(inputStr[0] != '"' || inputStr[strlen(inputStr)-1] != '"')	/* wrong input */
					{
						printf("Wrong input data file.\n");
						exit(1);
					}
					else
					{
						inputStr[strlen(inputStr)-1] = '\0';
						strcpy(inputStr, inputStr+1);

						if(strlen(inputStr) != MLGF_GetAttrLength(mlgfd, i) ||
							!isValidStringValue(inputStr, strlen(inputStr)))	/* wrong input */
						{
							printf("Wrong input data file.\n");
							exit(1);
						}
						else
						{
							memcpy(STRING_ATTRIBUTE(&(attr[i])), inputStr, strlen(inputStr));
						}
					}
					break;
				case VARSTRING:
					/* eleminate '"' */
					if(inputStr[0] != '"' || inputStr[strlen(inputStr)-1] != '"')	/* wrong input */
					{
						printf("Wrong input data file.\n");
						exit(1);
					}
					else
					{
						inputStr[strlen(inputStr)-1] = '\0';
						strcpy(inputStr, inputStr+1);

						if(strlen(inputStr) > MLGF_GetAttrLength(mlgfd, i) ||
							!isValidStringValue(inputStr, strlen(inputStr)))	/* wrong input */
						{
							printf("Wrong input data file.\n");
							exit(1);
						}
						else
						{
							ATTRIBUTE_LENGTH(&(attr[i])) = strlen(inputStr);
							memcpy(STRING_ATTRIBUTE(&(attr[i])), inputStr, strlen(inputStr));
						}
					}
					break;
				default:
					printf("Wrong input data file.\n");
					exit(1);
			}
		}

		if(i != nAttr)
		{
			if(i == 0)	/* EOF */
			{
				break;
			}
			else
			{
				printf("Wrong input data file.\n");
				exit(1);
			}
		}
		else
		{
			/* get start time */
			ftime(&start_timevar);

			/* insert the record into mlgf */
			e = MLGF_InsertObject(mlgfd, attr);
			if(e == eDUPLICATEDRECORD)
			{
				printf("# Record to be inserted is duplicated: ");
			}
			else if ( e == eDUPLICATEDKEY)
			{
				printf("# Hashed key to be inserted is duplicated: ");
			}
			else
			{
				ERROR_CHECK(e, "MLGF_InsertObject()");
				nRecords++;
			}

			/* get time elapsed */
			ftime(&current_timevar);
			start_time = start_timevar.time * 1000 + start_timevar.millitm;
			current_time = current_timevar.time * 1000 + current_timevar.millitm;
			timeInMilliSeconds = current_time - start_time;

			totalTimeElapsed += timeInMilliSeconds;

			/* print the record inserted */
			if(e == eDUPLICATEDRECORD || e==eDUPLICATEDKEY)
			{
			printf("(");
			for(i=0; i<nAttr; i++)
			{
				switch(MLGF_GetAttrType(mlgfd, i))
				{
					case INT:
						printf("%d", *INT_ATTRIBUTE(&attr[i]));
						break;
					case FLOAT:
						printf("%f", *FLOAT_ATTRIBUTE(&attr[i]));
						break;
					case STRING:
					case VARSTRING:
						printf("\"");
						for(j=0; j<ATTRIBUTE_LENGTH(&attr[i]); j++)
						{
							printf("%c", *(STRING_ATTRIBUTE(&attr[i])+j));
						}
						printf("\"");
						break;
					default:
						printf("Wrong attribute type.\n");
						exit(1);
				}

				if(i+1 < nAttr)
				{
					printf(", ");
				}
			}
			printf(")\n");
			}

			/* read the next record from the input data file */
			memset(inputStr, 0, MAX_ATTRIBUTE_LEN);
			if(fgets(inputStr, MAX_ATTRIBUTE_LEN, fd) == NULL)	/* EOF */
			{
				break;
			}
			else if(inputStr[0] == '\n')
			{
				continue;
			}
			else
			{
				printf("Wrong input data file.\n");
				exit(1);
			}
		}
	}

	printf("\n# Total %d records are inserted into mlgf\n", nRecords);
	printf("  (Total time elapsed: %dms)\n", totalTimeElapsed);

	/* free memory */
	for(i=0; i<nAttr; i++)
	{
		switch(MLGF_GetAttrType(mlgfd, i))
		{
			case INT:
				free(INT_ATTRIBUTE(&(attr[i])));
				break;
			case FLOAT:
				free(FLOAT_ATTRIBUTE(&(attr[i])));
				break;
			case STRING:
			case VARSTRING:
				free(STRING_ATTRIBUTE(&(attr[i])));
				break;
			default:
				printf("Wrong attribute type.\n");
				exit(1);
		}
	}

	/* close the input data file */
	fclose(fd);

	/* close the MLGF file */
	e = MLGF_CloseIndex(mlgfd);
	ERROR_CHECK(e, "MLGF_CloseIndex()");

	printf("\n# MLGF file is closed.\n");

	/* final MLGF */
	e = MLGF_Final();
	ERROR_CHECK(e, "MLGF_Final()");

	printf("\n\n\n### MLGF Bulk Import ends\n");

	return 0;
}

int isIntValue(char *inputStr, int inputStrLen)
{
    int     i;  /* index */

    for(i=0; i<inputStrLen; i++)
    {
        if(inputStr[i] >= '0' && inputStr[i] <='9') /* valid int value */
        {
            continue;
        }
        else if(i == 0 && inputStr[i] == '-' && inputStrLen > 1)    /* valid int value */
        {
            continue;
        }
        else    /* wrong value */
        {
            break;
        }
    }

    if(inputStrLen == 0 || i < inputStrLen)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

int isFloatValue(char *inputStr, int inputStrLen)
{
    int     i;  /* index */
    int     flag;   /* flag indicating whether dot(.) character has been processed or not */

    flag = FALSE;
    for(i=0; i<inputStrLen; i++)
    {
        if(inputStr[i] >= '0' && inputStr[i] <='9') /* valid float value */
        {
            continue;
        }
        else if(i == 0 && inputStr[i] == '-' && inputStrLen > 1)    /* valid float value */
        {
            continue;
        }
        else if(i != 0 && inputStr[i] == '.' && flag == FALSE)  /* valid float value */
        {
            flag = TRUE;
        }
        else    /* wrong value */
        {
            break;
        }
    }

    if(inputStrLen == 0 || i < inputStrLen)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

int isValidStringValue(char *inputStr, int inputStrLen)
{
    int i;  /* index */

    /* check whether the input character string is valid or not */
    for(i=0; i<inputStrLen; i++)
    {
        if((inputStr[i] >= 'a' && inputStr[i] <= 'z') ||
            (inputStr[i] >= 'A' && inputStr[i] <= 'Z') ||
            (inputStr[i] == ' ') ||
            (inputStr[i] >= '0' && inputStr[i] <= '9')) /* valid string valie */
        {
            continue;
        }
        else    /* wrong value */
        {
            break;
        }
    }

    if(inputStrLen == 0 || i < inputStrLen)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}
